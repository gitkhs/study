mkApp.view('defHeader').on.isLogin = function(login) {
	var v01 = mkApp.view('v01');
	v01.vo.login = login;
	login && v01.on.list();
};

mkApp.view('v01', function(ctrl, svc) {
	ctrl.onCreate = function(vo) {
		vo.login = true;
		vo.files = [];

		ctrl.open();
	};
	ctrl.onLoad = function() {
		svc.debug.log('onload');
	};

	ctrl.on.list = function(evt) {
		svc.http.post('/manager/deploy/list').then(function(rsHttp) {
			ctrl.vo.files = rsHttp;
		}).catch(function(err) {
			mkApp.alert(err.message).then(function() {
				evt && evt.target.focus();
			});
		});
	};
	ctrl.on.deploy = function(evt) {
		svc.http.post('/manager/deploy/deploy').then(function(rsHttp) {
			ctrl.vo.files = rsHttp;
		}).catch(function(err) {
			mkApp.alert(err.message).then(function() {
				evt.target.focus();
			});
		});
	};
	ctrl.on.detail = function(evt, row) {
		svc.http.post('/manager/deploy/detail', {
			name: row
		}).then(function(rsHttp) {
			mkApp.sheet('s01').open({
				file: row,
				data: rsHttp.data.replace(/\n/g, '<br/>')
			}).then(function(rtn) {
				rtn && ctrl.on.list(evt);
			});
		}).catch(function(err) {
			mkApp.alert(err.message).then(function() {
				evt.target.focus();
			});
		});
	};
});

mkApp.sheet('s01', function(ctrl, svc) {
	ctrl.onCreate = function(vo) {
		vo.data = '';

		ctrl.html = ['<div data-app-sheet-layout>',
			'<div data-app-sheet-bar>',
				'<div data-app-wrap>',
					'<strong style="float:left;" data-bind="text:vo.file">1234</strong>',
					'<button data-bind="click:on.remove">삭 제</button>',
					' <button data-bind="click:on.close, focus">확 인</button>',
					'<div></div>',
				'</div>',
			'</div>',
			'<div data-app-sheet-content>',
				'<div data-app-wrap>',
					'<div data-bind="html:vo.data"></div>',
				'</div>',
			'</div>',
		'</div>'];
	};
	ctrl.onLoad = function(prm) {
		ctrl.vo.file = prm.file;
		ctrl.vo.data = prm.data;
	};

	ctrl.on.close = function(evt) {
		ctrl.close();
	};
	ctrl.on.remove = function(evt) {
		mkApp.confirm('삭제 하시겠습니까').then(function(yes) {
			return yes && svc.http.post('/manager/deploy/remove', {name: ctrl.vo.file});
		}).then(function(rsHttp) {
			svc.debug.log(ctrl, rsHttp);
			ctrl.close(rsHttp.remove);
		}).catch(function(err) {
			mkApp.alert(err.message).then(function() {
				evt.target.focus();
			});
		});
	};
});