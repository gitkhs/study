var errorMsg = function(evt, msg) {
	return mkApp.alert(msg).then(function() {
		evt && evt.target.focus()
	});
};
mkApp.view('defHeader').on.isLogin = function(login) {
	var v01 = mkApp.view('v01');
	v01.vo.login = login;
	login && v01.on.list();
};

mkApp.view('v01', function(ctrl, svc) {
	ctrl.onCreate = function(vo) {
		vo.login = false;
		vo.domains = [];

		ctrl.open();
	};

	ctrl.on.list = function(evt) {
		svc.http.post('/manager/domain/list').then(function(rsHttp) {
			ctrl.vo.domains = rsHttp.domains;
		}).catch(function(err) {
			mkApp.alert(err.message).then(function() {
				evt && evt.target.focus();
			});
		});
	};
	ctrl.on.append = function(evt) {
		mkApp.modal('m01').open().then(function(result) {
			result && ctrl.on.list(evt);
		});
	};
	ctrl.on.detail = function(evt, row) {
		mkApp.sheet('s01').open(row).then(function(result) {
			// domain.domain_name = 'aaa';
		});
	};
});

mkApp.modal('m01', function(ctrl, svc) {
	ctrl.onCreate = function(vo) {
		vo.domain_id = '';
		vo.domain_name = '';
		vo.admin_id = '';
		vo.date_end = '';

		ctrl.html = ['<div data-app-modal-layout>',
			'<div data-app-modal-content>',
				'<div data-app-wrap>',
					'<div>domain id <input type="text" data-bind="value:vo.domain_id, focus"></div>',
					'<div>domain name <input type="text" data-bind="value:vo.domain_name"></div>',
					'<div>admin id <input type="text" data-bind="value:vo.admin_id"></div>',
					'<div>end date <input type="text" data-bind="value:vo.date_end"></div>',
				'</div>',
			'</div>',
			'<div data-app-modal-bar>',
				'<div data-app-wrap>',
					'<button data-bind="click:on.ok">확 인</button>',
					' <button data-bind="click:on.close">종 료</button>',
				'</div>',
			'</div>',
		'</div>'];
	};

	ctrl.on.close = function(evt) {
		ctrl.close();
	};
	ctrl.on.ok = function(evt) {
		if(!ctrl.vo.domain_id) return errorMsg(evt, '도메인 아이디 미입력');
		if(!ctrl.vo.domain_name) return errorMsg(evt, '도메인 명 미입력');
		if(!ctrl.vo.admin_id) return errorMsg(evt, '도메인 관리자 미입력');
		if(!ctrl.vo.date_end) return errorMsg(evt, '도메인 종료일 미입력');

		svc.http.post('/manager/domain/append', {
			domain_id: ctrl.vo.domain_id,
			domain_name: ctrl.vo.domain_name,
			admin_id: ctrl.vo.admin_id,
			date_end: ctrl.vo.date_end
		}).then(function(rsHttp) {
			rsHttp.result && mkApp.alert('처리 되었습니다.').then(function() {
				ctrl.close(rsHttp.result);
			});
		}).catch(function(err) {
			errorMsg(evt, err.message);
		});
		
	};
});

mkApp.sheet('s01', function(ctrl, svc) {
	ctrl.onCreate = function(vo) {
		vo.domain_id = '';
		vo.domain_name = '';
		vo.admin_id = '';
		vo.date_start = '';
		vo.date_end = '';
		vo.date_update = '';

		ctrl.html = ['<div data-app-sheet-layout>',
			'<div data-app-sheet-bar>',
				'<div data-app-wrap>',
					'<strong style="float:left;" data-bind="text:vo.domain_id">1234</strong>',
					'<button data-bind="click:on.modify">수 정</button>',
					' <button data-bind="click:on.close">취 소</button>',
					'<div></div>',
				'</div>',
			'</div>',
			'<div data-app-sheet-content>',
				'<div data-app-wrap>',
					'<div style="padding:3px;">domain_name: <span data-bind="text:vo.domain_name"></span></div>',
					'<div style="padding:3px;">admin_id: <span data-bind="text:vo.admin_id"></span></div>',
					'<div style="padding:3px;">date_start: <span data-bind="text:vo.date_start"></span></div>',
					'<div style="padding:3px;">date_update: <span data-bind="text:vo.date_update"></span></div>',
					'<div style="padding:3px;">date_end: <input type="text" data-bind="value:vo.date_end, focus"></div>',
				'</div>',
			'</div>',
		'</div>'];
	};
	ctrl.onLoad = function(prm) {
		ctrl.vo.domain_id = prm.domain_id;
		ctrl.vo.domain_name = prm.domain_name;
		ctrl.vo.admin_id = prm.admin_id;
		ctrl.vo.date_start = prm.date_start;
		ctrl.vo.date_end = prm.date_end;
		ctrl.vo.date_update = prm.date_update;
	};

	ctrl.on.close = function(evt) {
		ctrl.close();
	};
	ctrl.on.remove = function(evt) {};
	ctrl.on.modify = function(evt) {
		svc.http.post('/manager/domain/modify', {
			domain_id: ctrl.vo.domain_id,
			date_end: ctrl.vo.date_end
		}).then(function(rsHttp) {
			rsHttp.result && mkApp.alert('처리 되었습니다.').then(function() {
				// ctrl.close(rsHttp.result);
			});
		}).catch(function(err) {
			mkApp.alert(err.message).then(function() {
				evt && evt.target.focus();
			});
		});
	};
});