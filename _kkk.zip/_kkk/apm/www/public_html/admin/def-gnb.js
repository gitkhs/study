mkApp.config = 	{
	alert: {
		html: ['<div data-app-modal-layout>',
			'<div data-app-modal-content>',
				'<div data-app-wrap>',
					'<div data-bind="html:vo.msg">msg</div>',
				'</div>',
			'</div>',
			'<div data-app-modal-bar>',
				'<div data-app-wrap>',
					'<button data-bind="text:vo.ok, click:on.ok, focus">ok</button>',
				'</div>',
			'</div>',
		'</div>'],
		btnOk: '확인'
	},
	confirm: {
		html: ['<div data-app-modal-layout>',
			'<div data-app-modal-content>',
				'<div data-app-wrap>',
					'<div data-bind="html:vo.msg"></div>',
				'</div>',
			'</div>',
			'<div data-app-modal-bar>',
				'<div data-app-wrap>',
					'<button data-bind="text:vo.yes, click:on.yes, focus">yes</button>',
					' <button data-bind="text:vo.no, click:on.no">no</button>',
				'</div>',
			'</div>',
		'</div>'],
		btnYes: '예',
		btnNo: '아니오'
	},
	toast: {
		html: ['<div data-app-sheet-layout>',
			'<div data-app-sheet-content style="background:#555; color:#fff;">',
				'<div data-app-wrap>',
					'<div data-bind="html:vo.msg"></div>',
				'</div>',
			'</div>',
		'</div>'],
		time: 3000
	}
};

mkApp.view('defHeader', function(ctrl, svc) {
	ctrl.onCreate = function(vo) {
		vo.login = false;

		ctrl.html = [
			'<div style="float:left;">admin</div>',
			'<div style="float:right;">',
				'<!-- ko ifnot:vo.login --><button data-bind="click:on.login">login</button><!-- /ko -->',
				'<!-- ko if:vo.login --><button data-bind="click:on.logout">logout</button><!-- /ko -->',
			'</div>',
			'<div style="clear:both;"></div>'
		];
		ctrl.open();
	};
	ctrl.onLoad = function() {
		svc.http.post('/manager/auth/isLogin').then(function(rsHttp) {
			ctrl.vo.login = rsHttp.login;
			ctrl.on.isLogin && ctrl.on.isLogin(rsHttp.login);
		}).catch(function(err) {
			mkApp.log(ctrl, err);
		});
	};

	ctrl.on.login = function(evt) {
		mkApp.modal('dlgLogin').open();
	};
	ctrl.on.logout = function(evt) {
		svc.http.post('/manager/auth/logout').then(function(rsHttp) {
			location.reload();
		}).catch(function(err) {
			 mkApp.alert(err.message).then(function() {
				evt.target.focus();
			});
		});
	};
});

mkApp.modal('dlgLogin', function(ctrl, svc) {
	ctrl.onCreate = function(vo) {
		vo.id = '';
		vo.pwd = '';

		ctrl.html = [
			'<div data-app-modal-layout>',
				'<div data-app-modal-content>',
					'<div data-app-wrap>',
						'<div>id <input type="text" data-bind="value:vo.id"></div>',
						'<div>pwd <input type="password" data-bind="value:vo.pwd"></div>',
					'</div>',
				'</div>',
				'<div data-app-modal-bar>',
					'<div data-app-wrap>',
						'<button data-bind="click:on.ok, focus">확 인</button>',
					'</div>',
				'</div>',
			'</div>'
		];
	};
	ctrl.on.ok = function(evt) {
		if(!ctrl.vo.id || !ctrl.vo.pwd) {
			return mkApp.alert('아이디 또는 패스워드 미입력').then(function() {
				evt.target.focus();
			});
		}

		svc.http.post('/manager/auth/login', {
			id: ctrl.vo.id,
			pwd: ctrl.vo.pwd
		}).then(function(rsHttp) {
			rsHttp.login && location.reload();
		}).catch(function(err) {
			 mkApp.alert(err.message).then(function() {
				evt.target.focus();
			});
		});
	};
});
