<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Deploy extends CI_Controller {
	public function __construct() {
		parent::__construct();

		$this->load->model('mAuthManager', 'auth');
		$this->auth->checkLogin();
		$this->load->helper('file');
	}
	public function deploy() {
		exec('D:/project/apm/www/deploy/run.bat >> D:/project/apm/www/deploy/'.date('Ymd').'.txt');
		$this->list();
	}
	public function list() {
		$data = array();
		foreach(get_filenames('D:/project/apm/www/deploy') as $row) {
			if(substr($row, -4) == '.txt') array_push($data, $row);
		}

		$this->ioJson->output($data);
	}
	public function detail() {
		$input = $this->ioJson->input();

		$data = read_file('D:/project/apm/www/deploy/'.$input->name);
		$this->ioJson->output(array(
			'data' => $data,
		));
	}
	public function remove() {
		$input = $this->ioJson->input();

		if(unlink('../deploy/'.$input->name)) {
			$this->ioJson->output(array(
				'remove' => true,
			));
		}
	}
}
