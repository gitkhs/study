<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Domain extends CI_Controller {
	public function __construct() {
		parent::__construct();

		$this->load->model('mAuthManager', 'auth');
		$this->auth->checkLogin();
	}

	public function list() {
		$total = $this->db->count_all('use_domain');
		$domains = $this->db->get('use_domain', 0, 10)->result();

		$this->ioJson->output(array(
			'total' => $total,
			'domains' => $domains,
		));
	}
	public function append() {
		$input = $this->ioJson->input();

		$this->db->insert('use_domain', array(
			'domain_id' => $input->domain_id,
			'domain_name' => $input->domain_name,
			'admin_id' => $input->admin_id,
			'date_start' => date('Ymd'),
			'date_update' => date('Ymd'),
			'date_end' => $input->date_end,
		));
		$this->ioJson->output(array(
			'result' => true,
		));
	}
	public function modify() {
		$input = $this->ioJson->input();

		$this->db->update('use_domain',
			// set
			array(
				'date_end' => $input->date_end,
			),
			// where
			array(
				'domain_id' => $input->domain_id,
			));
		$this->ioJson->output(array(
			'result' => true,
		));
	}
	public function remove() {
	}
}

/*
create table `use_domain` (
	`domain_id` varchar(50) not null,
	`domain_name` varchar(50) not null,
	`admin_id` varchar(20) not null,
	`date_start` date not null,
	`date_end` date not null,
	`date_update` date not null,
	primary key(`domain_id`)
);
*/