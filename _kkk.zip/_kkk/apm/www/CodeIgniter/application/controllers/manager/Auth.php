<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	public function __construct() {
		parent::__construct();

		$this->load->model('mAuthManager', 'auth');
	}
	public function isLogin() {
		$this->ioJson->output(array(
			'login' => $this->auth->isLogin(),
		));
	}
	public function login() {
		$data = $this->ioJson->input();
		if($data->id == '') throw new Exception('아이디를 입력 하세요.', 1);
		if($data->id != 'manager') throw new Exception('아이디가 일치 하지 않습니다.', 1);
		if($data->pwd == '') throw new Exception('비밀번호를 입력 하세요.', 1);
		if($data->pwd != 'm@nag2r') throw new Exception('비밀번호가 일치 하지 않습니다.', 1);

		$this->auth->setLogin(true);
		$this->ioJson->output(array(
			'login' => true,
		));
	}
	public function logout() {
		$this->auth->setLogin(false);
		$this->ioJson->output(array(
			'login' => false,
		));
	}
}
