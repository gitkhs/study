<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Domain extends CI_Controller {
	public function __construct() {
		parent::__construct();
	}

	public function list() {
		$data = array(
			'list' => array(
				'id' => 'abcd.com',
				'admin' => 'abcd',
			),
		);
		$this->ioJson->output($data);
	}
}
