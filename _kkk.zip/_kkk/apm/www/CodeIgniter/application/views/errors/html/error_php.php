<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once 'header.php';

$err = array();
if (defined('SHOW_DEBUG_BACKTRACE') && SHOW_DEBUG_BACKTRACE === TRUE):
	foreach (debug_backtrace() as $error):
		if (isset($error['file']) && strpos($error['file'], realpath(BASEPATH)) !== 0):
			array_push($err, array(
				'File' => $error['file'],
				'Line' => $error['line'],
				'Function' => $error['function'],
			));
		endif;
	endforeach;
endif;
echo json_encode(array(
	'error' => 3,
	'message' => $err,
));
?>
