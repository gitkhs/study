<?php
$hd = apache_request_headers();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: '.$hd['Origin']);
header('Access-Control-Allow-Credentials: true');
?>