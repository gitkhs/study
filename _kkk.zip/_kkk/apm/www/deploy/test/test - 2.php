<?php

// try {
// 	$con = new PDO('mysql:host=localhost;dbname=php7;charset=utf8', 'php', 'php7');
// } catch(PDOException $e) {
// 	echo 'connnection error: ' .$e->getMessage();
// }

// foreach($con->query('select * from test') as $row) {
// 	// print_r($row);
// 	echo $row['col2'];
// }
phpinfo();

?>