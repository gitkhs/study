# APM 환경설정

모든 환경은 바이너리 파일을 기준으로 작성

## apache 설정

### apache 다운로드 및 압축해제

[다운로드](http://apachelounge.com/download)

다운로드 받은 파일의 원하는 위치(d:\apm\)에 압축을 해지 한다.
압축을 해지하면 Apache24폴더가 생성된다.

### conf 파일수정

Apache24폴더의 conf폴더(d:\apm\Apache24\conf)로 이동 후 httpd.conf 파일을 수정한다.

`Define` 구문이 있는 경우 `SRVROOT` 값만 설치된 서버의 경로로 변경 한다. 그렇지 않은 경우 `ServerRoot`값과 `DocumentRoot` 값 두개다 직접 변경해준다.

php 설치시 php 모듈 로드를 위해 맨아래 다음을 추가 한다.

```ini
# 서버루트
Define SRVROOT "D:/amp/Apache24"
ServerRoot "${SRVROOT}"

# 서버 포트
Listen 8080

# 도큐먼트 루트
Define DOCROOT "D:/apm/www"
DocumentRoot "${DOCROOT}/public_html"
<Directory "${DOCROOT}/public_html">
	# .htaccess 사용을 위한 설정
	AllowOverride All
</Directory>

# 디렉토리 index 페이지 우선순위
<IfModule dir_module>
    DirectoryIndex index.html
    DirectoryIndex index.php
</IfModule>


# php7 module
LoadModule php7_module "D:\amp\php7\php7apache2_4.dll"
addHandler application/x-httpd-php .php
# configure php.ini
PHPIniDir "D:\amp\php7"
SetHandler application/x-httpd-php

# .htaccess 사용을 위한 주석제거
LoadModule rewrite_module modules/mod_rewrite.so
```

### apache 실행

개발 PC의 환경변수에 apache 실행경로(D:\amp\Apache24\bin)를 등록한다.

cmd창을 열어 `httpd`를 수행하여 서버를 실행한다. 서버중지는 실행한 커맨트 창에 `Ctrl-C`키 입력으로 중지.

> httpd

## php 설정

### php7 다운로드 및 압축해제

[다운로드](http://windows.php.net/download/)

윈도우즈의 경우 Thread Safe와 Non Thread Safe 두가지가 있는데 Thread Safe를 다운받는다.

* Thread Safe: 윈도우즈의 경우 멀티 스레드 방식으로 구동 되고 있어 성능은 저하 되지만 안정성이 높다.
* Non Thread Safe: 성능저하의 문제점을 보안한 방식으로 안정성이 보장 되지 않는다.

다운로드 받은 파일을 원하는위치(d:\apm\)에 압축을 해지 한다.
압축 해지 후 폴더명을 php7로 변경.

### php.ini 파일수정

php7폴더 안에 보면 **php.ini** 파일이 존재 하지 않는다. php.ini-development 와 php.ini-production 중 하나를 copy해서 사용한다. 페이지 디버깅 출력은 `php.ini-development`를 사용한다.

```ini
# php확장 기능 사용을 위한 경로 
extension_dir = "D:\apm\php7\ext"
# myspl 모듈 설정
extension=php_pdo_mysql.dll
```

### php 연동 확인

제대로 연동되었는지 확인을 위해 apache의 `DocumentRoot` 에 php 파일 작성 후 확인해본다.
php 구분 블록 `<?php` , `?>`에 작성한다.

```php
phpinfo();
```


## maria(mySql) 설정

### 다운로드 및 압축해제 / 실행

다운로드

다운로드 및 압축을 해지한다. 개발 PC의 환경변수에 mariadb 실행경로(D:\amp\mariadb\bin)를 등록한다. 커맨트 창 실행 후 서버를 콘솔모드로 실행.

> mysqld --console

종료시 다른 커맨드 창을 실행후 아래 커맨드 입력

> mysqladmin -u root shutdown

### 기본 명령어

사용자 관리
```sql
-- 추가
grant all privileges on *.* to username@localhost identified by 'password';
-- 삭제
delete from user where user='username';
```

데이터베이스 관리
```sql
-- 생성
create database dbname;
-- 삭제
drop database dbname;
-- 목록조회
show databases;
-- 사용선언
use dbname
```

### php동작 확인
```php
$con = new PDO('mysql:host=localhost;dbname=php7;charset=utf8', 'username', 'password');
```

## CodeIgniter

### 다운로드 및 설치

다운로드

`DocumentRoot` 아래 폴더에 압축을 해지 한다. `CodeIgniter` 폴더의 `index.php` 파일을 웹 루트로 옮긴 후 `$system_path` 와 `$application_folder` 값을 설치 경로에 맞게 수정 한다.

설치예
```
d:\apm\www\CodeIgniter	# 설치 위치
d:\apm\www\public_html	# DocumentRoot
d:\apm\www\public_html\index.php	# index.php
d:\apm\www\public_html\.htaccess	# index.php 제거를 위한 파일
```

index.php
```php
$system_path = '../CodeIgniter/system';
$application_folder = '../CodeIgniter/application';
```

### 환경설정

### URL에 index.php 삭제

URL정보에서 `index.php` 을 제거 하기 위해 apach 서버의 `mod_rewrite`가 활성화 되어 있어야 한다.
`.htaccess` 파일을 사용하여 설정한다.

.htaccess
```ini
RewriteEngine On

RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php/$1 [L]
```

httpd.conf
```ini
<Directory "${DOCROOT}/public_html">
	# .htaccess 사용을 위한 설정
	AllowOverride All
</Directory>
# .htaccess 사용을 위한 주석제거
LoadModule rewrite_module modules/mod_rewrite.so
```

### URL 접미어사용

config/config.php
```php
// url 뒤에 확장자 접미사를 사용 가능.
$config['url_suffix'] = '.json';
```
