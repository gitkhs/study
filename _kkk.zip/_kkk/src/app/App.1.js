require('./app.scss');
const err = vl => { throw vl; };
const ajax = async url => await fetch(url).then(rs=>rs.text());
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`);

const Controller = class {
	constructor({app, name, proc}) {
		this._vo = {};
		this._on = {};
		this.app = app;
		this.name = name;

		if(!proc) return err('invalid controller');

		proc(this, this.app.services);
	}
	async open(vl) {
		if(this._tpl) {
			this._html = this._html || await ajax(this._tpl) || '';
		}
		return await this._open(vl);
	}
	_open() { err('open is overridded'); }
	close(vl) { this._close(vl); }
	_close() { err('close is overridded'); }
	create(proc) { return this._create(proc), this; }
	_create(proc) { proc && proc(this._vo); }
	event(proc) { return proc && proc(this._on), this }
	onLoad(proc) { this._onload = proc; }

	set html(vl) { this._html = Array.isArray(vl) ? vl.join('') : vl; }
	set template(vl) { this._tpl = vl; }
	get vo() { return this._vo; }
	get on() { return this._on; }
};
const View = class extends Controller {
	constructor(vl) {
		super(vl);
		this.ctrl = 'View';
	}
	_create(proc) {
		document.addEventListener('DOMContentLoaded', () => {
			super._create(proc);
		});
	}
	async _open(prm) {
		const selector = `[data-app-view=${snake(this.name)}]`;
		const self = document.querySelector(selector);
		const listener = (vo) => {
			this._vo = vo;
			this._onload && this._onload(prm);
		};

		this._html && (self.innerHTML = this._html);
		this.app.attach({
			selector,
			listener,
			vo: this._vo,
			on: this._on,
		});
	}
	set visible(vl) {
		const selector = `[data-app-view=${snake(this.name)}]`;
		document.querySelector(selector).style.display = vl ? 'block' : 'none';
	}
};
const Modal = class extends Controller {
	constructor(vl) {
		super(vl);
		this.ctrl = 'Modal';
		this.prefix = 'data-app-modal';
	}
	async _open(prm) {
		const parent = document.querySelector(`[${this.prefix}-dailog]`);
		const self = parent.appendChild(document.createElement('div'));
		const listener = (vo) => {
			this._vo = vo;
			this._onload && this._onload(prm);
		};

		self.setAttribute(`${this.prefix}`, snake(this.name));
		self.setAttribute(`${this.prefix}-on`, '');

		self.innerHTML = this._html;
		this.dimmed();
		this.app.attach({
			listener,
			vo: this._vo,
			on: this._on,
			selector: `[${this.prefix}=${snake(this.name)}]`,
		});

		return new Promise((resolve) => { this.onclose = resolve; });
	}
	_close(rtn) {
		const parent = document.querySelector(`[${this.prefix}-dailog]`);
		const self = parent.querySelector(`[${this.prefix}=${snake(this.name)}]`);
		const animationend = evt => {
			self.removeEventListener('animationend', animationend);
			self.parentNode.removeChild(self);
			this.dimmed();
		};

		// console.log('c1', window.getComputedStyle(self).getPropertyValue('animation'));
		self.setAttribute(`${this.prefix}-off`, '');
		// console.log('c2', window.getComputedStyle(self).getPropertyValue('animation'));
		self.addEventListener('animationend', animationend);

		this.onclose && this.onclose(rtn);
	}
	dimmed() {
		const parent = document.querySelector(`[${this.prefix}-dailog]`);
		const dimmed = document.querySelector(`[${this.prefix}-dimmed]`);
		const append = () => {
			const dimmed = document.createElement('div');
			dimmed.setAttribute(`${this.prefix}-dimmed`, '');
			return dimmed;
		};

		dimmed && dimmed.parentNode.removeChild(dimmed);
		parent.lastChild && parent.insertBefore(
			append(),
			parent.lastChild
		);
	}
};
const Sheet = class extends Controller {
	constructor(vl) {
		super(vl);
		this.ctrl = 'Sheet';
		this.prefix = 'data-app-sheet';
	}
	async _open(prm) {
		const sheetName = snake(this.name);
		const parent = document.querySelector(`[${this.prefix}-dailog]`);
		const curr = parent.querySelector(`[${this.prefix}=${sheetName}]`);
		const listener = (vo) => {
			this._vo = vo;
			this._onload && this._onload(prm);
		};

		curr && parent.removeChild(curr);

		const self = parent.appendChild(document.createElement('div'));
		self.setAttribute(`${this.prefix}`, sheetName);
		self.setAttribute(`${this.prefix}-on`, '');
		self.innerHTML = this._html;

		this.app.attach({
			listener,
			vo: this._vo,
			on: this._on,
			selector: `[${this.prefix}=${sheetName}]`,
		});

		return new Promise((resolve) => { this.onclose = resolve; });
	}

	_close(rtn) {
		const sheetName = snake(this.name);
		const parent = document.querySelector(`[${this.prefix}-dailog]`);
		const self = parent.querySelector(`[${this.prefix}=${sheetName}]`);
		const aniEnd = evt => {
			self.parentNode.removeChild(self);
		};

		self.setAttribute(`${this.prefix}-off`, '');
		self.addEventListener('animationend', aniEnd);

		this.onclose && this.onclose(rtn);
	}
};
const Component = class Component extends Controller {
	constructor(vl) {
		super(vl);
		this.ctrl = 'Component';
		super.open();
	}
	open() {
		err(`componet::${this.name} open is not supported`);
	}
	async _open(prm) {
		const listener = (vo) => {
			this._vo = vo;
			this._onload && this._onload(prm);
		};
		this.app.setComponent({
			listener,
			vo: this._vo,
			on: this._on,
			html: this._html,
			selector: snake(this.name),
		});
	}
};

module.exports = class {
	constructor() {
		this.config = {};
		this.services = {};
		this.views = new Map();
		this.modals = new Map();
		this.sheets = new Map();
		this.components = new Map();
		this._popup = document.createElement('div');
		this._sheet = this._popup.appendChild(document.createElement('div'));
		this._modal = this._popup.appendChild(document.createElement('div'));
		this._style = document.head.insertBefore(
			document.createElement('style'),
			document.head.firstChild
		);

		// style 
		this._style.innerHTML = [
			'body {color:#aaa;}',
			'@keyframes modal-on {',
			'0% {margin-top: -20%; opacity: 0;}',
			'}',
			'@keyframes modal-off {100% {margin-top: -20%;opacity: 0;}}',
			
		].join('');
		this._popup.style = 'position:fixed; top:0; left:0; width:100%;';
		// this._sheet.outerHTML = ['<div style="position:fixed; width: 100%; left:0; bottom:0;">',
		// 		'<div style="border-top:solid 1px #aaa; height:80vh; background:#f00;">',
		// 		'a',
		// 		'</div>',
		// '</div>'].join('');
		// this._modal.innerHTML = [
		// 	'<div style="width:100%; height:100vh; background:#000; opacity:.5;"></div>',
		// ].join('');
		this._modal.style.position = 'fixed';
		this._modal.style.width = '100%';
		this._modal.style.left = '0';
		this._modal.style.top = '0';
		// document ready
		document.addEventListener('DOMContentLoaded', () => {
			// const dailog = document.body.appendChild(document.createElement('div'));
			// dailog.setAttribute('data-app-dailog', '');
			// dailog.innerHTML = '<div data-app-sheet-dailog></div><div data-app-modal-dailog></div>';
			this._init && this._init(this.config);

			document.body.appendChild(this._popup);
		});

		// debug service
		this.service('debug', () => {
			const local = /127.0.0.1|localhost/.test(location.hostname);
			const hash = location.hash.substr(1) &&
				JSON.parse('{"'+
					location.hash.substr(1)
					.replace(/=|&/g, v => ({'=':'":"', '&':'","'}[v]))
				+'"}') ||
				{};

			return {
				log(prefix, ...vl) {
					if(!local && !hash.debug) return;
					if(!(prefix instanceof Controller)) return console.log(prefix, ...vl);
	
					const {ctrl, name} = prefix;
					console.log(`%c[${ctrl}::${name}]`, 'font-weight:bold', ...vl);
				},
				break() {
					if(!local && !hash.debug && hash.debug != 'break') return;
					debugger;
				},
			};
		});
		// directive focus
		this.directive('focus', obj => {
			obj.init = function(el, vl) {
				setTimeout(()=>{el.focus()}, 1);
			};
		});
		// default alert
		this.modal('modalAlert', ctrl => {
			ctrl.create(vo => {
				vo.msg = '', vo.ok = '';
			}).event(on => {
				on.ok = () => ctrl.close();
			}).onLoad(({msg, ok}) => {
				ctrl.vo.msg = msg, ctrl.vo.ok = ok;
			});
		});
		// default confirm
		this.modal('modalConfirm', ctrl => {
			ctrl.create(vo => {
				vo.msg = '', vo.yes = '', vo.no = '';
			}).event(on => {
				on.yes = () => ctrl.close(true);
				on.no = () => ctrl.close(false);
			}).onLoad(({msg, yes, no}) => {
				ctrl.vo.msg = msg,
				ctrl.vo.yes = yes,
				ctrl.vo.no = no;
			});
		});
		// default toast
		this.sheet('sheetToast', ctrl => {
			ctrl.create(vo => {
				vo.msg = '';
			}).event(on => {
				on.ok = () => ctrl.close();
			}).onLoad(({msg, time}) => {
				ctrl.vo.msg = msg;
				setTimeout(() => ctrl.close(), time);
			});
		});
	}

	attach(vl) { this._attach(vl); }
	_attach(vl) { err('attach is override'); }
	setComponent(vl) { this._component(vl); }
	_component() { err('component is override'); }
	setDirective(name, proc) { this._directive(name, proc); }
	_directive(){ err('directive is override'); }

	init(proc) { this._init = proc; }
	getEl(vl) { return this[`_${vl}`]; }

	service(name, proc) {
		if(!name) return err('invalid service name');
		if(!proc) return this.services[name];

		this.services[name] = proc();
	}
	view(name, proc) {
		if(!name) return err('invalid view: name');
		if(!proc) return this.views.get(name);
		this.views.set(name, new View({ name, proc, app:this }));
	}
	modal(name, proc) {
		if(!name) return err('invalid modal: name');
		if(!proc) return this.modals.get(name);
		this.modals.set(name, new Modal({ name, proc, app:this }));
	}
	sheet(name, proc) {
		if(!name) return err('invalid sheet: name');
		if(!proc) return this.sheets.get(name);
		this.sheets.set(name, new Sheet({ name, proc, app:this }));
	}
	component(name, proc) {
		if(!name) return err('invalid component: name');
		if(!proc) return this.components.get(name);
		this.components.set(name, new Component({ name, proc, app:this }));
	}
	directive(name, procedure) {
		this.setDirective({name, procedure});
	}

	alert(msg, ok) {
		const {alert:{template, html, btnOk='OK'}} = this.config;
		this.modal('modalAlert').template = template;
		this.modal('modalAlert').html = Array.isArray(html) ? html.join('') : html;
		return this.modal('modalAlert').open({ msg, ok: ok || btnOk });
	}
	confirm(msg, yes, no) {
		const {confirm:{template, html, btnYes='YES', btnNo='NO'}} = this.config;
		this.modal('modalConfirm').template = template;
		this.modal('modalConfirm').html = Array.isArray(html) ? html.join('') : html;
		return this.modal('modalConfirm').open({ msg, yes: yes || btnYes, no: no || btnNo });
	}
	toast(msg, tm) {
		const {toast:{template, html, time=3000}} = this.config;
		this.sheet('sheetToast').template = template;
		this.sheet('sheetToast').html = Array.isArray(html) ? html.join('') : html;
		return this.sheet('sheetToast').open({ msg, time: tm || time });
	}
};
