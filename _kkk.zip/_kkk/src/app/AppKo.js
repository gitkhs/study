const App = require('./App');
const ko = require('../libs/knockout-3.4.2');
const bindObject = (vo, on) => {
	const _vo = {}, _on = {};
	Object.entries(vo).forEach(([ky, vl]) => {
		vo[ky] = Array.isArray(vl) ? ko.observableArray(vl) : ko.observable(vl);
		Object.defineProperty(_vo, ky, {
			get() { return vo[ky](); },
			set(v) { vo[ky](v); },
		});
	});
	Object.entries(on).forEach(([ky, vl]) => {
		_on[ky] = (...arg) => (vl && vl (arg.pop(), ...arg));
	});

	return { _vo, _on };
};
const MakeApp = class extends App {
	_attach({selector, vo, on, listener}) {
		const {_vo, _on} = bindObject(vo, on);
		const node = document.querySelector(selector);
		if(!node) {
			return console.log(`%ccan not find selector: ${selector}`, 'color:#f00');
		}

		ko.cleanNode(node);
		ko.applyBindings({ vo, on:_on }, node);
		listener && listener(_vo);
	}

	_component({selector, html:template, vo, on, listener}) {
		const {_vo, _on} = bindObject(vo, on);
		ko.components.register(selector, {
			template,
			viewModel: function() {
				this.vo = _vo;
				this.on = _on;
				listener && listener(_vo);
			},
		});
	}

	// sample - el data-bind="format:{value:'##.##', data:vo.data}"
	// sample - procedure function(el, vl) { console.log(vl); }
	_directive({name, procedure}) {
		if(name && procedure) {
			const val = (vl) => typeof vl === 'function' ? vl() : vl;
			const call = {};

			procedure(call);
			ko.bindingHandlers[name] = {
				init(el, vl) {
					call.init && call.init(el, val(vl()));
				}, 
				update(el, vl) {
					call.init && call.init(el, val(vl()));
				},
			};
		}
	}
};

window.shcApp = new MakeApp();
