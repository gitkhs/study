shcApp.service('http', function() {
	var SHOW = {Symbol:'SHOW'}, HIDE = {Symbol:'HIDE'};
	var REQUEST = {Symbol:'REQUEST'}, RESPONSE = {Symbol:'RESPONSE'}, ERROR = {Symbol:'ERROR'};
	var progressStat = HIDE;
	var local = /127.0.0.1|localhost/.test(location.hostname);
	var hash = (vl => {
		try {
			return JSON.parse('{"'+
				vl.replace(/=|&/g, v => ({'=':'":"', '&':'","'}[v]))
				+'"}');
		} catch(e) { return {}; }
	})(location.hash.substr(1));
	var log = function(type, url, vl) {
		if(!local && !hash.debug) return;

		var pf = '', st = '';
		var str = typeof vl === 'object' ? JSON.stringify(vl, null, '  ') : '';
		switch(type) {
		case REQUEST:
			pf = 'REQUEST| ' + url; st = 'font-weight:bold; color:#000;'; break;
		case RESPONSE:
			pf = 'RESPONSE| ' + url; st = 'font-weight:bold; color:#00f;'; break;
		case ERROR:
			pf = 'ERROR| ' + url; st = 'font-weight:bold; color:#f00;'; break;
		}

		if(document.documentMode) console.log(pf, vl, str);
		else console.log(`%c${pf}`, st, vl, str);
	};


	var makeParam = function(vl) {
		return Object.entries(vl).map(function(arg) {
			var ky = arg[0], vl = arg[1];
			return [
				encodeURIComponent(ky),
				encodeURIComponent(vl instanceof Object ? JSON.stringify(vl) : vl)
			].join('=');
		}).join('&');
	};
	var ajax = function(url, arg) {
		arg = arg || {};
		return fetch(url, {
			method: arg.method || 'GET',
			headers: arg.headers,
			body: arg.body,
			credentials: 'include'
		}).then(function(rs) {
			var contentType = rs.headers.get('Content-Type');
			var returnData = function(data) {
				return {status: rs.status, data:data};
			};

			if(/text/.test(contentType)) return rs.text().then(returnData);
			else if(/json/.test(contentType)) return  rs.json().then(returnData);
			else return rs.blob().then(function(data) {
				return {
					status: rs.status,
					data: {
						name: rs.headers.get('Content-Disposition'),
						blob: data
					}
				};
			});
		});
	};
	var send = function(url, data) {
		return new Promise(function(resolve, reject) {
			progressStat === HIDE && progress(SHOW);
			ajax(url, data).then(function(rtn) {
				progressStat === HIDE && progress(HIDE);
				if(rtn.status >= 200 && rtn.status < 300 && rtn.data) {
					return log(RESPONSE, url, rtn), resolve(rtn.data);
				}

				log(ERROR, url, rtn);
				reject(rtn.data || {message: 'data not found'});
			}).catch(function(err) {
				progressStat === HIDE && progress(HIDE);
				log(ERROR, url, err);
				reject(err);
			});
		});
	};

	var svc = {};
	svc.SHOW = SHOW, svc.HIDE = HIDE;
	svc.get = function(url, prm) {
		log(REQUEST, url, prm);
		return send(prm ? url + '?' + makeParam(prm || {}) : url);
	};
	svc.post = function(url, prm) {
		log(REQUEST, url, prm);
		return send(url, {
			method: 'POST',
			body: encodeURIComponent(JSON.stringify(prm || {}))
		});
	};
	svc.submit = function(url, prm) {
		log(REQUEST, url, prm);
		return send(url, {
			method: 'POST',
			body: Object.entries(prm || {}).reduce(function(frm, vl) {
				return frm.append(vl[0], encodeURIComponent(vl[1])), frm;
			}, new FormData())
		});
	};
	svc.async = function(vl) {
		log(REQUEST, '', vl);
		return new Promise(function(resolve, reject) {
			progressStat = SHOW, progress(progressStat);
			Promise.all(vl.map(function(vl) {
				return send(vl.url, {
					method: 'POST',
					body: encodeURIComponent(JSON.stringify(vl.param || {}))
				});
			})).then(function(vl) {
				progressStat = HIDE, progress(progressStat);
				console.log('-r-', vl);
				resolve(vl);
			}).catch(function(err) {
				progressStat = HIDE, progress(progressStat);
				console.log('-e-', err);
				reject(err);
			});
		});
	};
	svc.upload = function(url, vl) {
		log(REQUEST, url, vl);
		return new Promise(function(resolve, reject) {
			var file = document.querySelector(vl);
			if(!file || !file.files.length) {
				return reject('did not select a file');
			}

			var form = new FormData();
			form.append('userfile', file.files[0])
			send(url, {
				method: 'POST',
				body: form
			}).then(function() {
				resolve();
			}).catch(function(err) {
				reject(err);
			});
		});
	};
	svc.download = function(url, prm) {
		log(REQUEST, url, prm);
		return new Promise(function(resolve, reject) {
			send(url, {
				method: 'POST',
				body: encodeURIComponent(JSON.stringify(prm || {}))
			}).then(function(data) {
				if(data.blob.size <= 0) {
					return log(ERROR, url, rtn), reject({message: 'data size 0'});
				}

				if(document.documentMode) {
					window.navigator.msSaveBlob(data.blob, data.name);
				} else {
					var link = document.createElement('a');
					link.setAttribute('href', (window.URL || window.webkitURL).createObjectURL(data.blob));
					link.setAttribute('download', data.name);
					link.click();
					link.remove();
				}
				resolve();
			}).catch(function(err) {
				reject(err);
			});
		});
	};
	svc.loading = function(vl) {
		progressStat = vl;
		progress(vl);
		return svc;
	};

	// process
	// ================================================== //
	var _progress = document.createElement('div');
	_progress.setAttribute('style', 'position:fixed; top:0; left:0; width:100%; display:none;');
	_progress.innerHTML = [
		'<div data-app-progress-dimmed></div>',
		'<div data-app-progress-contents></div>',
		'<style>',
			'[data-app-progress-dimmed]{position:fixed; left:0; top:0; width:100%; height:100vh; background:#aaa; opacity:.3;}',
			'[data-app-progress-contents]{position:absolute; top:0; height:5px; width:100%; background-color: #3f51b5; background-size:50px 50px; background-image: linear-gradient(-45deg, rgba(255, 255, 255, .2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .2) 50%, rgba(255, 255, 255, .2) 75%, transparent 75%, transparent); animation:ani-progress 2s linear infinite;}',
			'@keyframes ani-progress {0% {background-position:0 0;} 100% {background-position:50px 50px;}}',
		'</style>'
	].join('');
	var progress = function(vl) {
		_progress.style.display = vl === SHOW ? 'block' : 'none';
	};
	document.addEventListener('DOMContentLoaded', function() {
		shcApp.appendLayer(_progress);
	});
	return svc;
});
