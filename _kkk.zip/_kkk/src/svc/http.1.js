shcApp.service('http', function() {
	var svc = {};
	var SHOW = {Symbol:'SHOW'}, HIDE = {Symbol:'HIDE'};
	var REQUEST = {Symbol:'REQUEST'}, RESPONSE = {Symbol:'RESPONSE'}, ERROR = {Symbol:'ERROR'};
	var progressStat = HIDE;
	var hash = location.hash.substr(1) ? JSON.parse('{"' +location.hash.substr(1).replace(/=|&/g, function(v){ return {'=':'":"', '&':'","'}[v]; })+'"}') : {};
	var local = /127.0.0.1|localhost/.test(location.hostname);
	var log = function(type, url, vl) {
		if(!local && !hash.debug) return;

		var sb = '', st = '';
		switch(type) {
		case REQUEST: sb = '%c[REQUEST] ' + url; st = 'font-weight:bold; color:#000;'; break;
		case RESPONSE: sb = '%c[RESPONSE] ' + url; st = 'font-weight:bold; color:#00f;'; break;
		case ERROR: sb = '%c[ERROR] ' + url; st = 'font-weight:bold; color:#f00;'; break;
		}
		console.log(sb, st, vl, typeof vl === 'object' ? JSON.stringify(vl, null, '  ') : '');
	};
	var progress = function(vl) {
		document.querySelector('[data-app-progress-dailog]')
		.style.display = vl === SHOW ? 'block' : 'none';
	};
	var layout, makeLayout = function() {
		var dailog = document.querySelector('[data-app-dailog]');
		var prog = document.querySelector('[data-app-progress-dailog]') ||
			dailog.appendChild(document.createElement('div'));
		prog.setAttribute('data-app-progress-dailog', '');
		prog.innerHTML = layout ? layout : [
			'<div data-app-progress-dimmed></div>',
			'<div data-app-progress-contents></div>',
			'<style>',
				'[data-app-progress-dailog]{position:absolute; width:100%; display:none;}',
				'[data-app-progress-dimmed]{position:fixed; left:0; top:0; width:100%; height:100%; background:#000; opacity:.1;}',
				'[data-app-progress-contents]{position:absolute; top:0; height:5px; width:100%; background-color: #3f51b5; background-size:50px 50px; background-image: linear-gradient(-45deg, rgba(255, 255, 255, .2) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, .2) 50%, rgba(255, 255, 255, .2) 75%, transparent 75%, transparent); animation: progress-on 2s linear infinite;}',
				'@keyframes progress-on {0% {background-position:0 0;} 100% {background-position:50px 50px;}}',
			'</style>'
		].join('');
	};
	var makeParam = function(vl) {
		return Object.entries(vl).map(function(arg) {
			var ky = arg[0], vl = arg[1];
			return [
				encodeURIComponent(ky),
				encodeURIComponent(vl instanceof Object ? JSON.stringify(vl) : vl)
			].join('=');
		}).join('&');
	};
	var ajax = function(url, arg) {
		arg = arg || {};
		return fetch(url, {
			method: arg.method || 'GET',
			headers: arg.headers,
			body: arg.body,
			credentials: 'include'
		}).then(function(rs) {
			var contentType = rs.headers.get('Content-Type');
			var returnData = function(data) { return {status: rs.status, data:data}; };

			if(/text/.test(contentType)) return rs.text().then(returnData);
			else if(/json/.test(contentType)) return  rs.json().then(returnData);
			else return rs.blob().then(returnData);
		});
	};
	var send = function(url, data) {
		return new Promise(function(resolve, reject) {
			ajax(url, data).then(function(rtn) {
				progressStat === HIDE && progress(HIDE);
				if(rtn.status >= 200 && rtn.status < 300 && rtn.data) {
					return log(RESPONSE, url, rtn), resolve(rtn.data);
				}

				log(ERROR, url, rtn);
				reject(rtn.data || {message: 'data not found'});
			}).catch(function(err) {
				progressStat === HIDE && progress(HIDE);
				log(ERROR, url, err);
				reject(err);
			});
		});
	};

	svc.get = function(url, prm) {
		progressStat === HIDE && progress(SHOW);
		log(REQUEST, url, prm);

		return send(prm ? url + '?' + makeParam(prm) : url);
	};
	svc.post = function(url, prm) {
		progressStat === HIDE && progress(SHOW);
		log(REQUEST, url, prm);

		return send(url, {
			method: 'POST',
			body: prm && encodeURIComponent(JSON.stringify(prm))
		});
	};
	svc.submit = function(url, prm) {
		progressStat === HIDE && progress(SHOW);
		log(REQUEST, url, prm);

		return send(url, {
			method: 'POST',
			body: prm && encodeURIComponent(makeParam(prm)),
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
			}
		});
	};
	svc.download = function(url, prm) {
		progressStat === HIDE && progress(SHOW);
		log(REQUEST, url, prm);

		return new Promise(function(resolve, reject) {
			ajax(prm ? url + '?' + makeParam(prm) : url).then(function(rtn) {
				progressStat === HIDE && progress(HIDE);
				if(!(rtn.status >= 200 && rtn.status < 300)) {
					return log(ERROR, url, rtn), reject(rtn.data);
				}
				var blob = rtn.data;
				if(blob.size <= 0) {
					return log(ERROR, url, rtn), reject({message: 'data size 0'});
				}

				log(RESPONSE, url, rtn);
				var filename = url.split('/');
				var agent = navigator.userAgent.toLowerCase();
				if(navigator.appName == 'Netscape' && (agent.includes('trident') || agent.includes('msie'))) {
					window.navigator.msSaveBlob(blob, filename.pop());
				} else {
					var link = document.createElement('a');
					link.setAttribute('href', (window.URL || window.webkitURL).createObjectURL(blob));
					link.setAttribute('download', filename.pop());
					link.click();
					link.remove();
				}
				resolve();
			}).catch(function(err) {
				progressStat === HIDE && progress(HIDE);
				log(ERROR, url, err);
				reject(err);
			});
		});
	};
	svc.upload = function(url, files) {
		console.log('not suported');
		return ;

		progressStat === HIDE && progress(SHOW);
		log(REQUEST, url);

		return new Promise(function(resolve, reject) {
			var form = new FormData();
			files = Array.isArray(files) ? files : [files];
			files.forEach(function(vl) {
				var fl = document.querySelector(vl);
				if(fl.files[0]) {
					form.append(fl.name, fl.files[0]);
				}
			});

			fetch(url, {
				method: 'POST',
				body: form
			}).then(function(rs) {
				var contentType = rs.headers.get('Content-Type');
				var returnData = function(data) { return {status: rs.status, data:data}; };
	
				if(/text/.test(contentType)) return rs.text().then(returnData);
				else if(/json/.test(contentType)) return  rs.json().then(returnData);
				else return rs.blob().then(returnData);
			}).then(function(rtn) {
				progressStat === HIDE && progress(HIDE);
				if(rtn.status >= 200 && rtn.status < 300 && rtn.data)
					return log(RESPONSE, url, rtn), resolve(rtn.data);

				log(ERROR, url, rtn);
				reject(rtn.data);
			}).catch(function(err) {
				progressStat === HIDE && progress(HIDE);
				log(ERROR, url, err);
				reject(err);
			});
		});
	};

	Object.defineProperty(svc, 'layout', {
		set: function(vl) {
			layout = Array.isArray(vl) ? vl.join('') : vl;
		}
	});
	Object.defineProperty(svc, 'loading', {
		set: function(vl) {
			progressStat = vl === true ? SHOW : HIDE;
			progress(progressStat);
		}
	});
	// process
	// ================================================== //
	document.addEventListener('DOMContentLoaded', makeLayout);
	return svc;
});
