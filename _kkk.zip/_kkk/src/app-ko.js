const ko = require('./libs/knockout-3.4.2');
const err = vl => { throw vl; };
const ajax = async url => await fetch(url).then(rs => rs.text());
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`);
const _app = {};
const _svc = new Map();
const _viw = new Map();
const _pop = new Map();
const _com = new Map();


const Controller = class {
	constructor({con, name, proc}) {
		this.con = con;
		this.name = name;
		this._on = {};

		if(!proc) return err('invalid controller procedure');
		proc(this);
	}
	onCreate(proc) {
		proc || err('invalid create procedure');
		return this._create(proc), this;
	}
	addEvent(name, proc) {
		name || proc || err('invalid event name or procedure');
		this._on[name] = proc();
		return this;
	}
	onLoad(proc) {
		proc || err('invalid load procedure');
		this._onload = proc;
		return this;
	}
	set html(vl) { this._html = Array.isArray(vl) ? vl.join('') : vl; }
	set template(vl) { this._tpl = vl; }
	get vo() { return this._vo; }
	get on() { return this._on; }

	_create(proc) { proc && proc(this._init = {}); }
	async _attach(prm) {
		this.self || err(`${this.name} is invalid DOM Object`);
		this._tpl && (this._html = this._html || await ajax(this._tpl) || '');
		this._html && (this.self.innerHTML = this._html);
		this._makeObserv();

		const isload = ko.observable(this._load);
		ko.cleanNode(this.self);
		ko.applyBindings({
			load: isload,
			vo: this._vo,
			on: this._on,
		}, this.self);

		this._onload && this._onload(prm);
		return new Promise((resolve) => { this._onclose = resolve; });
	}
	_makeObserv() {
		this._vo = {};
		Object.entries(this._init).forEach(([ky, vl]) => {
			const observ = Array.isArray(vl) ? ko.observableArray(vl) : ko.observable(vl);
			Object.defineProperty(this._vo, ky, {
				set(v) { observ(v); },
				get() { return Array.isArray(observ()) ? observ : observ(); },
			});
		});
	}
};
const View = class extends Controller {
	_attach() {}
	_create(proc) {
		document.addEventListener('DOMContentLoaded', () => {
			super._create(proc);
		});
	}
	bind(prm) {
		this.self = document.querySelector(`[data-app-view=${snake(this.name)}]`);
		this.self.setAttribute('data-bind', "if:load");
		this._load = true;
		return super._attach(prm);
	}
	visible(vl) {}
};
const Popup = class extends Controller {
	_attach() {}
	modal(prm) {
		if(document.querySelector(`[data-app-modal=${snake(this.name)}]`)) return;
		const {popup:{modal:{open}}} = _app.config;

		_app.modal.appendChild(_app.modalBG);
		this.self = _app.modal.appendChild(document.createElement('div'));
		this.self.setAttribute('data-app-modal', snake(this.name));
		this.self.setAttribute('style', open);
		this._load = 'modal';
		return super._attach(prm);
	}
	modaless(prm) {
		const {popup:{modaless:{open}}} = _app.config;
		const self = document.querySelector(`[data-app-modaless=${snake(this.name)}]`);

		this.self = self || _app.modaless.appendChild(document.createElement('div'));
		self || this.self.setAttribute('data-app-modaless', snake(this.name));
		this.self.setAttribute('style', open);
		this._load = 'modaless';
		return super._attach(prm);
	}
	close(prm) {
		const {popup} = _app.config;
		const {close} = popup[this._load];
		const remove = () => {
			this._load == 'modal' && _app[this._load].removeChild(_app.modalBG);
			_app[this._load].removeChild(this.self);
			this._load == 'modal' && _app[this._load].lastChild &&
				_app[this._load].insertBefore(_app.modalBG, _app[this._load].lastChild);

			self.removeEventListener('animationend', remove);
		};

		close && this.self.setAttribute('style', close);
		if(/animation/.test(close)) this.self.addEventListener('animationend', remove);
		else remove();

		this._onclose && this._onclose(prm);
	}
};
const Component = class Component extends Controller {
	set template(vl) { err('can not surpport template'); }
	_attach() {}
	_create(proc) {
		proc && proc(this._init = {});

		this._html || err(`${this.name} is invalid template`);
		this._makeObserv();

		const _vo = this._vo;
		const _on = this._on;
		const _onload = this._onload;
		ko.components.register(snake(this.name), {
			template: this._html,
			viewModel: function() {
				this.vo = _vo;
				this.on = _on;
				_onload && _onload(prm);
			}
		});
	}
};

const App = class App {
	constructor() {
		_app.style = document.createElement('style');
		_app.layer = document.createElement('div');
		_app.modalBG = document.createElement('div');
		_app.modaless = _app.layer.appendChild(document.createElement('div'));
		_app.modal = _app.layer.appendChild(document.createElement('div'));
		_app.modal.setAttribute('style', 'position:fixed; top:0; left:0; width:100%;');
		_app.modaless.setAttribute('style', 'position:fixed; top:0; left:0; width:100%;');

		// document ready
		document.addEventListener('DOMContentLoaded', () => {
			const {style, popup} = _app.config;
			document.body.appendChild(_app.layer);
			if(style) {
				document.head.insertBefore(_app.style, document.head.firstChild);
				_app.style.innerHTML = Array.isArray(style) ? style.join('') : style;
			}
			if(popup) {
				const {modal:{bgStyle, bgHtml}} = popup;
				bgStyle && _app.modalBG.setAttribute('style', bgStyle);
				bgHtml && (_app.modalBG.innerHTML = bgHtml);
			}
		});

		// debug service
		this.service('debug', () => {
			const local = /127.0.0.1|localhost/.test(location.hostname);
			const hash = (vl => {
				try {
					return JSON.parse('{"'+
						vl.replace(/=|&/g, v => ({'=':'":"', '&':'","'}[v]))
						+'"}');
				} catch(e) { return {}; }
			})(location.hash.substr(1));
			const print = (pf, st, vl) => {
				if(document.documentMode) console.log(pf, ...vl);
				else console.log(`%c${pf}`, st, ...vl);
			};

			return {
				log(ctrl, ...vl) {
					if(!console) return;
					if(!(local || 'debug' in hash)) return;
					if(!(ctrl instanceof Controller)) return console.log(ctrl, ...vl);
					print(`${ctrl.con}::${ctrl.name}| `, 'font-weight:bold', vl);
				},
				err(ctrl, ...vl) {
					if(!console) return;
					if(!(local || 'debug' in hash)) return;
					if(!(ctrl instanceof Controller)) return print('Error: ', 'font-weight:bold;color:#f00;', [ctrl, ...vl]);
					print(`${ctrl.con}::${ctrl.name}|Error: `, 'font-weight:bold;color:#f00;', vl);
				},
				break() {
					if(!(local || 'debug' in hash && hash.debug == 'break')) return;
					debugger;
				},
			};
		});
		// directive focus
		this.directive('focus', (obj = {}) => {
			obj.init = function(el, vl) {
				setTimeout(()=>{el.focus()}, 1);
			};
			return obj;
		});
		// default alert
		this.popup('modalAlert', ctrl => {
			ctrl.onCreate(vo => {
				vo.msg = '', vo.ok = '';
			}).addEvent('ok', () => ({
				click() { ctrl.close(); }
			})).onLoad(({msg, ok}) => {
				ctrl.vo.msg = msg, ctrl.vo.ok = ok;
			});
		});
		// default confirm
		this.popup('modalConfirm', ctrl => {
			ctrl.onCreate(vo => {
				vo.msg = '', vo.yes = '', vo.no = '';
			}).addEvent('yes', () => ({
				click() { ctrl.close(true); }
			})).addEvent('no', () => ({
				click() { ctrl.close(false); }
			})).onLoad(({msg, yes, no}) => {
				ctrl.vo.msg = msg,
				ctrl.vo.yes = yes,
				ctrl.vo.no = no;
			});
		});
		// default toast
		this.popup('sheetToast', ctrl => {
			ctrl.onCreate(vo => {
				vo.msg = '';
			}).onLoad(({msg, time}) => {
				ctrl.vo.msg = msg;
				setTimeout(() => ctrl.close(), time);
			});
		});
	}

	service(name, proc) {
		if(!name) return err('invalid service name');
		if(!proc) return _svc.get(name);
		_svc.set(name, proc());
	}
	view(name, proc) {
		if(!name) return err('invalid view: name');
		if(!proc) return _viw.get(name);
		_viw.set(name, new View({ name, proc, con:'view' }));
	}
	popup(name, proc) {
		if(!name) return err('invalid popup: name');
		if(!proc) return _pop.get(name);
		_pop.set(name, new Popup({ name, proc, con:'pop' }));
	}
	component(name, proc) {
		if(!name) return err('invalid component: name');
		if(!proc) return _com.get(name);
		_com.set(name, new Component({ name, proc, con:'comp' }));
	}
	directive(name, proc) {
		// sample - el data-bind="format:{value:'##.##', data:vo.data}"
		// sample - procedure function(el, vl) { console.log(vl); }
		if(!name) return err('invalid directive: name, procedure');

		const val = (vl) => typeof vl === 'function' ? vl() : vl;
		const {init, update} = proc();

		ko.bindingHandlers[name] = {
			init(el, vl) {
				init && init(el, val(vl()));
			}, 
			update(el, vl) {
				update && update(el, val(vl()));
			},
		};
	}
	alert(msg, ok) {
		const {alert:{template, html, btnOk='OK'}={}} = _app.config;
		const alert = this.popup('modalAlert');

		html || template || err('modalAlert invalid template');
		alert.template = template;
		alert.html = Array.isArray(html) ? html.join('') : html;
		return alert.modal({ msg, ok: ok || btnOk });
	}
	confirm(msg, yes, no) {
		const {confirm:{template, html, btnYes='YES', btnNo='NO'}={}} = _app.config;
		const confirm = this.popup('modalConfirm');

		html || template || err('modalConfirm invalid template');
		confirm.template = template;
		confirm.html = Array.isArray(html) ? html.join('') : html;
		return confirm.modal({ msg, yes: yes || btnYes, no: no || btnNo });
	}
	toast(msg, tm) {
		const {toast:{template, html, time=3000}={}} = _app.config;
		const toast = this.popup('sheetToast');

		toast.template = template;
		toast.html = Array.isArray(html) ? html.join('') : html;
		return toast.modaless({ msg, time: tm || time });
	}

	init(proc) {
		const config = proc && proc();
		_app.config = config && JSON.parse(JSON.stringify(config));
	}
	appendLayer(vl) { return _app.layer.appendChild(vl); }
	appendStyle(vl) { _app.style.innerHTML += vl; }
};

window.shcApp = new App();
