module.exports = ({target, version=''}, {mode='production'}) => {
	let outdir = '/asset';
	const entry = {};
	const rules = [];
	const module = {rules};
	const rulesTransfile = {
		test: /\.js$/,
		loader: 'babel-loader',
		exclude: /node_modules/,
		query: {
			// presets: [[
			// 	'env',
			// 	{ targets: {ie:6}, debug: true, useBuiltIns: true,}
			// ]],
			presets: [['env']]
		},
	};
	const rulesSass = {
		test: /\.scss$|\.sass$|\.css$/,
		use: [
			{ loader: 'style-loader', options: { insertAt: 'top' } },
			{ loader: 'css-loader' },
			{ loader: 'sass-loader' },
		],
	};

	entry[`make-app.${version}`] = [
		'whatwg-fetch',
		'babel-polyfill',
		'./src/app/AppKo.js',
	];
	entry[`make-service-http`] = './src/svc/http.1.js';
	entry[`shc-app-ko.${version}`] = [
		'whatwg-fetch',
		'babel-polyfill',
		'./src/app-ko.js',
	];
	entry[`shc-service-http`] = './src/svc/http.js';

	rules.push(rulesTransfile);
	rules.push(rulesSass);

	return {
		mode,
		module,
		entry,
		output: {
			path: __dirname + outdir,
			filename: '[name].js'
		},
	}
};
