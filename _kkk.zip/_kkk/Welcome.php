<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct();
		// throw new Exception('한글', 1);
	}
	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function testGet() {
		$input = $this->input->get();
		$this->ioJson->output(array(
			'input' => $input,
		));
	}
	public function testPost() {
		$input = $this->ioJson->input();
		$this->ioJson->output(array(
			'input' => $input,
		));
	}
	public function testSubmit() {
		$input = $this->input->post();
		$this->ioJson->output(array(
			'input' => $input,
		));
	}
	public function testDown() {
		$input = $this->ioJson->input();

		$origin = $this->input->get_request_header('Origin');
		if($origin) {
			$this->output
				->set_header('Access-Control-Allow-Origin: '.$origin)
				->set_header('Access-Control-Allow-Credentials: true');
		}

		$this->output->set_header('Access-Control-Expose-Headers:Content-Disposition');
		$this->output->set_header('Content-Disposition:deep.png');
		$this->output
			->set_content_type('png')
			->set_output(file_get_contents('deep.png'));
	}
	public function testUpload() {
		$con['upload_path'] = './';
		$con['allowed_types'] = 'gif|jpg|png';
		$con['max_size'] = 0;
		$con['max_width'] = 1024;
		$con['max_height'] = 768;

		$this->load->library('upload', $con);
		$this->upload->initialize($con);
		if(!$this->upload->do_upload()) {
			throw new Exception($this->upload->display_errors(), 1);
		}


		$origin = $this->input->get_request_header('Origin');
		if($origin) {
			$this->output
				->set_header('Access-Control-Allow-Origin: '.$origin)
				->set_header('Access-Control-Allow-Credentials: true');
		}
		$this->ioJson->output(array(
			'uri' => $_SERVER['HTTP_HOST'].'/'.$this->upload->data()['file_name'],
		));
	}

	// public function upload() {
	// 	$this->load->model('mIoFile', 'ioFile');
	// 	$this->ioFile->upload();

	// 	$data = array(
	// 		'test' => '',
	// 	);
	// 	$this->ioJson->output($data);
	// }
}
