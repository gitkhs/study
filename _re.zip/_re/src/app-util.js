const {
	snake,
	json,
	query,
	queryAll,
	element,
} = require('./util');
const prefixData = vl => `data-${vl}`;
const appSelector = (vl) => {
	const sel = Object.entries(vl)
		.map(([ky, vl]) => (vl ? `${snake(ky)}=${vl}` : snake(ky)))
		.join('');
	return prefixData(sel);
};
const appQuery = (vl, dom) => {
	const sel = appSelector(vl);
	return query(`[${sel}]`, dom) || query(`[${sel.replace('data-', '')}]`, dom)
};
const appQueryAll = (vl, dom) => {
	const sel = appSelector(vl);
	const all = queryAll(`[${sel}]`, dom);
	return all.length ? all : queryAll(`[${sel.replace('data-', '')}]`, dom)
};
const appElement = (vl) => {
	const attr = Object.entries(vl)
		.reduce((rs, [ky, vl]) => Object.assign(rs, {
			[prefixData(snake(ky))]: vl
		}), {});

	return element('div', {attr });
};
const queryElement = (sel, dom) => (appQuery(sel, dom) || appElement(sel));

module.exports = {
	appQuery,
	appQueryAll,
	appSelector,
	appElement,
	queryElement,
};