app.service('http', function(obj) {
	const {
		ajax,
		promise,
		query,
		isIE,
		hash,
	} = app.service('util');
	const log = (pt, url, ...vl) => {
		if(hash('log') == 'console' || (/127.0.0.1|localhost/.test(location.hostname) && console)) {
			if(isIE) {
				return console.log(
					`[service-http:${pt}]`,
					`${url}\n`,
					...vl,
					`\n${'-'.repeat(50)}\n`,
					JSON.stringify(vl, null, '  ')
				);
			}

			console.log(
				`%c[service-http:${pt}]`,
				`font-weight:bold; color:#${pt === 'REQUEST' ? '00f' : 'f00'};`,
				`${url}\n`,
				...vl,
				`\n${'-'.repeat(50)}\n`,
				JSON.stringify(vl, null, '  ')
			);
		}
	};
	const loadingbar = vl => {
		const prog = query('[data-app-progress-dailog]', document.body);
		prog.style.display = vl === true ? 'block' : 'none';
	};
	const rest = ({method, url, prm, loading}) => {
		loading && loadingbar(true);
		log('REQUEST', url, prm);

		return promise((resolve, reject) => {
            ajax(url, {
                method,
                body: prm && encodeURIComponent(JSON.stringify(prm))
            }).then((data) => {
				loading && loadingbar(false);
				log('RESPONSE', url, data);

				resolve(data);
            }).catch((err) => {
				loading && loadingbar(false);
				log('ERROR', url, err);

				reject(err);
            });
        });
	};

	obj.get = (url, loading = true) => rest({url, loading, method: 'GET'});

	obj.post = (url, prm, loading = true) => rest({url, prm, loading, method: 'POST'});

	obj.rest = (method, url, prm, loading = true) => rest({method, url, prm, loading});

	obj.submit = (url, prm, loading = true) => {
		loading && loadingbar(true);
		log('REQUEST', url, prm);

        return promise((resolve, reject) => {
            ajax(url, {
                method: 'POST',
                body: Object.entries(prm).map((vl) => {
                    return [
                        encodeURIComponent(vl[0]),
                        encodeURIComponent(
                            vl[1] instanceof Object ? JSON.stringify(vl[1]) : vl[1]
                        ),
                    ].join('=');
                }).join('&'),
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
                }
            }).then((data) => {
				loading && loadingbar(false);
				log('RESPONSE', url, data);

				resolve(data);
            }).catch((err) => {
				loading && loadingbar(false);
				log('ERROR', url, err);

				reject(err);
            });
        });
	};

	obj.download = (url, loading = true) => {
		loading && loadingbar(true);
		log('REQUEST', url);

        ajax(url).then((blob) => {
			loading && loadingbar(false);
			log('RESPONSE', url, blob);
            if(blob.size <= 0) return;

			const filename = url.split('/');

			if(isIE) {
				window.navigator.msSaveBlob(blob, filename.pop());
			} else {
				const link = document.createElement('a');
				link.setAttribute('href', (window.URL || window.webkitURL).createObjectURL(blob));
				link.setAttribute('download', filename.pop());
				link.click();
				link.remove();
			}
        }).catch((err) => {
			loading && loadingbar(false);
			log('ERROR', url, err);
        });
	};

	obj.upload = (url, sel, loading = true) => {
		const form = document.querySelector(sel);
		const files = form.querySelectorAll('input[type=file]');
		const values = [...files].reduce((pr, cr) => {
			pr[cr.name] = cr.value;
			return pr;
		}, {});

		loading && loadingbar(true);
		log('REQUEST', url, values);
		return promise((resolve, reject) => {
			ajax(url, {
				method: 'POST',
				body: new FormData(form),
			}).then((data) => {
				loading && loadingbar(false);
				log('RESPONSE', url, data);

				resolve(data);
			}).catch((err) => {
				loading && loadingbar(false);
				log('ERROR', url, err);

				reject(err);
			});
		});
	};
});
