module.exports = (Parent) => {
	const {hash, isIE} = require('./util');
	const {appQuery, appQueryAll, appSelector, appElement} = require('./app-util');
	const Controller = class extends Parent {
		constructor({name: _name, html: _html, tpl: _tpl}) {
			super();

			this._member = new WeakMap();
			this._member.set(this, {
				_name,
				_html,
				_tpl,
				_on: {},
			});
		}

		log(...vl) {
			const {_name, _clsName} = this._member.get(this);

			if(hash('log') == 'console' || (/127.0.0.1|localhost/.test(location.hostname) && console)) {
				if(isIE) {
					console.log(
						`[${_clsName}:${_name}]`,
						...vl,
						`\n${'-'.repeat(50)}\n`,
						JSON.stringify(vl, null, '  ')
					);
					return;
				}

				console.log(
					`%c[${_clsName}:${_name}]`,
					'font-weight:bold;',
					...vl,
					`\n${'-'.repeat(50)}\n`,
					JSON.stringify(vl, null, '  ')
				);
			}
		}

		// 컨트롤러 로드 함수 세팅
		set onload(_onload) {
			Object.assign(this._member.get(this), {
				_onload,
			});
		}

		// 이벤트 바인딩
		set on(vl) {
		}
		get on() {
			const {_on} = this._member.get(this);
			return _on;
		}

		// 프로그래스바
		set progress(vl) {
			const prog = appQuery({ appProgressDailog: '' }, document.body);
			prog.style.display = vl === true ? 'block' : 'none';
		}
	};

	// Bind
	// ============================== //
	const Bind = class extends Controller {
		constructor(vl) {
			super(vl);

			Object.assign(this._member.get(this), {
				_clsName: 'Bind',
			});
		}

		// 화면 로드
		load(prm) {
			const {_onload} = this._member.get(this);
			this.render({
				append: false,
				parent: document.body,
				created() {
					_onload && _onload(prm);
				},
			});
		}
	};

	// View
	// ============================== //
	const View = class extends Controller {
		constructor(vl) {
			super(vl);

			Object.assign(this._member.get(this), {
				_clsName: 'View',
			});
		}

		// 단일 뷰 로드
		load(prm, multi) {
			const {_name, _onload} = this._member.get(this);
			const parent = appQuery({ appContainer: '' }, document.body);

			this.render({
				parent,
				created() {
					[...appQueryAll({ appView: '' }, parent)].forEach(vl => {
						vl.dataset.appView == _name || vl.parentNode.removeChild(vl);
					});

					_onload && _onload(prm);
				},
			});
		}

		reload(prm) {
		}
	};

	// Modal
	// ============================== //
	const makeDimmed = () => {
		const parent = appQuery({ appModalDailog: '' }, document.body);
		const dimmed = appQuery({ appModalDimmed: '' }, parent);
		dimmed && dimmed.parentNode.removeChild(dimmed);
		parent.lastChild && parent.insertBefore(
			appElement({ appModalDimmed: '' }),
			parent.lastChild
		);
	};
	const Modal = class extends Controller {
		constructor(vl) {
			super(vl);

			Object.assign(this._member.get(this), {
				_clsName: 'Modal',
			});
		}

		// open
		open(prm) {
			const {_name, _onload} = this._member.get(this);
			const parent = appQuery({ appModalDailog: '' }, document.body);

			this.render({
				parent,
				created() {
					const dom = appQuery({ appModal: _name }, parent);
					dom.setAttribute(appSelector({ appModalOn: '' }), '');
					makeDimmed();

					_onload && _onload(prm);
				},
			});

			return new Promise((_close, reject) => {
				Object.assign(this._member.get(this), {
					_close,
				});
			});
		}

		// close
		close(prm) {
			const {_name, _close} = this._member.get(this);
			const parent = appQuery({ appModalDailog: '' }, document.body);
			const dom = appQuery({ appModal: _name }, parent);

			dom.setAttribute(appSelector({ appModalOff: '' }), '');
			dom.addEventListener('animationend', evt => {
				dom.parentNode.removeChild(dom);
				makeDimmed();
			});

			_close && _close(prm);
		}
	};

	// Sheet
	// ============================== //
	const Sheet = class extends Controller {
		constructor(vl) {
			super(vl);

			Object.assign(this._member.get(this), {
				_clsName: 'Sheet',
			});
		}

		// open
		open(prm) {
			const {_name, _onload} = this._member.get(this);
			const parent = appQuery({ appSheetDailog: '' }, document.body);

			this.render({
				parent,
				created() {
					const dom = appQuery({ appSheet: _name }, parent);
					dom.setAttribute(appSelector({ appSheetOn: '' }), '');
	
					_onload && _onload(prm);
				},
			});

			return new Promise((_close, reject) => {
				Object.assign(this._member.get(this), {
					_close,
				});
			});
		}

		// close
		close(prm) {
			const {_name, _close} = this._member.get(this);
			const parent = appQuery({ appSheetDailog: '' }, document.body);

			const dom = appQuery({ appSheet: _name }, parent);
			dom.setAttribute(appSelector({ appSheetOff: '' }), '');
			dom.addEventListener('animationend', evt => {
				dom.parentNode.removeChild(dom);
			});

			_close && _close(prm);
		}
	};

	// Component
	// ============================== //
	const Component = class extends Controller {
		constructor(vl) {
			super(vl);

			Object.assign(this._member.get(this), {
				_clsName: 'Component',
			});
		}

		load(prm) {
			const {
				_onload,
				_name: name,
				_html: html,
				_vo: vo,
				_on: on,
			} = this._member.get(this);

			this.setComponent({
				name,
				html,
				vo,
				on,
				after() {
					_onload && _onload(prm);
				},
			});
		}
	};

	return {
		Controller,
		Bind,
		View,
		Modal,
		Sheet,
		Component,
	};
};
