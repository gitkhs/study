//
// ================================================== //
const entries = vl => Object.entries(vl);
const json = vl => (typeof vl === 'string' ? JSON.parse(vl) : JSON.stringify(vl));
const left = (vl, sz) => vl.substr(0, sz);
const right = (vl, sz) => vl.substr(vl.length - sz);
const lpad = (vl, sz, ch=' ') => (vl.length >= sz ? vl : right(ch.repeat(sz) + vl, sz));
const rpad = (vl, sz, ch=' ') => (vl.length >= sz ? vl : left(vl + ch.repeat(sz), sz));
const date = (vl = 'yyyymmdd', dt = new Date) => {
	return vl.replace(/(yyyy|yy|mm|dd|h24|hh|mi|ss|ms|a\/p)/gi, (vl) => {
		switch(vl) {
		case 'yyyy': return dt.getFullYear();
		case 'yy': return lpad(dt.getFullYear(), 2, '0');
		case 'mm': return lpad(dt.getMonth()+1, 2, '0');
		case 'dd': return lpad(dt.getDate(), 2, '0');
		case 'h24': return lpad(dt.getHours(), 2, '0');
		case 'hh': return lpad(dt.getHours()%12 || 12, 2, '0');
		case 'mi': return lpad(dt.getMinutes(), 2, '0');
		case 'ss': return lpad(dt.getSeconds(), 2, '0');
		case 'ms': return lpad(dt.getMilliseconds(), 3, '0');
		default: return '';
		}
	});
};
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`);
const camel = vl => vl.replace(/-\w/g, vl => vl.toUpperCase().substr(1));
const ajax = async (url, {method='GET', headers, body} = {}) => {
	return await fetch(url, { method, headers, body }).then(rs => {
		const contentType = rs.headers.get('Content-Type');

		if(/text/.test(contentType)) return rs.text();
		if(/json/.test(contentType)) return rs.json();
		return rs.blob();
	});
};
const promise = fn => new Promise(fn);
const promiseAll = vl => Promise.all(vl);

// DOM Object & element controll
// ================================================== //
const isIE = (() => {
	const agent = navigator.userAgent.toLowerCase();
	if(navigator.appName == 'Netscape' && (agent.includes('trident') || agent.includes('msie'))) {
		return true;
	}
})();
const _hash = location.hash && location.hash.substr(1).replace(/&/g, '","').replace(/=/g, '":"');
const hash = (ky) => {
	const hash = (_hash && json(`{"${_hash}"}`)) || {};
	if(!ky) return hash;

	return hash[ky];
};
const query = (v, dom = document) => dom.querySelector(v);
const queryAll = (v, dom = document) => dom.querySelectorAll(v);
const element = (tag, {html, text, attr, css, on} = {}) => {
	const dom = document.createElement(tag);

	html ? (dom.innerHTML = html) : (text && (dom.innerText = text));
	attr && entries(attr).forEach(([k, v]) => dom.setAttribute(k, v));
	css && entries(css).forEach(([k, v]) => (dom.style[k] = v));
	on && entries(on).forEach(([k, v]) => dom.addEventListener(k, v));

	return dom;
};

module.exports = {
	entries,
	json,
	left,
	right,
	lpad,
	rpad,
	date,
	snake,
	camel,
	ajax,
	promise,
	promiseAll,
	
	isIE,
	hash,
	element,
	query,
	queryAll,
};