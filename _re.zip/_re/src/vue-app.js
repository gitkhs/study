const vuejs = require('./libs/vue.min');
const {snake, ajax} = require('./util');
const {queryElement} = require('./app-util');
const Vue = class {
	static htmlAlert() {
		return `<div data-app-modal-layout>
			<div data-app-modal-content>
				<div v-html="vo.msg"></div>
			</div>
			<div data-app-modal-bar>
				<button v-focus v-on:click="on.close">ok</button>
			</div>
		</div>`;
	}
	static htmlConfirm() {
		return `<div data-app-modal-layout>
			<div data-app-modal-content>
				<div v-html="vo.msg"></div>
			</div>
			<div data-app-modal-bar>
				<button v-text="vo.yes" v-on:click="on.yes" v-focus>yes</button>
				<button v-text="vo.no" v-on:click="on.no">no</button>
			</div>
		</div>`;
	}
	static htmlToast() {
		return `<div data-app-sheet-layout>
			<div data-app-sheet-content style="background:#555; color:#fff;">
				<div v-html="vo.msg"></div>
			</div>
		</div>`;
	}
	static directive(nm, fn) {
		if(nm && fn) {
			const {init, update} = fn();
			const obj = {
				inserted(el, vl, bind) {
					init && init(el, vl.value);
				},
				update(el, vl, bind) {
					update && update(el, vl.value);
				}
			};

			vuejs.directive(snake(nm), obj);
		}
	}


	async render({created, parent, append=true} = {}) {
		const {
			_name,
			_html,
			_tpl,
			_clsName,
			_vo: vo,
			_on: on = {},
		} = this._member.get(this);
		const selector = `app${_clsName}`;
		const template = _html || await ajax(_tpl);
		const dom = queryElement({ [selector]: _name }, parent);

		Object.assign(this._member.get(this), {
			_html: template,
		});

		dom.innerHTML = template;
		append && parent.appendChild(dom);

		new vuejs({
			el: `[data-${snake(selector)}=${_name}]`,
			data: { vo, on },
			created() {
				created && created();
			},
		});
	}

	setComponent({name, html, vo, on, after}) {
		vuejs.component(snake(name), {
			template: html,
			data() {
				return {vo, on};
			},
			created() {
				after && after();
			}
		});
	}

	set vo(src) {
		Object.assign(this._member.get(this), {
			_vo: src,
			_voPrx: Object.entries(src).reduce((prv, [ky]) => {
				prv[ky] = vl => (vl ? (src[ky] = vl) : src[ky]);
				return prv;
			}, {})
		});
	}

	get vo() {
		const {_voPrx} = this._member.get(this);
		return _voPrx;
	}
};

window.app = require('./app')(Vue);
