module.exports = (lib) => {
	require('./app-style.scss');
	const util = require('./util');
	const classes = require('./controller')(lib);

	const local = {
		Service: {},
		Bind: {},
		View: {},
		Modal: {},
		Sheet: {},
		Component: {},
	};
	const ctrlFactory = (ctrlName, opt, after) => {
		const stoge = local[ctrlName];
		if(typeof opt === 'string') return stoge[opt];

		const {name} = opt;
		stoge[name] = new classes[ctrlName](opt);
		document.addEventListener('DOMContentLoaded', () => {
			after && after(stoge[name]);
		});

		return stoge[name];
	};

	return new class {
		constructor() {
			const info = document.querySelector('[data-app-info]');
			const appInfo = info &&
				info.dataset.appInfo &&
				info.dataset.appInfo
				.replace(/'/g,'"')
				.replace(/\n/g, '');
			this._info = JSON.parse(appInfo) || {};
	
			// modal:: alert
			this.modal({
				name: 'modalAlert',
				tpl: this._info.alert,
				html: this._info.alert ? '' : lib.htmlAlert(),
			}, ctrl => {
				ctrl.vo = { msg: '' };
				ctrl.onload = prm => ctrl.vo.msg(prm);
				ctrl.on.close = () => ctrl.close();
			});
			// modal:: confirm
			this.modal({
				name: 'modalConfirm',
				tpl: this._info.confirm,
				html: this._info.confirm ? '' : lib.htmlConfirm(),
			}, ctrl => {
				ctrl.vo = { msg: '', yes: '', no: '' };
				ctrl.onload = ({msg, yes, no}) => {
					ctrl.vo.msg(msg);
					ctrl.vo.yes(yes || this._info.confirmYes || 'yes');
					ctrl.vo.no(no || this._info.confirmNo || 'no');
				};
				ctrl.on.yes = () => ctrl.close(true);
				ctrl.on.no = () => ctrl.close(false);
			});
			// sheet:: toast
			this.sheet({
				name: 'sheetToast',
				tpl: this._info.toast,
				html: this._info.toast ? '' : lib.htmlToast(),
			}, ctrl => {
				ctrl.vo = { msg: '' };
				ctrl.onload = ({msg, tm}) => {
					ctrl.vo.msg(msg);
					setTimeout(() => ctrl.close(), tm || 3000);
				};
			});
			// directive:: focus
			this.directive('focus', () => ({
				init(el, vl) {
					setTimeout(() => el.focus(), 10);
				},
			}));
			// service:: util
			this.service('util', obj => {
				Object.assign(obj, util);
			});
	
			document.addEventListener('DOMContentLoaded', () => {
				const body = document.body;
				const dailog = document.createElement('div');
				dailog.setAttribute('data-app-dailog', '');
				dailog.innerHTML = `<div data-app-sheet-dailog></div>
					<div data-app-modal-dailog></div>
					<div data-app-progress-dailog>
						<div data-app-progress-dimmed></div>
						<div data-app-progress-contents></div>
					</div>`;
				body.appendChild(dailog);
			});
		}

		service(nm, fn) {
			const {Service} = local;
			if(!fn) {
				if(!Service[nm]) throw `can not load service: [${nm}]`;

				return Service[nm];
			}

			Service[nm] = {};
			fn(Service[nm]);
		}

		bind(vl, fn) {
			return ctrlFactory('Bind', vl, (ctrl) => {
				fn && fn(ctrl);
				ctrl.load();
			});
		}

		view(vl, fn) {
			return ctrlFactory('View', vl, (ctrl) => {
				const {load} = vl;
				fn && fn(ctrl);
				load && ctrl.load();
			});
		}

		modal(vl, fn) {
			return ctrlFactory('Modal', vl, (ctrl) => {
				fn && fn(ctrl);
			});
		}

		sheet(vl, fn) {
			return ctrlFactory('Sheet', vl, (ctrl) => {
				fn && fn(ctrl);
			});
		}

		component(vl, fn) {
			return ctrlFactory('Component', vl, (ctrl) => {
				fn && fn(ctrl);
				ctrl.load();
			});
		}

		directive(nm, fn) {
			lib.directive(nm, fn);
		}

		config(ky, vl) {
			if(!vl) {
				return ky ? this._info[ky] : this._info;
			}

			this._info[ky] = vl;
		}

		alert(msg) {
			return app.modal('modalAlert').open(msg);
		}

		confirm(msg, {yes, no} = {}) {
			return app.modal('modalConfirm').open({msg, yes, no});
		}

		toast(msg, tm) {
			return app.sheet('sheetToast').open({msg, tm});
		}
	}
};
