module.exports = ({target, version=''}, {mode='production'}) => {
	let outdir = '/asset';
	const entry = {};
	const rules = [];
	const module = {rules};
	const rulesTransfile = {
		test: /\.js$/,
		use: [{
			loader: 'babel-loader',
			query: {
				presets: ['env'],
			},
		}],
	};
	const rulesSass = {
		test: /\.scss$|\.sass|\.css$/,
		use: [
			{
				loader: 'style-loader',
				options: { insertAt: 'top' },
			}, {
				loader: 'css-loader',
			}, {
				loader: 'sass-loader',
			},
		],
	};

	// 컴파일 대상
	if(target === 'app1') {
		// knockout
		entry[`ko-app.${version}`] = [
			'whatwg-fetch',
			'babel-polyfill',
			'./src/ko-app.js',
		];
		// vue
		entry[`vue-app.${version}`] = [
			'whatwg-fetch',
			'babel-polyfill',
			'./src/vue-app.js',
		];

		// service
		entry[`service-http.${version}`] = './src/service/http.js'

		rules.push(rulesTransfile);
	} else if(target === 'app2') {
		// knockout
		entry[`ko-app.${version}`] = './src/ko-app.js';
		// vue
		entry[`vue-app.${version}`] = './src/vue-app.js';

		// service
		entry[`service-http.${version}`] = './src/service/http.js'
	}

	rules.push(rulesSass);

	return {
		mode,
		module,
		entry,
		output: {
			path: __dirname + outdir,
			filename: '[name].js'
		},
	}
};
