module.exports = {
	entry: {
		app: './src/app.js',
		'ko-app-mdrn': './src/app-wrap-ko.js',
	},
	output: {
		path: __dirname + '/asset',
		filename: '[name].js'
	},
	mode: 'development',
	devServer: {
		contentBase: './dist',
	},
	module: {
		rules: [
			{
				test: /\.scss$|\.sass|\.css$/,
				use: [
					{
						loader: 'style-loader',
						options: {
							insertAt: 'top',
						},
					},
					{
						loader: 'css-loader',
					},
					{
						loader: 'sass-loader',
					},
				],
			},
		],
	},
 };