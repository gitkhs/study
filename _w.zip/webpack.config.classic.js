module.exports = {
	entry: {
		app: './src/app.js',
		'ko-app-clss': [
			'whatwg-fetch',
			'babel-polyfill',
			'./src/app-wrap-ko.js',
		],
	},
	output: {
		path: __dirname + '/asset',
		filename: '[name].js'
	},
	mode: 'development',
	devServer: {
		contentBase: './dist',
	},
	module: {
		rules: [
			{
				test: /\.js$/,
				use: [
					{
						loader: 'babel-loader',
						query: {
							presets: ['env'],
						},
					},
				],
			},
			{
				test: /\.scss$|\.sass|\.css$/,
				use: [
					{
						loader: 'style-loader',
						options: {
							insertAt: 'top',
						},
					},
					{
						loader: 'css-loader',
					},
					{
						loader: 'sass-loader',
					},
				],
			},
		],
	},
 };