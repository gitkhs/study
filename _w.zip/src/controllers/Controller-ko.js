module.exports = (() => {
	const localValue = new WeakMap();
	const ko = require('../libs/knockout-3.4.2');
	const {
		log,
		ajax,
		query,
		appQuery,
		appElement,
	} = require('../utils');
	const val = (obj, vl) => (vl ? Object.assign(localValue.get(obj), vl) : localValue.get(obj));
	const error = ({_clsName, _name}, ...vl) => {
		throw (_name ? `[${_clsName}::${_name}] ` : '') + vl.join(',');
	};

	return class Controller {
		constructor({name: _name, tpl: _tpl, html: _html}) {
			const _clsName = this.constructor.name;
			_name || error({}, `${_clsName} invalid name => ${_clsName.toLowerCase()}({name: ''}, function)`);
			_html || _tpl || error({}, `${_clsName} invalid template => ${_clsName.toLowerCase()}({name: '', html: 'template tag'}, function) or ${_clsName.toLowerCase()}({name: '', tpl: 'template url'}, function)`);

			localValue.set(this, {
				_name,
				_tpl,
				_html,
				_clsName,
				_call: {},
				_vo: {},
				_on: {},
				_bindOn: {},
				_bindVo: {},
			});
		}

		// 클래스 멤버변수 용
		member(vl) {
			return val(this, vl);
		}

		// 로그
		log(...vl) {
			const {_name, _clsName} = val(this);
			log(`%c${_clsName}::${_name}`, 'font-weight:bold', ...vl, '\n\n');
		}

		// 포커스처리를 위한 DOM 객체
		prifixTarget(evt = {}) {
			const _target = typeof evt === 'string' ? query(evt) : evt.target;
			_target && val(this, { _target });

			return this;
		}

		// 화면 랜더링
		async render({created, append=true} = {}) {
			const {
				_parent,
				_clsName,
				_tpl,
				_html,
				_name,
				_bindOn: on,
				_bindVo: vo,
			} = val(this);
			const selector = `app${_clsName}`;
			const dom = appQuery({ [selector]: _name }, _parent) ||
				appElement({ [selector]: _name });
			const template = _html || await ajax(_tpl);

			val(this, {
				_html: template,
			});

			dom.innerHTML = template;
			append && _parent.appendChild(dom);

			ko.cleanNode(dom);
			ko.applyBindings({ vo, on }, dom);

			created && created();
		}

		// 화면 이벤트 바인딩을 위한 함수 세팅
		event(name, fn) {
			const {_bindOn, _on} = val(this);

			_on[name] = fn;
			Object.assign(_bindOn, {
				[name]: (...vl) => (fn && fn(vl[vl.length-1], ...vl)),
			});
		}

		// 화면변수 관리 객체 세팅
		set vo(vl) {
			const isObject = vl => vl instanceof Object && !Array.isArray(vl);
			const observable = (vl) => Object.entries(vl).reduce((vo, [ky, vl]) => {
				if(isObject(vl)) {
					vo[ky] = observable(vl);
					return vo;
				}

				vo[ky] = Array.isArray(vl) ? ko.observableArray(vl) : ko.observable(vl);
				return vo;
			}, {});

			isObject(vl) || error(val(this), '"vo" type error ==> type is Object');
			
			val(this, {
				_bindVo: observable(vl),
			});
		}

		// 화면변수 관리 객체 반환
		get vo() {
			return val(this)._bindVo;
		}

		// 이벤트 관리 객체
		get on() {
			return val(this)._on;
		}

		// 호출 함수 등록
		get call() {
			return val(this)._call;
		}

		// 컨트롤러 로드 함수 세팅
		set onload(_onload) {
			val(this, {
				_onload,
			});
		}
	};
})();