module.exports = (lib) => {
	const Controller = require(`./Controller-${lib}`);
	const ko = require('../libs/knockout-3.4.2');
	const {
		ajax,
		snake,
	} = require('../utils');

	return class Component extends Controller {
		// 클래스 멤버변수 용
		member() {
		}

		// 화면 로드
		load(param) {
			const {
				_name,
				_onload,
				_html: template,
				_bindVo: vo,
				_bindOn: on,
			} = super.member();

			ko.components.register(snake(_name), {
				template,
				viewModel: function() {
					this.vo = vo;
					this.on = on;
					_onload && _onload(param);
				},
			});
		}
	};
};