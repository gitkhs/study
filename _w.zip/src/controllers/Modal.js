module.exports = (lib) => {
	const Controller = require(`./Controller-${lib}`);
	const {
		appQuery,
		appElement,
		appSelector,
	} = require('../utils');
	const makeDimmed = () => {
		const parent = appQuery({ appModalDailog: '' }, document.body);
		const dimmed = appQuery({ appModalDimmed: '' }, parent);
		dimmed && dimmed.remove();
		parent.lastChild && parent.insertBefore(
			appElement({ appModalDimmed: '' }),
			parent.lastChild
		);
	};

	return class Modal extends Controller {
		constructor(vl) {
			super(vl);

			super.member({
				_parent: appQuery({ appModalDailog: '' }, document.body),
			});
		}

		// 클래스 멤버변수 용
		member() {
		}

		// 모달 오픈
		async open(param) {
			const {_parent, _name, _onload} = super.member();
			const created = () => {
				const dom = appQuery({ appModal: _name }, _parent);
				dom.setAttribute(appSelector({ appModalOn: '' }), '');
				makeDimmed();
	
				_onload && _onload(param);
			};

			await this.render({created});

			return new Promise((_close, reject) => {
				super.member({ _close });
			});
		}

		// 모달 종료
		close(param) {
			const {_parent, _name, _close, _target} = super.member();

			const dom = appQuery({ appModal: _name }, _parent);
			dom.setAttribute(appSelector({ appModalOff: '' }), '');
			dom.addEventListener('animationend', (ev) => {
				dom.remove();
				makeDimmed();
				_target && _target.focus();
			});

			_close && _close(param);
		}
	};
};