module.exports = lib => {
	return {
		Bind: require('./Bind')(lib),
		View: require('./View')(lib),
		Modal: require('./Modal')(lib),
		Sheet: require('./Sheet')(lib),
		Component: require('./Component')(lib),
	};
};