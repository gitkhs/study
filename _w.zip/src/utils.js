const log = (...vl) => {
	const local = /127.0.0.1|localhost/.test(location.hostname);
	(local || hash.log) && console && console.log(...vl);
};
const error = vl => { throw vl; };

// data utils
// ================================================== //
const entries = vl => Object.entries(vl);
const left = (vl, sz) => vl.substr(0, sz);
const right = (vl, sz) => vl.substr(vl.length - sz);
const lpad = (vl, sz, ch=' ') => (vl.length >= sz ? vl : right(ch.repeat(sz) + vl, sz));
const rpad = (vl, sz, ch=' ') => (vl.length >= sz ? vl : left(vl + ch.repeat(sz), sz));
const date = (vl = 'yyyymmdd', dt = new Date) => {
	return vl.replace(/(yyyy|yy|mm|dd|h24|hh|mi|ss|ms|a\/p)/gi, (vl) => {
		switch(vl) {
		case 'yyyy': return dt.getFullYear();
		case 'yy': return lpad(dt.getFullYear(), 2, '0');
		case 'mm': return lpad(dt.getMonth()+1, 2, '0');
		case 'dd': return lpad(dt.getDate(), 2, '0');
		case 'h24': return lpad(dt.getHours(), 2, '0');
		case 'hh': return lpad(dt.getHours()%12 || 12, 2, '0');
		case 'mi': return lpad(dt.getMinutes(), 2, '0');
		case 'ss': return lpad(dt.getSeconds(), 2, '0');
		case 'ms': return lpad(dt.getMilliseconds(), 3, '0');
		default: return '';
		}
	});
};

const json = vl => (/^{.+?}$|^\[.+?\]$/.test(vl) ? JSON.parse(vl) : vl);
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`);
const camel = vl => vl.replace(/-\w/g, vl => vl.toUpperCase().substr(1));
const ajax = async (url, {method='GET', headers={}, body={}} = {}) => {
	return await fetch(url, { method, headers, body }).then(rs => {
		const contentType = rs.headers.get('Content-Type');

		if(/text/.test(contentType)) return rs.text();
		if(/json/.test(contentType)) return rs.json();
		return rs.blob();
	});
};
const promise = fn => new Promise(fn);
const promiseAll = vl => Promise.all(vl);


// DOM & browser utils
// ================================================== //
const hash = ((vl) => (
	vl && json(`{"${vl}"}`) || {}
))(location.hash.substr(1).replace(/&/g, '","').replace(/=/g, '":"'));
const query = (v, dom = document) => dom.querySelector(v);
const queryAll = (v, dom = document) => dom.querySelectorAll(v);
const element = (tag, {html, text, attr, css, on} = {}) => {
	const dom = document.createElement(tag);

	html ? (dom.innerHTML = html) : (text && (dom.innerText = text));
	attr && Object.entries(attr).forEach(([k, v]) => dom.setAttribute(k, v));
	css && Object.entries(css).forEach(([k, v]) => (dom.style[k] = v));
	on && Object.entries(on).forEach(([k, v]) => dom.addEventListener(k, v));

	return dom;
};

// App utils
// ================================================== //
const prefixData = vl => `data-${vl}`;
const appinfo = (dom = document.body) => {
	const app = dom.dataset.app && dom.dataset.app.replace(/'/g,'"');
	return app && json(app.replace(/\n/g, ''));
};
const appSelector = (vl) => {
	const sel = Object.entries(vl)
		.map(([ky, vl]) => (vl ? `${snake(ky)}=${vl}` : snake(ky)))
		.join('');
	return prefixData(sel);
};
const appQuery = (vl, dom) => {
	const sel = appSelector(vl);
	return query(`[${sel}]`, dom) || query(`[${sel.replace('data-', '')}]`, dom)
};
const appQueryAll = (vl, dom) => {
	const sel = appSelector(vl);
	const all = queryAll(`[${sel}]`, dom);
	return all.length ? all : queryAll(`[${sel.replace('data-', '')}]`, dom)
};
const appElement = (vl) => {
	const attr = Object.entries(vl)
		.reduce((rs, [ky, vl]) => Object.assign(rs, {
			[prefixData(snake(ky))]: vl
		}), {});

	return element('div', {attr });
};


module.exports = {
	log,
	error,

	entries,
	left,
	right,
	lpad,
	rpad,
	date,

	json,
	snake,
	camel,
	ajax,
	promise,
	promiseAll,

	hash,
	element,
	query,

	appinfo,
	appSelector,
	appQuery,
	appQueryAll,
	appElement,
};
