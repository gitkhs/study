require('./app.scss');

var json = function(vl) {
	return (/^{.+?}$|^\[.+?\]$/.test(vl) ? JSON.parse(vl) : vl);
};
var appinfo = function(dom) {
	dom = dom || document.body;
	var app = dom.dataset.app && dom.dataset.app.replace(/'/g,'"');
	return app && json(app.replace(/\n/g, ''));
};

document.addEventListener('DOMContentLoaded', function() {
    var body = document.body;
    var head = document.head;
	var config = appinfo();
	var jsname = (function() {
		var path = config.path || '/';
		var name = config.name || '';

        try {
			if(typeof Symbol == 'undefined') return path + name + '-clss.js';
			eval('class x {}'), eval('var x = x=>x');
		} catch(e){
			return path + name + '-clss.js';
		}
	
		return path + name + '-mdrn.js';
	})();
	

	var appScript = document.createElement('script');
	appScript.setAttribute('src', jsname);
    head.appendChild(appScript);

	console.log('--doc ready--', JSON.stringify(config, null, '\t'));
	console.log(jsname);
});

/*
const json = vl => (/^{.+?}$|^\[.+?\]$/.test(vl) ? JSON.parse(vl) : vl);
const appinfo = (dom = document.body) => {
	const app = dom.dataset.app && dom.dataset.app.replace(/'/g,'"');
	return app && json(app.replace(/\n/g, ''));
};
const entries = vl => Object.keys(vl).map(([k, v]) => ([v, vl[k]]));
const element = (tag, {html, text, attr, css, on} = {}) => {
	const dom = document.createElement(tag);

	html ? (dom.innerHTML = html) : (text && (dom.innerText = text));
	attr && entries(attr).forEach(([k, v]) => dom.setAttribute(k, v));
	css && entries(css).forEach(([k, v]) => (dom.style[k] = v));
	on && entries(on).forEach(([k, v]) => dom.addEventListener(k, v));

	return dom;
};

document.addEventListener('DOMContentLoaded', function() {
    const body = document.body;
    const head = document.head;
    const config = appinfo();
	const jsname = (() => {
        const {path, name} = config;

        try {
			if(typeof Symbol == 'undefined') return `${path||''}/${name}-clss.js`;
			eval('class x {}'), eval('var x = x=>x');
		} catch(e){
			return `${path||''}${name}-clss.js`;
		}
	
		return `${path||''}${name}-mdrn.js`;
	})();

    head.appendChild(element('script', {
        attr: { src: jsname },
    }));

	body.appendChild(element('div', {
		attr: { 'data-app-dailog': '' },
		html: `<div data-app-sheet-dailog></div>
		<div data-app-modal-dailog></div>
		<div data-app-progress-dailog>
			<div data-app-progress-dimmed></div>
			<div data-app-progress-contents></div>
        </div>`,
	}));

});
*/