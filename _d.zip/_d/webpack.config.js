module.exports = ({target, version=''}, {mode='production'}) => {
	let outdir = '/asset';
	const entry = {};
	const rules = [];
	const module = {rules};
	const rulesTransfile = {
		test: /\.js$/,
		use: [{
			loader: 'babel-loader',
			query: {
				presets: ['env'],
			},
		}],
	};
	const rulesSass = {
		test: /\.scss$|\.sass$|\.css$/,
		use: [
			{
				loader: 'style-loader',
				options: { insertAt: 'top' },
			}, {
				loader: 'css-loader',
			}, {
				loader: 'sass-loader',
			},
		],
	};

	// 컴파일 대상
	// // knockout
	// entry[`ko-app.${version}`] = [
	// 	'whatwg-fetch',
	// 	'babel-polyfill',
	// 	'./src/ko-app.js',
	// ];
	// vue
	entry[`makeup-vue.${version}`] = [
		'whatwg-fetch',
		'babel-polyfill',
		'./src/app-vue.js',
	];
	entry['svc-http'] = './src/service/http.js';
	entry['svc-utils'] = './src/service/utils.js';
	entry['svc-material'] = './src/service/material.js';

	rules.push(rulesTransfile);
	rules.push(rulesSass);

	return {
		mode,
		module,
		entry,
		output: {
			path: __dirname + outdir,
			filename: '[name].js'
		},
	}
};
