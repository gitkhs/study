const Vue = require('./libs/vue.min');
const Makeup = require('./app/app');
const Binder = class Binder {
	attach({selector, vo, on, listener}) {
		new Vue({
			el: selector,
			data: { vo, on },
			created() { listener && listener(); },
		});
	}

	component({node, html, on, vo, listener}) {
		Vue.component(node, {
			template: html,
			data() { return {vo, on}; },
			created() { listener && listener(); }
		});
	}

	directive(name, procedure) {
		if(name && procedure) {
			const {init, update} = procedure();

			Vue.directive(name, {
				inserted(el, vl) {
					init && init(el, vl.value);
				},
				update(el, vl) {
					update && update(el, vl.value);
				}
			});
		}
	}
};

window.mk = new Makeup(new Binder());
