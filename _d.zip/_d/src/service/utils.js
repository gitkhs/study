mk.service('utils', () => {
	const left = (vl, sz) => vl.substr(0, sz);
	const right = (vl, sz) => vl.substr(vl.length > sz ? vl.length - sz : 0);
	const lpad = (vl, sz, ch=' ') => (vl.length >= sz ? vl : right(ch.repeat(sz) + vl, sz));
	const rpad = (vl, sz, ch=' ') => (vl.length >= sz ? vl : left(vl + ch.repeat(sz), sz));
	const formatDate = (vl = 'yyyymmdd', dt = new Date) => {
		return vl.replace(/(yyyy|yy|mm|dd|h24|hh|mi|ss|ms|a\/p)/gi, (vl) => {
			switch(vl) {
			case 'yyyy': return dt.getFullYear();
			case 'yy': return lpad(dt.getFullYear(), 2, '0');
			case 'mm': return lpad(dt.getMonth()+1, 2, '0');
			case 'dd': return lpad(dt.getDate(), 2, '0');
			case 'h24': return lpad(dt.getHours(), 2, '0');
			case 'hh': return lpad(dt.getHours()%12 || 12, 2, '0');
			case 'mi': return lpad(dt.getMinutes(), 2, '0');
			case 'ss': return lpad(dt.getSeconds(), 2, '0');
			case 'ms': return lpad(dt.getMilliseconds(), 3, '0');
			default: return '';
			}
		});
	};
		
	return {
		left, right, lpad, rpad, formatDate,
		promise(fn) {
			return new Promise(fn);
		},
		promiseAll(arr) {
			return Promise.all(arr);
		},
		json(vl) {
			return typeof vl === 'string' ? JSON.parse(vl) : JSON.stringify(vl);
		},
		entries(vl) {
			return Object.entries(vl);
		},
		assign(ass, vl) {
			return Object.assign(ass, vl);
		},
		snakeCase(vl) {
			return vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`);
		},
		camelCase(vl) {
			return vl.replace(/-\w/g, vl => vl.toUpperCase().substr(1));
		},
	};
});