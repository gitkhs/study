mk.service('http', () => {
	const SHOW = Symbol('SHOW'), HIDE = Symbol('HIDE');
	const REQUEST = Symbol('REQUEST'), RESPONSE = Symbol('RESPONSE'), ERROR = Symbol('ERROR');
	const log = (proto, url, vl, body) => {
		const subject = {
			[REQUEST]: [`%c[REQUEST] ${url}`, 'font-weight:bold; color:#000;'],
			[RESPONSE]: [`%c[RESPONSE] ${url}`, 'font-weight:bold; color:#00f;'],
			[ERROR]: [`%c[ERROR] ${url}`, 'font-weight:bold; color:#f00;'],
		}[proto];
		const stringify = (vl, body) => {
			if(body) return body;
			if(typeof vl === 'object') return JSON.stringify(vl, '', '  ');
			return '';
		};
		const {debug} = mk.config();
		if(!(/127.0.0.1|localhost/.test(location.hostname) || debug)) return;

		console.log(...subject, vl, stringify(vl, body));
	};
	const progress = vl => {
		const prog = document.querySelector('[data-app-progress-dailog]');
		prog.style.display = vl === SHOW ? 'block' : 'none';
	};
	const ajax = async (url, {method='GET', headers, body} = {}) => {
		return await fetch(url, { method, headers, body }).then(rs => {
			const contentType = rs.headers.get('Content-Type');
	
			if(/text/.test(contentType)) return rs.text();
			if(/json/.test(contentType)) return rs.json();
			return rs.blob();
		});
	};
	const rest = ({method, url, prm}) => {
		return new Promise((resolve, reject) => {
			progressStat === HIDE && progress(SHOW);
			log(REQUEST, url, prm);

			ajax(url, {
                method,
                body: prm && encodeURIComponent(JSON.stringify(prm))
            }).then((data) => {
				progressStat === HIDE && progress(HIDE);
				log(RESPONSE, url, data);

				resolve(data);
            }).catch((err) => {
				progressStat === HIDE && progress(HIDE);
				log(ERROR, url, err);

				reject(err);
            });
        });
	};
	const makeParam = vl => Object.entries(vl).map(([ky, vl]) => {
		return [
			encodeURIComponent(ky),
			encodeURIComponent(
				vl instanceof Object ? JSON.stringify(vl) : vl
			),
		].join('=');
	}).join('&');
	const submit = (url, prm) => {
		const body = makeParam(prm);

        return new Promise((resolve, reject) => {
			progressStat === HIDE && progress(SHOW);
			log(REQUEST, url, prm, body);

			ajax(url, {
                body,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
                }
            }).then((data) => {
				progressStat === HIDE && progress(HIDE);
				log(RESPONSE, url, data);

				resolve(data);
            }).catch((err) => {
				progressStat === HIDE && progress(HIDE);
				log(ERROR, url, err);

				reject(err);
            });
        });
	};
	const download = (url) => {
		progressStat === HIDE && progress(SHOW);
		log(REQUEST, url);

        ajax(url).then((blob) => {
			progressStat === HIDE && progress(HIDE);
			log(RESPONSE, url, blob);
            if(blob.size <= 0) return;

			const filename = url.split('/');
			const agent = navigator.userAgent.toLowerCase();
			if(navigator.appName == 'Netscape' && (agent.includes('trident') || agent.includes('msie'))) {
				window.navigator.msSaveBlob(blob, filename.pop());
			} else {
				const link = document.createElement('a');
				link.setAttribute('href', (window.URL || window.webkitURL).createObjectURL(blob));
				link.setAttribute('download', filename.pop());
				link.click();
				link.remove();
			}
        }).catch((err) => {
			progressStat === HIDE && progress(HIDE);
			log(ERROR, url, err);
        });
	};
	const upload = (url, selector) => {
		const form = document.querySelector(selector);
		const files = form.querySelectorAll('input[type=file]');
		const values = [...files].reduce((pr, cr) => {
			cr.value && pr.push(cr.value);
			return pr;
		}, []);


		return new Promise((resolve, reject) => {
			if(values.length < 1) {
				progressStat === HIDE && progress(HIDE);
				log(ERROR, url, 'invalid file');
				reject('invalid file');
				return;
			};

			progressStat === HIDE && progress(SHOW);
			log(REQUEST, url);

			ajax(url, {
				method: 'POST',
				body: new FormData(form),
			}).then((data) => {
				progressStat === HIDE && progress(HIDE);
				log(RESPONSE, url, data);

				resolve(data);
			}).catch((err) => {
				progressStat === HIDE && progress(HIDE);
				log(ERROR, url, err);

				reject(err);
			});
		});
	};

	// process
	// ================================================== //
	require('./http.scss');
	document.addEventListener('DOMContentLoaded', () => {
		const dailog = document.querySelector('[data-app-dailog]');
		const prog = document.createElement('div');
		prog.setAttribute('data-app-progress-dailog', '');
		prog.innerHTML = '<div data-app-progress-dimmed></div><div data-app-progress-contents></div>';
		dailog.appendChild(prog);
	});

	let progressStat = HIDE;
	return {
		submit,
		download,
		upload,
		set loading(vl) {
			progressStat = vl === true ? SHOW : HIDE;
			progress(progressStat);
		},
		get(url, prm) {
			return rest({url: (prm ? url + '?' + makeParam(prm) : url), method: 'GET'});
		},
		post(url, prm) {
			return rest({url, prm, method: 'POST'});
		},
		rest(method, url, prm) {
			rest({method, url, prm});
		},
	};
});
