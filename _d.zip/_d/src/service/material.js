mk.service('material', () => {
	const typePhone = Symbol('phone'), typeDesktop = Symbol('desktop');

	// process
	// ================================================== //
	require('../libs/mdc/material-components-web.min.css');
	const mdc = require('../libs/mdc/material-components-web.min');
	window.mdc = mdc;
	document.addEventListener('DOMContentLoaded', () => {
		document.body.style.cssText += 'margin:0; padding:0;';
	});

	return {
		get typePhone() { return typePhone; },
		get typeDesktop() { return typeDesktop; },
		autoInit() {
			mdc.autoInit();
		},
		drawer(vl) {
			return mdc.drawer.MDCDrawer.attachTo(document.querySelector(vl));
		},
		list(vl) {
			return mdc.list.MDCList.attachTo(document.querySelector(vl));
		},
		getMedia() {
			if(window.innerWidth < 780) return typePhone;
			return typeDesktop;
		},
	};
});
