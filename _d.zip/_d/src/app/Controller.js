const PRIV = new WeakMap();
const val = (ky, vl) => {
	const con = PRIV.get(ky);
	return vl ? Object.assign(con, vl) : con;
};
const ajax = async url => await fetch(url).then(rs=>rs.text());
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`);

const Controller = class Controller {
	constructor({binder, name, procedure}) {
		const config = {
			name,
		};

		PRIV.set(this, {
			config,
			binder,
			name,
			on: {},
			vo: {},
		});

		procedure && procedure(this);
	}

	async open(url, prm) {
		const {tpl, html} = val(this);
		const template = url && await ajax(url);

		val(this, {
			tpl: url,
			html: tpl === url ? html : template,
		});

		return await this._open(prm);
	}
	_open() { throw 'open is override'; }

	close(prm) {
		this._close(prm);
	}
	_close() { throw 'close is override'; }

	config(ky, vl) {
		const {config} = val(this);
		if(!ky) return config;
		if(!vl) return config[ky];

		config[ky] = vl;
		return config;
	}

	get name() { return val(this).name; }
	set vo(vo) { val(this, { vo }); };
	get vo() { return val(this).vo; }
	get on() { return val(this).on; }
	set onload(onload) { val(this, { onload }); }
	get isOpen() { return val(this).isOpen; };
};

const View = class View extends Controller {
	async _open(prm) {
		const {binder, name, html, onload, on, vo} = val(this);
		const selector = `[data-app-view=${snake(name)}]`;
		const self = document.body.querySelector(selector) ||
			document.body.querySelector(selector.replace('data-', ''));
		const listener = () => onload && onload(prm);

		self.innerHTML = html;
		binder.attach({selector, vo, on, listener});

		val(this, { isOpen: true });
	}

	get module() { return 'View'; }
};

const Modal = class Modal extends Controller {
	async _open(prm) {
		const {binder, name, html, onload, on, vo} = val(this);
		const prefix = 'data-app-modal';
		const parent = document.body.querySelector(`[${prefix}-dailog]`);
		const self = document.createElement('div');
		const listener = () => onload && onload(prm);
		const dimmed = parent => {
			const dimmed = document.querySelector(`[${prefix}-dimmed]`);
			const append = () => {
				const dimmed = document.createElement('div');
				dimmed.setAttribute(`${prefix}-dimmed`, '');
				return dimmed;
			};

			dimmed && dimmed.parentNode.removeChild(dimmed);
			parent.lastChild && parent.insertBefore(
				append(),
				parent.lastChild
			);
		};

		self.setAttribute(`${prefix}`, snake(name));
		self.setAttribute(`${prefix}-on`, '');
		self.innerHTML = html;

		parent.appendChild(self);
		dimmed(parent);

		binder.attach({
			vo, on, listener,
			selector: `[${prefix}=${snake(name)}]`,
		});

		val(this, { dimmed, isOpen:true, });
		return new Promise((onclose) => val(this, { onclose }));
	}

	_close(prm) {
		const {name, dimmed, onclose} = val(this);
		const prefix = 'data-app-modal';
		const parent = document.body.querySelector(`[${prefix}-dailog]`);
		const self = parent.querySelector(`[${prefix}=${snake(name)}]`);

		self.setAttribute(`${prefix}-off`, '');
		self.addEventListener('animationend', evt => {
			self.parentNode.removeChild(self);
			dimmed(parent);
		});

		onclose && onclose(prm);
		val(this, { isOpen:false, });
	}

	get module() { return 'Modal'; }
};

const Sheet = class Sheet extends Controller {
	constructor(vl) {
		super(vl);
	}

	async _open(prm) {
		const {binder, name, html, onload, on, vo} = val(this);
		const prefix = 'data-app-sheet';
		const parent = document.body.querySelector(`[${prefix}-dailog]`);
		const listener = () => onload && onload(prm);

		const curr = parent.querySelector(`[${prefix}=${snake(name)}]`);
		curr && parent.removeChild(curr);

		const self = document.createElement('div');
		self.setAttribute(`${prefix}`, snake(name));
		self.setAttribute(`${prefix}-on`, '');
		self.innerHTML = html;
		parent.appendChild(self);

		binder.attach({
			vo, on, listener,
			selector: `[${prefix}=${snake(name)}]`,
		});

		val(this, { isOpen:true, });
		return new Promise((onclose) => val(this, { onclose }));
	}

	_close(prm) {
		const {name, onclose} = val(this);
		const prefix = 'data-app-sheet';
		const parent = document.body.querySelector(`[${prefix}-dailog]`);
		const self = parent.querySelector(`[${prefix}=${snake(name)}]`);

		self.setAttribute(`${prefix}-off`, '');
		self.addEventListener('animationend', evt => {
			self.parentNode.removeChild(self);
		});

		onclose && onclose(prm);
		val(this, { isOpen:false, });
	}

	get module() { return 'Sheet'; }
};


const Component = class Component extends Controller {
	async _open(prm) {
		const {binder, name, html, onload, on, vo} = val(this);
		const listener = () => onload && onload(prm);

		binder.component({node:snake(name), html, on, vo, listener});

		return this;
	}

	get module() { return 'Component'; }
};

module.exports = {
	Controller,
	View,
	Modal,
	Sheet,
	Component,
};