require('./app.scss');
const modules = require('./Controller');
const ctrlFactory = ({module, name, procedure, binder}) => {
	const inst = lc[module.toLowerCase()];
	const Ctrl = modules[module];
	if(!procedure) return inst[name];

	const ctrl = new Ctrl({
		name,
		procedure,
		binder,
	});

	return inst[name] = ctrl;
};

const lc = {
	view: {},
	modal: {},
	sheet: {},
	component: {},
	service: {},
	config: {},
};

module.exports = class Makeup {
	constructor(binder) {
		Object.assign(this, {
			binder,
		});

		// focus directive
		this.directive('focus', () => ({
			init(el, vl) {
				setTimeout(() => el.focus(), 10);
			},
		}));
		this.modal('modalAlert', ctrl => {
			ctrl.vo = { msg: '', ok: '' };
			ctrl.onload = ({msg, ok}) => { ctrl.vo.msg = msg, ctrl.vo.ok = ok; };
			ctrl.on.ok = () => ctrl.close();
		});
		this.modal('modalConfirm', ctrl => {
			ctrl.vo = { msg: '', yes: '', no: '' };
			ctrl.onload = ({msg, yes, no}) => {
				ctrl.vo.msg = msg;
				ctrl.vo.yes = yes;
				ctrl.vo.no = no;
			};
			ctrl.on.yes = () => ctrl.close(true);
			ctrl.on.no = () => ctrl.close(false);
		});
		this.sheet('sheetToast', ctrl => {
			ctrl.vo = { msg: '' };
			ctrl.onload = ({msg, time}) => {
				ctrl.vo.msg = msg;
				setTimeout(() => ctrl.close(), time);
			};
		});

		document.addEventListener('DOMContentLoaded', () => {
			const main = document.createElement('section');
			main.setAttribute('data-app-view', 'main');

			const dailog = document.createElement('section');
			dailog.setAttribute('data-app-dailog', '');
			dailog.innerHTML = '<div data-app-sheet-dailog></div><div data-app-modal-dailog></div>';

			document.body.appendChild(main);
			document.body.appendChild(dailog);
		});
	}

	log(ctrl, ...vl) {
		if(!(/127.0.0.1|localhost/.test(location.hostname) || lc.config.debug)) return;

		const {Controller} = modules;
		if(ctrl instanceof Controller) {
			const {module, name} = ctrl;
			console.log(`%c[${module}::${name}]`, 'font-weight:bold', ...vl);
		} else {
			console.log(ctrl, ...vl);
		}
	}

	service(name, procedure) {
		if(!procedure) return lc.service[name];
		return lc.service[name] = procedure();
	}

	main(tpl, procedure) {
		document.addEventListener('DOMContentLoaded', () => {
			if(typeof tpl === 'function') {
				this.view('main', tpl).open('');
			} else {
				this.view('main', procedure).open(tpl);
			}
		});
	}

	view(name, procedure) {
		return ctrlFactory({
			name,
			procedure,
			module: 'View',
			binder: this.binder,
		});
	}

	modal(name, procedure) {
		return ctrlFactory({
			name,
			procedure,
			module: 'Modal',
			binder: this.binder,
		});
	}

	sheet(name, procedure) {
		return ctrlFactory({
			name,
			procedure,
			module: 'Sheet',
			binder: this.binder,
		});
	}

	component(name, procedure) {
		return ctrlFactory({
			name,
			procedure,
			module: 'Component',
			binder: this.binder,
		});
	}

	set loadComponent(vl) {
		vl && vl.forEach(vl => {
			lc.component[vl.name] && lc.component[vl.name].open(vl.tpl)
		});
	}

	directive(name, procedure) {
		this.binder.directive(name, procedure);
	}

	config(ky, vl) {
		if(!ky) return lc.config;
		if(!vl) return lc.config[ky];

		lc.config[ky] = vl;
		return lc.config;
	}

	getTpl(vl) {
		if(window.innerWidth > 780) return vl;

		vl = vl.split('.');
		return vl.concat('m', vl.pop()).join('.')
	}

	alert(msg, ok) {
		const {alert:{tpl, btnOk='OK'}} = lc.config;
		return this.modal('modalAlert').open(tpl, {
			msg,
			ok: ok || btnOk
		});
	}
	confirm(msg, yes, no) {
		const {confirm:{tpl, btnYes='YES', btnNo='NO'}} = lc.config;
		return this.modal('modalConfirm').open(tpl, {
			msg,
			yes: yes || btnYes,
			no: no || btnNo,
		});
	}
	toast(msg, tm) {
		const {toast:{tpl, time=3000}} = lc.config;
		return this.sheet('sheetToast').open(tpl, {
			msg,
			time: tm || time,
		});
	}
};