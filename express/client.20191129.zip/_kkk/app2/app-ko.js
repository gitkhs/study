(_=>{
const {assign, entries, defineProperties} = Object;
const rmDash = vl=> vl.replace(/(?:-(\w))/g, (_, $1)=> $1.toUpperCase());
const pascal = vl=> rmDash(vl).replace(/^[\w]/, v=> v.toUpperCase());
const camel = vl=> rmDash(vl).replace(/^[\w]/, v=> v.toLowerCase());
const snake = vl=> vl.replace(/[A-Z]/g, v=> `-${v.toLowerCase()}`).replace(/^-/, '');

new class {
	constructor() {
		App && assign(App, {_view:this});
	}
	
	bindElement(el, {vo, on, ctrl}) {
		ko.cleanNode(el);
		ko.applyBindings({vo, on, ctrl}, el);
	}
	value(vl) {
		const vo = Array.isArray(vl) ? ko.observableArray(vl) : ko.observable(vl);
		return defineProperties(vo, {
			$data: {get(){return ko.unwrap(vo)}, set(vl){vo(vl)}},
			$length: {get(){return ko.unwrap(vo).length}}
		});
	}
	event(fn) {
		const handle = {};
		fn && fn(handle);
		return entries(handle).reduce((handle, [ky, vl])=> assign(handle, {
			[ky](...arg) {vl(arg.pop(), ...arg)}
		}), handle);
	}
	directive(name, fn) {
		ko.bindingHandlers[name] = {init(el, vl, bind, vo, context) {
			const {ctrl} = vo;
			const {$parents:[parent]} = context;
			fn(parent ? parent.ctrl : ctrl, el, vl());
		}};
	}
	component({name, template, create, component}) {
		const {value, event} = this;
		const ViewModel = function({$data:{ctrl:parent}}, com) {
			this.vo = {};
			this.on = {};
			this.value = value;
			this.event = event;
			create && create(component[parent.name]=this, parent);
		};
		const createViewModel = (_, {element})=> new ViewModel(ko.contextFor(element));
//		const {$data:{ctrl}} = ko.contextFor(element); // 모 컨트롤러 취득

		ko.components.register(snake(name), {template, viewModel:{createViewModel}});
	}
};
})();
