(_=>{
const utils = (_=>{
	const {assign} = Object;
	// object
	const clone = vl=> {
		if(Array.isArray(vl)) return vl.slice(0);
		else if(typeof vl == 'object') return assign({}, vl);
		else return vl;
	};
	const obj = {clone};

	// element
	const create = tg=> document.createElement(tg);
	const query = (vl, el)=> (el?el:document).querySelector(vl);
	const all = (vl, el)=> (el?el:document).querySelectorAll(vl);
	const el = {create, query, all};
	
	// date
	const datetime = (fm='YMDhhmissms', dt=new Date)=> {
		const zero = (vl, sz)=> vl.toString().padStart(sz, '0');
		const tf ={
			Y: zero(dt.getFullYear(), 4),
			M: zero(dt.getMonth()+1, 2),
			D: zero(dt.getDate(), 2),
			hh: zero(dt.getHours(), 2),
			mi: zero(dt.getMinutes(), 2),
			ss: zero(dt.getSeconds(), 2),
			ms: zero(dt.getMilliseconds(), 3)
		};
		return fm.replace(/Y|M|D|hh|mi|ss|ms/g, v=> tf[v]);
	};
	const today = datetime('YMD');
	const dt = {datetime, today};
	
	// url
	const nocache = (vl, q=/\?/, v=`?v=${today}`)=> (q.test(vl) ? vl.replace(q, v) : vl+v);
	const url = {nocache};

	// ajax
	const html = async ({html, url}={})=> {
		if(html) return html;
		else if(url) return await (await fetch(nocache(url))).text();
	}
	const ajax = {html};
	
	const isChrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
	return {obj, el, dt, url, ajax, isChrome};
})();

const error = vl=> {throw vl};
const {assign, entries} = Object;
const {obj, el, dt, url, ajax, isChrome} = utils;

















//------------------------------ //
// Layout
//------------------------------ //
const Layout = class {
	static GET({name, _init, _url}) {return new Layout({name, _init, _url})}
	constructor(vl) {
		this._el = null;
		this._open = null;
		this._close = null;
		this._ctrl = null;

		assign(this, vl);
		this._init && this._init(this);
	}

	set open(_open) {assign(this, {_open})}
	set close(_close) {assign(this, {_close})}

	setHtml(_html) {this._url || assign(this, {_html})}
	setUrl(_url) {this._url || assign(this, {_url})}
	getElement() {return this._el}
	setElement(_el) {assign(this, {_el})}
	setCtrl(_ctrl) {assign(this, {_ctrl})}
	async bind() {
		const {_open, _ctrl} = this;
		_open && _open(_ctrl, utils.el);

		const {_el, _html, _url} = this;
		if(!_el) return error(`can bind element: "${_ctrl.name}" element not defined`);
		if(!_html && !_url) return error(`"${_ctrl.name}" invalid template`);

		_el.innerHTML = await ajax.html({html:_html, url:_url});
	}
	unbind() {
		const {_close, _ctrl} = this;
		_close && _close(_ctrl, utils.el);
	}

	async _innerHtml() {
		const {_el, _html, _url, _ctrl} = this;
		if(!_el) return error(`can bind element: "${_ctrl.name}" element not defined`);

		const tpl = await ajax.html({html:_html, url:_url});
		if(!tpl) return error(`"${_ctrl.name}" invalid template`);
		_el.innerHTML = tpl;
	}
};

//------------------------------ //
// Controller
//------------------------------ //
const Controller = class {
	static GET({_app, _name, _create, _layout, _parent, _param}) {
		return new Controller({
			_app, _name, _create, _layout, _parent, _param,
			_type: 'Controller', _vo:{}, _on:{},
		});
	}
	constructor(vl) {
		assign(this, vl);

		const {_app, _name, _layout, _create} = vl;
		if(_app.isOpen(_name)) return error(`"${_name}" Controller is Open`);

		_app.addCtrl(_name);
		_layout.setCtrl(this);

		_create && _create(this);
		this._result = new Promise(async (_resolve, _reject)=> {
			assign(this, {_resolve, _reject});

			await _layout.bind();

			const {_vo:vo, _on:on, _onload} = this;
			_app.getView().bindElement(_layout.getElement(), {vo, on, ctrl:this});
			_onload && _onload();
		});
	}

	get name() {return this._name}
	get type() {return this._type}
	get vo() {return this._vo}
	get on() {return this._on}
	set html(vl) {this._layout.setHtml(vl)}
	set url(vl) {this._layout.setUrl(vl)}
	set onload(_onload) {assign(this, {_onload})}
	set onclose(_onclose) {assign(this, {_onclose})}
	get param() {return obj.clone(this._param)}
	get component() {
		const {_app, _name} = this;
		const components = _app.getComponents();
		return [...components.entries()].reduce((pre, [ky, vl])=> assign(pre, {[ky]:vl[_name]}), {});
	}
//	get result() {return this._result.then}
	async then(fn) {return fn && fn(await this._result)}
	
	event(vl) {return this._app.getView().event(vl)}
	value(vl, fn) {
		const value = this._app.getView().value(vl);
		fn && value.subscribe(fn);
		return value;
	}
	extend(ky, vl) {
		if(ky in this) error(`extend error: ${ky} is defined`);
		else this[ky] = vl;
		return vl;
	}
	close(param) {
		const {_name, _app, _resolve, _layout, _onclose} = this;
		//{ctrl:this, result:obj.clone(param)}
		_resolve(obj.clone(param));

		_layout.unbind();
		_onclose && _onclose();
		_app.delCtrl(_name);
	}
};

// ------------------------------ //
// app
//------------------------------ //
window.App = class {
	constructor(name) {
		window[name] = prc=> prc&&prc(this);
		this._components = new Map;
		this._ctrls = new Set;
	}

	get utils() {return utils}
	get debug() {
		// log,
		// report,
		// break;
		return {
			break() {debugger}
		};
	}

	addCtrl(vl) {this._ctrls.add(vl)}
	delCtrl(vl) {this._ctrls.delete(vl)}
	isOpen(vl) {return this._ctrls.has(vl)}
	getView() {return this._view}
	getComponents() {return this._components}
	extend(ky, vl) {
		if(ky in this) return error(`extend error: ${ky} is defined`);
		this[ky] = vl;
	}
	require(...arg) {
		const {_isStart, _require} = this;
		if(_isStart) return error(`can not require: app is start`);
		arg.forEach(v=> _require.add(v));
	}
	layout(name, _init) {
		const {layout} = this;
		if(!name || !_init) return error(`layout invalid param`);
		if(layout[name]) return error(`duplicate layout: ${name}`);

		layout[name] = (_url)=> Layout.GET({name, _init, _url});
	}
	controller(_name, _create) {
		const {controller} = this;
		if(!_name || !_create) return error(`controller invalid param`);
		if(controller[_name]) return error(`duplicate controller: ${name}`);
		controller[_name] = (_layout, _parent, _param)=> Controller.GET({
			_name, _create, _layout, _parent, _param,
			_app:this
		});
	}
	directive(name, fn) {
		const {directive} = this;
		if(!name || !fn) return error(`directive param is invalid`);
		if(directive[name]) return error(`duplicate directive: ${name}`);
		directive[name] = fn;
	}
	component(name, tpl, create) {
		const {component, _components} = this;
		if(!name || !tpl || !create) return error(`component param is invalid`);
		if(component[name]) return error(`duplicate component: ${name}`);

		_components.set(name, {});
		component[name] = ajax.html(tpl).then(template=> ({
			name, template, create, component:_components.get(name),
		}));
	}
	start(urls, prc) {
		document.addEventListener('DOMContentLoaded', async _=> {
			await this.loadLibrary(...new Set(urls));
			// 
			// this.loadLibrary(...this._require);

			this._requireModules();

			const {directive, component, _view} = this;
			// regist directive
			entries(directive).forEach(([ky, vl])=> _view.directive(ky, vl));
			// regist component
			(await Promise.all(entries(component).map(([_, vl])=> vl))).forEach(vl=> {
				_view.component(vl);
			});

			prc && prc();
		});
	}
	loadLibrary(...arg) {
		const {el:{create}, url:{nocache}} = utils;
		const {head} = document;
		const script = (url, resolve)=> {
			const script = head.appendChild(create('script'));
			script.src = nocache(url);
			script.onload = _=> resolve();
			script.onerror = _=> resolve(`can not load script: ${url}`);
		};
		const style = (url, resolve)=> {
			const link = head.appendChild(create('link'));
			link.rel = 'stylesheet';
			link.href = nocache(url);
			link.onload = _=> resolve();
			link.onerror = _=> resolve(`can not load css: ${url}`);
		};
		return Promise.all(arg.map(url=> new Promise((resolve, reject)=> {
			if(/\.js[\?]?/.test(url)) script(url, resolve);
			else if(/\.css[\?]?/.test(url)) style(url, resolve);
			else reject(`${url} file type error: type is js, css`);
		}))).then(all=> all.forEach(v=> v&&console.log(v)));
	}

	_requireModules() {
		const {App} = window;
		window.App = undefined;

		const {_view} = App;
		if(!_view) return error('undefined view modules');

		assign(this, {_view});
	}
};
})();
