app.view('viewName', function(ctrl) {});
app.popup('popupName', function(ctrl) {});
