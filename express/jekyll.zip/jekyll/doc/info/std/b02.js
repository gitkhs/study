// viSample 컨트롤러 등록
app.view('viSample', function(){});
// viSample 컨트롤러 인스턴스
var viSample = app.ctrl.viSample;
