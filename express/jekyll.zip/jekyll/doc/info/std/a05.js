// 히스토리 이벤트시 처리
app.router = function(ev) {};
// 모든 컨트롤러 시작시 호출
app.ctrlOpen = function(ctrl) {
  // 히스토리 적재 처리
};
// 모든 컨트롤러 종료 호출
app.ctrlClose = function(ctrl) {
  // 히스토리 삭제 처리
};
