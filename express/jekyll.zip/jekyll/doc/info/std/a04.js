// 어플리케이션의 루트설정
app.root = '/app-root';
// 반환된경로: /app-root/template.html
var template = app.path('template.html');