app.debug('localhost');
app.debug(['localhost', '127.0.0.1']);
