app.popup('popupName', function(ctrl, param) {});
