app.view('viewName', function(ctrl, param) {});
