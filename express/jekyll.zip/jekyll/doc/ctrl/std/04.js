app.component('compName', function(ctrl, param) {});
