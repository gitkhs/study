ctrl.vo.display = ctrl.observer('none');
// JSON객체 사용
ctrl.vo.style = {
  display: ctrl.observer('block'),
  color: ctrl.observer('#f00')
};
