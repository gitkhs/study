ctrl.vo.single = ctrl.observer('1');
ctrl.vo.selected = ctrl.observer(true);
ctrl.vo.multi = ctrl.observer(['1', '2']);
