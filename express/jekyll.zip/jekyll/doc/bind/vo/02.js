ctrl.vo.outText = ctrl.observer('');
ctrl.vo.outText('&lt;span&gt;html 마크업 미적용&lt;/span&gt;');
