app.view('viewName', function(ctrl) {
  ctrl.vo.imgUrl = ctrl.observer('');
});
