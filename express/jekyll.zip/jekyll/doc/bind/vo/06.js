ctrl.vo.id = ctrl.observer('id_sample');
// JSON객체 사용
ctrl.vo.imgAttr = {
  title: ctrl.observer('image'),
  href: ctrl.observer('/image.jpg')
};
