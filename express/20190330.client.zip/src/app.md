## App 인스턴스 취득

`MakeApp` 함수를 통해 인스턴스를 반환 받는다.
함수 호출시 등록된 컨트롤러의 이름을 파라메터로 전달 가능하며, 페이지 로딩시 해당 컨트롤러를 실행 시킨다.

```javascript
// app 취득
const app = MakeApp();

// 실행할 컨트롤러 명시
const app = MakeApp('v1');
app.view('v1', ctrl => {});

// 실행할 컨트롤러 명시 다건
const app = MakeApp('v1', 'v2');
app.view('v1', ctrl => {});
app.view('v2', ctrl => {});
```

* MakeApp 메소드
  - debug: 콘솔로그 출력여부 설정
  - require: 추가로 불러올 스크립트, 스타일시를 등록한다.
  - get: 등록된 컨트롤러를 반환한다.
  - view: `view`를 관리할 컨트롤러를 등록한다.
  - popup: `popup`을 관리할 컨트롤러를 등록한다.
  - component: `component`를 관리할 컨트롤러를 등록한다.
  - directive: 뷰(html 태그)에 정의된 동작을 수행하도록 해주는 작업을 한다.
  - service: `MakeApp` 인스턴스에 사용할 메소드를 등록 한다.

* MakeApp 유틸리티
  - animation: 애니메이션 액션에 대한 처리시 사용.
  - loadLibrary: 스크립트, 또는 스타일시트를 동적으로 추가.
  - appendResource: 리소스 영역에 추가
  - removeResource: 리소스 영역에서 삭제

### 모드 설정

app의 `debug` 메소드에 호스트명을 등록하여 브라우저 콘솔로그를 출력하도록 설정 할수 있다.

```javascript
app.debug('localhost');
app.debug('localhost', 'dev.com');  // 다건
```

### 라이브러리 로드

스크립트 또는 스타일시트를 `require` 메소드를 이용하여 어플리케이션에 로드 한다.

**주의:** 비동기 호출 이므로 `require`로 호출한 스크립트 안에서 `require`로 다른 리소스를 로드 할수 없다.

```javascript
app.require('a.js');
app.require('a.js', 'b.css');   // 다건
```

## 컨트롤러 작성 및 사용

컨트롤러의 종류는 모두 3종류로 구분되며, 등록되는 컨트롤러의 이름은 중복해서 사용 할 수 없다. app의 `view`, `popup`, `component` 메소드를 이용하여 등록하며, 등록된 컨트롤러를 아규먼트로 받아 사용한다.

* view: 어플리케이션의 정의된 영역(`data-app-view="name"`)을 컨트롤 또는 템플릿 조각을 추가 사용한다.

* popup: 어플리케이션의 리소스 영역(`data-app-resource`)에 템플릿 조각을 추가 사용한다. 리소스 영여은 화면이 시작되면서 자동으로 생성되며, 리소스 안에 팝업영역(`data-app-popup="name"`)이 추가된다.

* component: 다른 컨트롤러에서 호출해서 사용할 컨트롤러로 한화면에서 2개 이상 사용해도 별도의 컨트롤러가 생성되지 않는다. 태그의 주석(`<!-- ko component:'name' --><!-- /ko -->`)을 이용하여 콤포넌트가 들어갈 영역을 지정한다.

**참고**: 컨트롤러명은 html에서는 snakeCase를 사용하고 javascript에서는 camelCase를 사용한다.

```html
<div data-app-view="test-view">
  <!-- ko component:'test-component' --><!-- /ko -->
</div>

<div data-app-resource>
  <div data-app-popup="test-popup"></div> <!-- 팝업 실행시 생성 -->
</div>
```

```javascript
app.view('testView', ctrl => {});
app.popup('testPopup', ctrl => {});
app.component('testComponent', ctrl => {});
```

### 컨트롤러 등록 및 취득

app의 `view`, `popup`, `component`를 통해 각가 등록하며, app의 `get`을 통해 컨트롤러를 반환 받는다.

컨트롤러가 제공하는 속성값 및 메소드

* 속성
  - vo: 화면에 바인딩된 값
  - on: 화면에 바인딩된 이벤트
  - css: 화면에 class를 관리
  - attr: 화면의 html속성을 관리
  - style: 화면 영역의 스타일을 관리
  - html: 화면에 삽일될 html조각
  - url: 화면에 삽입될 html조각을 해당 url에서 읽어온다. html이 등록되어 있을 경우 url은 무시된다.

* 메소드
  - open: 컨트롤러를 실행 한다. 파라메터를 이용하여 해당 컨트롤러의 `onload` 에 데이터를 전달 한다.
  - close: 컨트롤러를 종료 한다. 파라메터를 이용하여 값을 전달 하며 호출한 `open` 메소드의 프로미스로 전달된다.
  - onload: 컨트롤러 실행시 발생되는 이벤트로 `open` 메소드에서 전달된 값과 애니메이션 스타일 사용시 애니메이션 값이 전달 된다.
  - event: 화면에 바인딩될 이벤트 객체를 생성 한다. 핸들값이 전달되면 핸들에 사용할 이벤트를 등록 한다.
  - observer: 화면에 바인딩될 변수 객체를 생성 한다. `$`키워드를 이용하여 값을 할당 하거나 가저온다.
  - query: 컨트롤러에서 관리하는 영역에서 셀렉터를 이용하여 DOM객체를 반환해 준다.
  - append: 컨트롤러에 메소드를 추가한다.
  - log: 브라우저 콘솔에 로그를 출력한다. 첫번째 파라메터(`style:{}`)를 이용하여 로그의 스타일을 지정 할수 있다.
  - error: 브라우저 콘솔에 에러로그 출력한다. 에러 스택로그를 저장 한다.

컨트롤러 취득시 `get` 메소드에 파라메터로 이름과 옵션값을 전달하여 컨트롤러를 반환 받는다. 옵션은 부가적인 동작을 원할때 작성한다.

* 옵션
  - focus: 오픈한 컨트롤러가 종료후 되돌아갈 포커스 포인트로 셀렉터(string) 또는 객체를 기록한다.
  - moveNext: view를 오픈할 때 포커스를 다음 화면으로 이동할지 여부를 기록한다. 디폴트값(false)
  - fixedbody: popup을 오픈할 때 스크롤 잠금 기능을 사용할지 여부를 기록한다. 디폴트값(true)

```html
<style>
@keyframes popup-open {
  0% { margin-left: -100px; }
}
@keyframes popup-close {
  100% { margin-left: 100px; }
}
</style>

<div data-app-view="sample-view">
  <div data-bind="text: vo.text"></div>
</div>
```

```javascript
// 뷰컨트롤러
app.view('vSample', ctrl => {
  // 로그 출력
  ctrl.log('out text');
  ctrl.log('style:{color:red}', 'out text color red');

  // onload 이벤트
  ctrl.onload(param => {});

  // vo 변수 등록
  ctrl.vo.text = ctrl.observer('text');
  ctrl.vo.list = ctrl.observer([]);

  // on 이벤트 등록
  ctrl.on.submit = ctrl.event(hd => {
    // 클릭이벤트
    hd.click = (vl/* 뷰오브젝트 */, ev/* 이벤트객체 */) => {
      // 팝업 컨트롤러 취득
      const pSample = app.get('pSample', {focus:ev/* 종료시 돌아올 포인트 */});
      // 팝업 오픈
      pSample.open({text: 'view text'}).then(rs => {
        // 팝업 종료시 발생
        ctrl.log('retrun data', rs);
      });
    };
  });
});

// 팝업컨트롤러
app.popup('pSample', ctrl => {
  ctrl.onload((prm, ani) => {
    ani.then(x => {
      // 애니메이션 완료 후 메시지 출력
      ctrl.vo.message.$ = prm.text;
    });
  });

  // vo 변수 등록
  ctrl.vo.message = ctrl.observer('');
  ctrl.vo.motion = ctrl.observer({
    width: '100vw',
    background: '#fff',
    animation: 'popup-open 1s 1',
  });
  // on 이벤트 등록
  ctrl.on.close = ctrl.event(hd => {
    hd.click = (vl, ev) => {
      ctrl.vo.motion.$ = {animation: 'popup-close 1s 1'}
      ctrl.close({text: 'popup close'});
    };
  });

  // 화면 템플릿
  ctrl.html = `
  <div data-bind="style: vo.motion">
    <div data-bind="html: vo.message"></div>
    <button data-bind="event: on.close">close</button>
  </div>
  `;
});
```

### 화면 바인딩 방법

컨트롤러의 변수 바인딩 객체(`vo`)를 이용하여 화면에 값을 입력 또는 출력 하며, 미리 정의된 디렉티브(`data-bind`)을 이용하여 객체(`vo`)를 바인딩 시킨다. 다건 수행일 경우 콤마(`,`)로 구분하여 사용가능.

바인딩 변수객체(`vo`)는 컨트롤러의 `observer` 메소드를 통해 취득 후 사용한다. `observer` 를 통해 생성된 객체의 `$`를 이용하거나 함수 형태로 값을 넣거나 가져 올수 있다.

```javascript
ctrl.vo.sample = ctrl.observer('');
// 값 세팅
ctrl.vo.sample.$ = 'text out';
ctrl.vo.sample('text out');
// 값 반환
ctrl.log(ctrl.vo.sample.$);
ctrl.log(ctrl.vo.sample());
```

* value: 화면상에 입력된 값을 변수로 받아 오거나, 변수의 값을 화면에 출력.

* text: 변수의 값을 TEXT로 출력

* html: 변수의 값을 html태그로 출력

* attr: 태그의 속성값을 변경

* css: 태그의 클래스(`class`)를 변경

* style: 태그의 스타일을 변경

* visible: 태그영역을 show / hide 처리 한다.

```html
<input data-bind="value: vo.t1" type="text">
<div data-bind="text: vo.t2"></div>
<div data-bind="html: vo.t3"></div>
<div data-bind="attr: vo.t4, css: vo.t5, style: vo.t6"></div><!-- 다건 -->
<div data-bind="visible: vo.t7"></div>
```

```javascript
// 화면값 입력 및 출력
ctrl.vo.t1 = ctrl.observer();
ctrl.vo.t1.$ = 'out';
ctrl.log('in data', ctrl.vo.t1.$);

// 화면에 텍스트 작성
ctrl.vo.t2 = ctrl.observer();
ctrl.vo.t2.$ = 'text out';

// 화면에 html 태그 삽입
ctrl.vo.t3 = ctrl.observer();
ctrl.vo.t3.$ = '<stron>html tag</stron>';

// 속성값 변경
ctrl.vo.t4 = ctrl.observer();
ctrl.vo.t4.$ = {
  id: 'tagid'
};

// 클래스 변경
ctrl.vo.t5 = ctrl.observer({
  show: true
});

// 스타일 변경
ctrl.vo.t6 = ctrl.observer({
  minHeight: '100px'
});

// show / hide 처리
ctrl.vo.t7 = ctrl.observer(false);
```

### 반복 및 조건부 처리

변수 바인딩 객체(`on`) 생성시 배열로 생성할 경우 배열의 내용을 화면에 반복적으로 수행 할 수 있으며, 조건에 따라 화면 생성 여부를 결정 할 수 있다.

* foreach: 배열의 내용을 반복하여 화면에 출력한다. 반복구 안의 데이터는 `$data`객체를 이용하여 출력할 수 있다. `$data`객체는 별칭을 부여 하여 사용할 수도 있다. `observer`를 배열로 생성된 객체는 배열을 관리 하기 위한 별도의 메소드를 제공한다.
  * push: 배열의 끝에 추가
  * pop: 배열의 마지막 항목 제거
  * unshift: 배열의 앞에 추가
  * shift: 배열의 처음 항목 제거
  * reverse: 배열의 순서를 반대로한 값을 반환
  * sort: 배열을 정렬 기본은 알파벳순
  * splice: 색인번호에서 해당 갯수만큼 제거후 값을 반환
  * replace: 원본값을 새로운 값으로 변환
  * remove: 값을 제거
  * removeAll: 전체값 제거

* if(ifnot): 변수의 값이 true 이면 화면을 한다. `ifnot` 은 `if` 의 반대로 동작 한다. `visible` 과의 차이점은 `if`의 경우 element를 생성하지 않으므로, **id** 값등이 중복되지 않는다.

```html
<!-- 반복 처리 -->
<div data-bind="foreach: vo.list">
  <!-- 반복구 상위의 객체를 호출할 경우 $parent를 사용 -->
  <button data-bind="text: $data.title, event: $parent.on.btn"></button>
</div>
<ul>
  <!-- ko foreach: {as: item, data: vo.list} -->
  <li data-bind="text: item.title"></li>
  <!-- /ko -->
</ul>

<!-- 조건부 처리 -->
<div data-bind="if: vo.list.$.length">
  <strong data-bind="text: vo.list.$.length"></strong>건 존재 합니다.
</div>
<!-- ko ifnot: vo.list.$.length -->
<div>데이터가 존재 하지 않습니다.</div>
<!-- /ko -->
```

```javascript
ctrl.vo.list = ctrl.observer([
  {title: 'title - 1'},
  {title: 'title - 2'},
]);
ctrl.vo.list.push({title: 'title - 3'});

// 이벤트
ctrl.on.btn = ctrl.event(handle => {
  handle.click = (vl/* $data */, ev) => {
    // vl은 반복구의 $data를 전달한 값으로 $data를 새로운 값으로 변환
    ctrl.vo.list.replace(vl, {title: 'title -new'});
  };
});
```


### 이벤트 바인딩 방법

컨트롤러의 이벤트 바인딩 객체(`on`)를 이용하여 이벤트를 처리 한다. 미리 정의된 디렉티브(`data-bind`)를 이용하여 객체(`vo`, `on`)를 바인딩 시킨다.

이벤트 객체(`on`)는 컨트롤러의 `event` 메소드를 통해 취득 후 사용한다. `event` 에서 넘어오는 핸들객체에 원하는 이벤트의 구현부를 작성한다.

```html
<button data-bind="event: on.sample"></button>
```

```javascript
ctrl.on.sample = ctrl.event(handle => {
  handle.click = (vl, ev) => {};  // 클릭 이벤트
  handle.change = (vl, ev) => {}; // 체인지 이벤트
});
```

### 디렉티브 작성

디렉티브(`data-bind`)에 사용자 기능을 추가한다. app의 `directive` 메소드를 사용하여 넘겨 받은 핸들을 이용해 작성한다. 핸들은 각각 `init`, `update` 가 있으며 `init` 은 컨트롤러 오픈시 한번 호출되며, `update` 는 값의 변경시 호출된다.

```html
<div data-bind="sample">aaaa</div>
```

```javascript
app.directive('dirSample', handle => {
  handle.init = (el/* DOM객체 */, vl/* 화면에서 넘어온값 */, ctrl/* 컨트롤러 */) => {
    el.innerHTML = '<strong>testDirective</strong>';
  };
});

```


## 스타일시트 정의

미리 정의되어 있는 selector를 사용하여 스타일을 정의할 수 있다.

* `[data-app-view]`: 뷰 영역
* `[data-app-resource]`: 어플리케이션 리소스 영역
* `[data-app-popup]`: 팝업 여역으로 리소스 영역 안에 생성.
* `[data-app-motion]`: 화면 오픈(`open`) 또는 종료(`close`)시 애니메이션 처리 영역

