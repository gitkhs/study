const ko = require('../libs/knockout-3.4.2');

// object util
const prop = (...v) => Object.assign(...v);
const clone = v => (typeof v === 'object' ? prop({}, v) : v);
const arrConv = v => (Array.isArray(v) ? v : [v]);
const arrJoin = v => (Array.isArray(v) ? v.join('') : v);

// DOM util
const el = t => document.createElement(t);
const qr = (s, d = document) => d.querySelector(s);

// app util
const snakeCase = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`).replace(/^-/, '');
const pascalCase = vl => ('-'+vl).replace(/-[A-z]/g, vl => vl.toUpperCase()).replace(/-/g, '');
const camelCase = vl => pascalCase(vl).replace(/^[A-z]/, vl => vl.toLowerCase());
const log = (...vl) => {
  console && console.log(...vl);
};
const error = vl => {
  if(localStorage) {
    const errors = localStorage.errors ? JSON.parse(localStorage.errors) : [];

    errors.unshift({
      time: new Date().getTime(),
      log: new Error().stack,
    }) > 20 && errors.pop();

    localStorage.errors = JSON.stringify(errors);
  }
  // console && console.error && console.error(vl);
  throw vl;
};
const today = (dt = new Date()) => {
  const y = dt.getFullYear();
  const m = '00' + (dt.getMonth() + 1);
  const d = '00' + dt.getDate();

  return y + m.substr(m.length - 2) + d.substr(d.length-2);
};

const WAIT_PREFIX = 'data-app-wait';
const MOTION_PREFIX = 'data-app-motion';
const VIEW_PREFIX = 'data-app-view';
const POPUP_PREFIX = 'data-app-popup';
const RESOURCE_PREFIX = 'data-app-resource';

// ---------- class Controller ---------- //
const Controller = class {
  constructor(_type, _name, _create) {
    prop(this, {
      _type,
      _name,
      _create,
      _isopen: false,
      _focus: null, _trigger: null,
      _loadAfter: null, _load: null,
      _resolve: null,
      _html: null, _url: null,
      vo: null, on: null,
      attr: null, style: null, clss: null,
    });
  }

  // 화면 로드 이벤트
  onload(proc) {
    return new Promise(resolve => {
      this._load = proc;
      this._loadAfter = resolve;
    });
  }
  html(vl) {
    if(this._isopen) return this;

    this._html = Array.isArray(vl) ? vl.join('') : (typeof vl == 'string' ? vl : '');
    return this;
  }
  url(vl) {
    if(this._isopen) return this;

    this._url = typeof vl == 'string' ? vl : '';
    return this;
  }
  // focus(focus) {
  //   if(typeof focus === 'string') this._focus = qr(focus);
  //   else if(focus instanceof Event) this._focus = focus.currentTarget || focus.target;
  //   else if(focus instanceof Element) this._focus = focus;

  //   return this;
  // }
  trigger(vl) {
    // focus, body-scroll
    this._trigger = vl;
    return this;
  }

  // 화면 오픈
  open(param) {
    return new Promise(async (resolve) => {
      this._init();
      const after = this._open();
      await this._bind();

      this._load && this._load(clone(param));
      this._isopen = true;
      this._resolve = resolve;

      await this._motion('open');

      after && after();
      this._loadAfter && this._loadAfter();
    });
  }
  _open() { error(`"${this.name}" open is override`); }
  // 화면 바인딩 처리
  async _bind() {
    const {_self, vo, on, attr, style, clss: css} = this;

    // 템플릿 취득
    if(this._url) {
      this._html = await fetch(this._url).then(rs => rs.text());
      this._url = null;
    }
    if(this._html) _self.innerHTML = this._html;

    ko.cleanNode(_self);
    ko.applyBindingsToNode(_self, { css, attr, style });
    ko.applyBindings({ vo, on, ctrl: this }, _self);
  }

  close(param) {
    return new Promise(async (resolve) => {
      const {_focus, _resolve} = this;
      const after = this._close();
      this._isopen = false;
      _resolve && _resolve(clone(param));

      await this._motion('close');

      _focus && _focus.focus();
      after && after();
      resolve();
    });
  }
  _close() { error(`"${this.name}" close is override`); }
  // 모션감지
  _motion(type) {
    const motion = qr(`[${MOTION_PREFIX}]`, this._self);
    motion && motion.setAttribute(MOTION_PREFIX, type);

    return app.animation(this._self);
  }

  // 초기화
  _init() {
    this.vo = {};
    this.on = {};
    this.attr = ko.observable({});
    this.style = ko.observable({});
    this.clss = ko.observable({});
    this._create(this);
  }
  get name() { return this._name; }
  // 로그 출력
  log(style, ...vl) {
    const {_type, _name} = this;
    if(/^style:{\w+.*}$/.test(style)) style = style.substring(7, style.length-1);
    else {
      vl.unshift(style);
      style = '';
    }

    log(`%c${_type}:${_name}\n`, `font-weight:bold;${style}`, ...vl);
  }
  // 속성값 추가
  append(name, vl) {
    if(!name || !vl) return error(`append: invalid params`);
    if(this[name]) return error(`append: duplicate`);

    this[name] = vl;
    return this;
  }
  // 화면 바인딩 변수 객체 생성
  observer(vl) { return Array.isArray(vl) ? ko.observableArray(vl) : ko.observable(vl); }
  // 화면 바인딩 이벤트 객체 생성
  event(func) {
    const on = {};
    return func && func(on), on;
  }
}

// ---------- class View ---------- //
const View = class extends Controller {
  static GET(name, proc) { return new View(name, proc); }
  constructor(name, proc) {
    super('view', name, proc);
  }

  // 오픈 처리
  _open() {
      const name = snakeCase(this.name);
      this._self = qr(`[${VIEW_PREFIX}=${name}]`);
      if(!this._self) return error(`can not find element: ${VIEW_PREFIX}="${name}"`);
  }

  // 종료 처리
  _close() {
    const {_self} = this;

    return x => {
      const name = snakeCase(this.name);
      _self.outerHTML = `<${_self.nodeName} ${VIEW_PREFIX}="${name}"></${_self.nodeName}>`;
    };
  }
}

// ---------- class Popup ---------- //
class Popup extends Controller {
  static GET(name, proc) { return new Popup(name, proc); }
  constructor(name, proc) {
    super('popup', name, proc);
  }

  _open() {
      const name = snakeCase(this.name);
      this._self = app.appendResource(el('div'));

      const {_self, bodyScroll} = this;
      _self.setAttribute(POPUP_PREFIX, name);
      _self.addEventListener('click', evt => {
        if(_self == evt.target) bodyScroll();
      });
      bodyScroll(false);

      return x => {
        const first = this._self.firstChild;
        if(first) {
          first.setAttribute('tabindex', 0);
          first.focus();
        }
      };
  }
  _close() {
    const {dataset: {appPopup}={}} = this._self.nextSibling || {};
    if(appPopup) {
      const name = camelCase(appPopup);
      const child = app.controller(name);
      child.close();
    }

    return x => {
      const {_trigger:{focus}={}, _self, bodyScroll} = this;

      let target;
      if(typeof focus === 'string') target = qr(focus);
      else if(focus instanceof Event) target = focus.currentTarget || focus.target;
      else if(focus instanceof Element) target = focus;

      target && target.focus();
      _self.remove();
      bodyScroll(true);
    };
  }

  bodyScroll(vl) {
    const {body:{style:bodyStyle}, documentElement:{style:htmlStyle}} = document;

    if(vl === undefined)  vl = htmlStyle.overflowY == 'hidden';
    bodyStyle.overflowY = vl ? 'auto' : 'hidden';
    htmlStyle.overflowY = vl ? 'auto' : 'hidden';
  }
}

// ---------- class Component ---------- //
class Component extends Controller {
  static GET(name, proc) { return new Component(name, proc); }
  constructor(name, proc) {
    super('component', name, proc);

    this._init();
    this._bind();
  }
  initialize(vl) { this._load && this._load(clone(vl)); }

  // 화면 바인딩 처리
  async _bind() {
    const ctrl = this;
    const {name, vo, on, attr, style, clss: css, _load} = this;

    if(this._url) {
      this._html = await fetch(this._url).then(rs => rs.text());
      this._url = null;
    }
    if(!this._html) return error(`invalid template: "${name}"`);

    ko.components.register(snakeCase(name), {
      template: this._html,
      viewModel: {
        createViewModel(prm, info) {
          ko.applyBindingsToNode(info.element, {ctrl});
          // ko.applyBindingsToNode(info.element, {
					// 	ctrl, css, attr, style
					// });

          // _load && setTimeout(() => _load(clone(prm)));
          return { vo, on };
        }
      }
    });
  }
}

// ---------- class MakeApp ---------- //
const app = new class MakeApp {
  constructor() {
    prop(this, {
      _launcher: new Set,
      _require: new Set,
      _ctrl: new Map,
      _resource: null,
    });

    // app 인스턴스 반환
    window.MakeApp = name => (arrConv(name).forEach(v => this._launcher.add(v)), this);
    document.addEventListener('DOMContentLoaded', () => this._run());
  }
  // 어플리케이션 실행
  _run() {
    const {_launcher, _require, _ctrl, animation} = this;

    // 팝업등 처리할 리소스
    this._resource = document.body.appendChild(el('div'));
    this._resource.setAttribute(RESOURCE_PREFIX, '');

    // 라이브러리 로드
    this.loadLibrary([..._require]).then(rs => {
      _launcher.forEach(name => {
        const ctrl = _ctrl.get(name);
        if(ctrl instanceof View) ctrl.open(this);
      });

      // 페이지 로드 모션처리
      const wait = qr(`[${WAIT_PREFIX}]`, document.body);
      if(wait) {
        wait.setAttribute(WAIT_PREFIX, 'false');
        animation(wait).then(wait => wait.remove());
      }
    });
  }

  // 로드할 스크립트 수집
  require(js) { arrConv(js).forEach(v => this._require.add(v)); }
  // 스크립트 로딩
  loadLibrary(vl) {
    return Promise.all(arrConv(vl).map(vl => new Promise((resolve, reject) => {
      if(typeof vl !== 'string') return reject('error');

      let lib;
      if(/\.js$/.test(vl)) {
        lib = document.head.appendChild(el('script'));
        lib.src = `${vl}?v=${today()}`;
      } else if(/\.css$/.test(vl)) {
        lib = document.head.appendChild(el('link'));
        lib.rel = 'stylesheet';
        lib.href = `${vl}?v=${today()}`;
      } else return reject('error');

      lib.onload = () => {
        resolve({ load: true, name: vl });
    };
      lib.onerror = () => resolve({ load: false, name: vl });
    })));
  }

  // 컨트롤러 반환
  controller(vl) {
    return [...this._ctrl].reduce((ctrl, [k, v]) => Object.assign(ctrl, {[k]:v.trigger(vl)}), {});
  }

  // 뷰
  view(name, proc) {
    if(this._ctrl.has(name)) return error(`dup controller: "${name}"`);
    this._ctrl.set(name, View.GET(name, proc));

    return this;
  }
  // 팝업
  popup(name, proc) {
    if(this._ctrl.has(name)) return error(`dup controller: "${name}"`);
    this._ctrl.set(name, Popup.GET(name, proc));

    return this;
  }
  // 콤포넌트
  component(name, proc) {
    if(this._ctrl.has(name)) return error(`dup controller: "${name}"`);
    this._ctrl.set(name, Component.GET(name, proc));

    return this;
  }

  // 디렉티브
  // sample - el data-bind="format:{value:'##.##', data:vo.data}"
  // sample - procedure function(el, vl) { console.log(vl); }
  directive(name, proc) {
    if(!name) return err('directive: invalid name');
		if(!proc) return err('directive: invalid procedure');

    const handle = {};
    proc(handle);
    const {init, update} = handle;

    ko.bindingHandlers[name] = {
			init(el, vl, bind, model, context) {
				init && init(el, vl(), model.ctrl);
			}, 
			update(el, vl, bind, model, context) {
				update && update(el, vl(), model.ctrl);
			},
		};

    return this;
  }
  // 모든 팝업 종료
  clearPopup() {
    const pop = qr(`[${POPUP_PREFIX}]`, this._resource);
    const {appPopup} = pop.dataset;
    const name = camelCase(appPopup);
    this._ctrl.get(name).close();
  }
  // 속성값 추가
  append(name, vl) {
    if(!name || !vl) return error(`append: invalid params`);
    if(this[name]) return error(`append: duplicate`);

    this[name] = vl;
    return this;
  }
  // 리소스 추가
  appendResource(vl) { return this._resource.appendChild(vl); }
  // 리소스 삭제
  removeResource(vl) { this._resource.removeChild(vl); }

  // 오류 출력
  error(vl) { error(vl); }
  // 에니메이션 처리
  animation(target) {
    return new Promise((resolve, reject) => {
      if(!target) return reject();
    
      let move = false;
      const start = () => {
        move = true;
        target.removeEventListener('animationstart', start);
      };
      target.addEventListener('animationstart', start);
    
      const end = () => {
        resolve(target)
        target.removeEventListener('animationend', end);
      };
      target.addEventListener('animationend', end);
    
      setTimeout(() => {
        if(move) return;
        resolve(target);
      }, 100);
    })
  };
}
