const ko = require('../libs/knockout-3.4.2');

// object util
const prop = (...v) => Object.assign(...v);
const clone = v => (typeof v === 'object' ? prop({}, v) : v);
const arrConv = v => (Array.isArray(v) ? v : [v]);
const arrJoin = v => (Array.isArray(v) ? v.join('') : v);

// DOM util
const el = t => document.createElement(t);
const qr = (s, d = document) => d.querySelector(s);
const animation = (selector, befor) => {
  const target = qr(selector);
  befor && befor(target);

  return new Promise(resolve => {
    let nonAni=true;
    const animationstart = x => {
      nonAni = false;
      target.removeEventListener('animationstart', animationstart);
    };
    target.addEventListener('animationstart', animationstart);

    const animationend = x => {
      resolve({target, status:'animationend'});
      target.removeEventListener('animationend', animationend);
    };
    target.addEventListener('animationend', animationend);

    setTimeout(x => nonAni && resolve({target}), 100);
  });
};

// app util
const snakeCase = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`).replace(/^-/, '');
const pascalCase = vl => ('-'+vl).replace(/-[A-z]/g, vl => vl.toUpperCase()).replace(/-/g, '');
const camelCase = vl => pascalCase(vl).replace(/^[A-z]/, vl => vl.toLowerCase());
const hash = location.hash.length ? JSON.parse(`{"${location.hash.replace(/^#/, '').replace(/&/g, '","').replace(/=/g, '":"')}"}`) : {};
const log = (debug, ...vl) => {
  if(location.hostname != debug) return;
  console && console.log(...vl);
};
const error = (message, kill=true) => {
  if(localStorage) {
    const errors = localStorage.errors ? JSON.parse(localStorage.errors) : [];

    errors.unshift({
      message,
      time: new Date().getTime(),
      log: new Error().stack,
    }) > 20 && errors.pop();

    localStorage.errors = JSON.stringify(errors);
  }
  if(kill) throw message;
  else console && console.error(message);
};
var datetime = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]);

const DIF_PREFIX = 'data-app';
const WAIT_PREFIX = 'data-app-wait';
const MOTION_PREFIX = 'data-app-motion';
const DIF_VIEW = `${DIF_PREFIX}-view`;
const POPUP_PREFIX = 'data-app-popup';
const DIF_RESOURCE = `${DIF_PREFIX}-resource`;

// ---------- class Controller ---------- //
const Controller = class {
  static GET(vl) {
    const {_name, _type, _procedure} = vl;
    if(!_type || !_procedure) return error(`can not find controller: ${_name}`);

    switch(_type){
    case 'view': return View.GET(vl);
    case 'popup': return Popup.GET(vl);
    case 'component': return Component.GET(vl);
    }
  }
  constructor(vl) {
    prop(this, vl, {
      _self: null,
      _onload: null,
      // _url: null, _html: null, _template: null,
      _template: {url:'', html:''},
      _vo: {}, _on: {},
      _css: ko.observable(vl),
      _attr: ko.observable(vl),
      _style: ko.observable(vl),
    });

    const {_procedure} = this;
    _procedure(this);
  }

  // public properties
  get on() { return this._on; }
  get vo() { return this._vo; }
  set css(vl) { this._css(vl); }
  set attr(vl) { this._attr(vl); }
  set style(vl) { this._style(vl); }
  set url(vl) {
    if(typeof vl != 'string') return error('url type is string');
    this._url = vl;
  }
  set html(vl) {
    if(typeof vl != 'string') return error('html type is string');
    this._html = vl;
  }
  async template() {
  }

  // public method
  onload(func) { this._onload = func; }
  event(func, on={}) { return func && func(on), on; }
  observer(vl) {
    const data = Array.isArray(vl) ? ko.observableArray(vl) : ko.observable(vl);
    return Object.defineProperty(data, '$',{
      get() { return data();},
      set(vl) { ko.observable().toString() == vl.toString() || data(vl); },
    });
  }
  append(name, procedure) {
    const {_name} = this;
    if(!name || !procedure) return error(`can not append "${_name}": param is name, procedure`);
    if(typeof procedure != 'function') return error(`can not append "${_name}": procedure is function`)

    if(this[name]) return;
    this[name] = procedure;
  }
  open(param) {
    this._param = prop({}, param);
    this._url = '2';
    console.log('open1');
    // Object.freeze(this);
    this._url = '1';
    console.log('open2');
    // const {_onload} = this;
    // _onload && _onload(prop({}, param));
  }
  close(param) {
    this._removeContorller();
  }
  log(style, ...vl) {
    const {_type, _name, _debug} = this;
    style = /^style:{\w+.*}$/.test(style) ? style.substring(7, style.length-1) : (vl.unshift(style), '');
    log(_debug, `%c${_type}:${_name}\n`, `font-weight:bold;${style}`, ...vl);
  }

  // 
  async _bind() {
    const {_self, _template, _html, _url} = this;
    console.log('-1-', this._template, this._html, this._url);
    const template = _template || _html || _url && await fetch(_url).then(rs => rs.text());
    console.log({template});
    // this._template = _template || _html || _url && await fetch(_url).then(rs => rs.text());

    if(template) {
      this._template = template;
      _self.innerHTML = template;
    }
    // console.log('-2-', this._template);
    // if(this._template) _self.innerHTML = this._template;

    const {_vo:vo, _on:on, _css:css, _attr:attr, _style:style} = this;
    ko.cleanNode(_self);
    ko.applyBindingsToNode(_self, { css, attr, style });
    ko.applyBindings({ vo, on, ctrl: this }, _self);

    const {_onload} = this;
    _onload && _onload({});
  }
}

// ---------- class View ---------- //
const View = class extends Controller {
  static GET(vl) { return new View(vl); }
  constructor(vl) {
    super(vl);

    const name = snakeCase(this._name);
    this._self = qr(`[${DIF_VIEW}=${name}]`);
    if(!this._self) return error(`can not find element: ${DIF_VIEW}="${name}"`);

    // this._bind();
  }
}

// ---------- class Popup ---------- //
class Popup extends Controller {
  static GET(vl) { return new Popup(vl); }
  constructor(vl) {
    super(vl);
  }
}

// ---------- class Component ---------- //
class Component extends Controller {
  static GET(vl) { return new Component(vl); }
  constructor(vl) {
    super(vl);
  }
}

// ---------- class MakeApp ---------- //
new class MakeApp {
  constructor() {
    prop(this, {
      _hostname: null,
      _resource: null,
      _procedures: new Map,
      _controllers: new Map,
      _launcher: new Set,
      _require: new Set,
    });

    const {_launcher} = this;
    window.MakeApp = (...name) => (name.forEach(v => _launcher.add(v)), this);
    document.addEventListener('DOMContentLoaded', x => this._bootstrap());
  }

  GET(_name, _trigger) {
    if(!_name) return error(`invalid Controller name`);

    const {_procedures, _controllers, _debug} = this;
    if(_controllers.has(_name)) return _controllers.get(_name).trigger(_trigger);

    if(!_procedures.has(_name)) return error(`invalid procedure: ${_name}`);

    const {type:_type, procedure:_procedure} = _procedures.get(_name);
    const ctrl = Controller.GET({
      _name, _trigger,
      _type, _procedure, _debug,
      _removeContorller: x => _controllers.delete(_name),
    });
    _controllers.set(_name, ctrl);

    return ctrl;
  }
  view(name, procedure) {
    this._addProcedure('view', name, procedure);
  }
  popup(name, procedure) {
    this._addProcedure('popup', name, procedure);
  }
  component(name, procedure) {
    this._addProcedure('component', name, procedure).GET(name);
  }
  _addProcedure(type, name, procedure) {
    const {_procedures} = this;
    if(!name || !procedure) return error(`can not initialize controller: "${type}" parameter is name, procedure`);
    if(typeof procedure != 'function') return error(`can not initialize controller: "${type}" procedure is function`);
    if(_procedures.has(name)) return error(`duplicate controller name: ${name}`);

    _procedures.set(name, { type, procedure });
    return this;
  }
  directive(name, procedure) {
    // directive
  }
  service(name, procedure) {
    if(!name || !procedure) return error('can not append service: param is name, procedure');
    if(typeof procedure != 'function') return error('can not append service: procedure is function')

    if(this[name]) return;
    this[name] = procedure;
  }

  require(...link) { link.forEach(v => this._require.add(v)); }
  async _bootstrap() {
    this._resource = document.body.appendChild(el('div'));

    const {_resource, _require, _launcher} = this;
    _resource.setAttribute(DIF_RESOURCE, '');

    await this.loadLibrary(..._require);
    [..._launcher].forEach(name => this.GET(name).open({}));

    Object.freeze(this);
  }
  set debug(name) { this._debug = name; }

  // resource
  appendResource(vl) { return this._resource.appendChild(vl); }
  removeResource(vl) { this._resource.removeChild(vl); }

  // utils
  // endAnimation() {}
  log(...vl) { log(this._debug, ...vl); }
  error(vl) { error(vl, false); }
  animation(selector, befor) { return animation(selector, befor); }
  loadLibrary(...link) {
    return Promise.all(link.map(vl => new Promise((resolve, reject) => {
      if(!/\.js$|\.css$/.test(vl)) return reject(`can not include: ${vl}`);

      const lib = document.head.appendChild(el(/\.js$/.test(vl) ? 'script' : 'link'));
      if(/\.js$/.test(vl)) lib.src = `${vl}?v=${datetime('YMD')}`;
      else {
        lib.rel = 'stylesheet';
        lib.href = `${vl}?v=${datetime('YMD')}`;
      }
      lib.onload = x => resolve({ load: true, name: vl });
      lib.onerror = x => resolve({ load: false, name: vl });
    })));
  }
}
