const ko = require('../libs/knockout-3.4.2');

// object util
const prop = (...v) => Object.assign(...v);

// DOM util
const el = t => document.createElement(t);
const qr = (s, d = document) => d.querySelector(s);
const animation = (selector, befor) => {
  const target = typeof selector == 'string' ? qr(selector) : selector;
  befor && befor(target);

  return new Promise(resolve => {
    let nonAni=true;
    const animationstart = x => {
      nonAni = false;
      target.removeEventListener('animationstart', animationstart);
    };
    target.addEventListener('animationstart', animationstart);

    const animationend = x => {
      resolve({target, status:'animationend'});
      target.removeEventListener('animationend', animationend);
    };
    target.addEventListener('animationend', animationend);

    setTimeout(x => nonAni && resolve({target}), 100);
  });
};

// app util
const snakeCase = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`).replace(/^-/, '');
// const pascalCase = vl => ('-'+vl).replace(/-[A-z]/g, vl => vl.toUpperCase()).replace(/-/g, '');
// const camelCase = vl => pascalCase(vl).replace(/^[A-z]/, vl => vl.toLowerCase());
// const hash = location.hash.length ? JSON.parse(`{"${location.hash.replace(/^#/, '').replace(/&/g, '","').replace(/=/g, '":"')}"}`) : {};
const log = (...vl) => console && console.log(...vl);
const error = (message, debug) => {
  if(localStorage) {
    const errors = localStorage.errors ? JSON.parse(localStorage.errors) : [];

    errors.unshift({
      message,
      time: new Date().getTime(),
      log: new Error().stack,
    }) > 20 && errors.pop();

    localStorage.errors = JSON.stringify(errors);
  }

  // if(kill) throw message;
  // else console && console.error(message);
  if(debug === undefined) throw message;
  debug && console && console.error(message);
};
var datetime = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]);

const DIF_PREFIX = 'data-app';
const DIF_VIEW = `${DIF_PREFIX}-view`;
const DIF_POPUP = `${DIF_PREFIX}-popup`;
const DIF_MOTION = `${DIF_PREFIX}-motion`;
const DIF_RESOURCE = `${DIF_PREFIX}-resource`;

// ---------- class Controller ---------- //
const Controller = class {
  constructor({_name, _procedure}) {
    prop(this, {
      _name, _procedure, _option: {},
      _onload: null, _closeTrigger: null,
      _self: null, _url: null, _html: null,
      _vo: {}, _on: {},
      _css: ko.observable({}),
      _attr: ko.observable({}),
      _style: ko.observable({}),
    });
  }
  open(param) { error(`Controller::open is overrided`); }
  close(param) { error(`Controller::close is overrided`); }
  async _open() {
    const {_self} = this;
    const template = await this._template();
    if(template) {
      _self.innerHTML = template;
      prop(this, {_html: template});
    } else {
      this._html = _self.innerHTML;
    }

    const {_vo:vo, _on:on, _css:css, _attr:attr, _style:style} = this;
    ko.cleanNode(_self);
    ko.applyBindingsToNode(_self, { css, attr, style });
    ko.applyBindings({ vo, on, ctrl:this }, _self);
  }
  _close() {
    const {_option} = this;
    const {focus} = _option;

    let target;
    if(typeof focus == 'string') target = qr(focus);
    else if(focus instanceof Event) target = focus.currentTarget || focus.target;
    else if(focus instanceof Element) target = focus;
    target && target.focus();

    const {_self, _css, _attr, _style} = this;
    const clear = vl => Object.entries(vl).reduce((o, [k])=> ((o[k]=false), o), {});
    _css(clear(_css()));
    _attr(clear(_attr()));
    _style(clear(_style()));

    _self.innerHTML = '';
    this._closeTrigger = null;
    this._vo = {};
    this._on = {};
  }
  async _template() {
    const {_html, _url} = this;
    return _html || _url && await fetch(_url).then(rs => rs.text());
  }
  _motion(type) {
    const {_self} = this;
    const motion = qr(`[${DIF_MOTION}]`, _self);
    motion && motion.setAttribute(DIF_MOTION, type);

    return animation(_self);
  }

  // properties
  get on() { return this._on; }
  get vo() { return this._vo; }
  set css(vl) { this._css(vl); }
  set attr(vl) { this._attr(vl); }
  set style(vl) { this._style(vl); }
  set url(vl) {
    if(typeof vl != 'string') return error(`"${this._name}": url type is string`);
    this._url = vl;
  }
  set html(vl) {
    if(typeof vl != 'string') return error(`"${this._name}": html type is string`);
    this._html = vl;
  }

  // method
  onload(func) { this._onload = func; }
  event(func, on={}) { return func && func(on), on; }
  observer(vl) {
    const data = Array.isArray(vl) ? ko.observableArray(vl) : ko.observable(vl);
    return Object.defineProperty(data, '$',{
      get() { return data();},
      set(vl) { ko.observable().toString() == vl.toString() || data(vl); },
    });
  }

  // util
  query(selector) { return qr(selector, this._self); }
  option(opt) {
    const {_option, _closeTrigger} = this;
    _closeTrigger || prop(_option, opt);
    return this;
  }
  append(name, procedure) {
    const {_closeTrigger, _name} = this;
    if(_closeTrigger) return error(`"${_name}" is opened`);
    if(!name || !procedure) return error(`"${_name}" invalid parameter: pname, procedure`);
    if(typeof procedure != 'function') return error(`"${_name}" type error: procedure is function`);
    if(this[name]) return;

    this[name] = procedure;
  }
  log(style, ...vl) {
    const {_type, _name, _option:{debug}} = this;
    style = /^style:{\w+.*}$/.test(style) ? style.substring(7, style.length-1) : (vl.unshift(style), '');

    if(debug.indexOf(location.hostname) == -1) return;
    log(`%c${_type}:${_name}`, `font-weight:bold;${style}`, ...vl);
  }
  error(...vl) {
    const {_type, _name, _option:{debug}} = this;
    error(`${_type}:${_name}>> ${vl.join('>> ')}`, debug.indexOf(location.hostname) > -1);
  }
}

// ---------- class View ---------- //
const View = class extends Controller {
  static GET(vl) { return new View(vl); }
  constructor(vl) {
    super(vl);
    prop(this, { _type: 'view' });
  }

  open(param) {
    return new Promise(async (resolve, reject) => {
      const {_name, _procedure, _closeTrigger} = this;
      if(_closeTrigger) return reject(`"${_name}" is opened`);
      _procedure && _procedure(this);

      const name = snakeCase(_name);
      const _self = qr(`[${DIF_VIEW}=${name}]`);
      if(!_self) return reject(`cannot find element: ${DIF_VIEW}="${name}"`);
      _self.setAttribute('tabindex', '0');

      let loadAfter;
      const {_onload, _option:{moveNext}} = prop(this, {_self});
      
      await this._open();
      _onload && _onload(prop({}, param), new Promise(resolve => (loadAfter=resolve)));
      this._closeTrigger = resolve;

      await this._motion('open');
      moveNext && _self.focus();

      loadAfter && loadAfter();
    });
  }
  close(param) {
    return new Promise(async (resolve) => {
      const {_closeTrigger, _self} = this;
      _closeTrigger && _closeTrigger(prop({}, param));

      await this._motion('close');
      await this._close();

      resolve();
    });
  }
}

// ---------- class Popup ---------- //
class Popup extends Controller {
  static GET(vl) { return new Popup(vl); }
  constructor(vl) {
    super(vl);
    prop(this, { _type: 'popup' });
  }

  open(param) {
    return new Promise(async (resolve, reject) => {
      const {_name, _procedure, _closeTrigger, _option:{resource}} = this;
      if(_closeTrigger) return reject(`"${_name}" is opened`);
      _procedure && _procedure(this);

      const name = snakeCase(_name);
      const _self = resource.appendChild(el('div')); 
      _self.setAttribute(DIF_POPUP, name);
      _self.setAttribute('tabindex', '0');
      _self.addEventListener('click', evt => {
        if(_self == evt.target) this._fixedBody();
      });
  
      let loadAfter;
      const {_onload} = prop(this, {_self});
    
      await this._open();
      _onload && _onload(prop({}, param), new Promise(resolve => (loadAfter=resolve)));
      this._closeTrigger = resolve;
      this._fixedBody(true);

      await this._motion('open');
      _self.focus();
  
      loadAfter && loadAfter();
    });
  }
  close(param) {
    return new Promise(async (resolve) => {
      const {_closeTrigger, _self} = this;
      _closeTrigger && _closeTrigger(prop({}, param));

      await this._motion('close');
      await this._close();
      this._fixedBody(false);

      _self.remove();
      resolve();
    });
  }
  _fixedBody(isOpen) {
    const {_option:{fixedbody=true}} = this;
    if(!fixedbody) return;

    const {body:{style:bodyStyle}, documentElement:{style:htmlStyle}} = document;
    if(isOpen === undefined)  isOpen = htmlStyle.overflowY != 'hidden';
    bodyStyle.overflowY = isOpen ? 'hidden' : 'auto';
    htmlStyle.overflowY = isOpen ? 'hidden' : 'auto';
  }
}

// ---------- class Component ---------- //
class Component extends Controller {
  static GET(vl) { return new Component(vl); }
  constructor(vl) {
    super(vl);
    prop(this, { _type: 'component' });

    const {_procedure} = this;
    _procedure && _procedure(this);
  }

  async initComponent() {
    const template = await this._template();
    const {_name, _onload, _vo:vo, _on:on} = this;
    const name = snakeCase(_name);
    const ctrl = this;

    ko.components.register(name, {
      template,
      viewModel: {
        createViewModel(prm, info) {
          ko.applyBindingsToNode(info.element, {ctrl});
          _onload && setTimeout(x => _onload());
          return { vo, on };
        }
      }
    });
  }
}

// ---------- class MakeApp ---------- //
new class MakeApp {
  constructor() {
    prop(this, {
      _debug: '',
      _resource: null,
      _controllers: new Map,
      _launcher: new Set,
      _require: new Set,
    });

    const {_launcher} = this;
    window.MakeApp = (...name) => (name.forEach(v => _launcher.add(v)), this);
    document.addEventListener('DOMContentLoaded', x => this._bootstrap());
  }
  async _bootstrap() {
    this._resource = document.body.appendChild(el('div'));

    const {_resource, _require, _launcher, _controllers} = this;
    _resource.setAttribute(DIF_RESOURCE, '');

    await this.loadLibrary(..._require);
    await Promise.all([..._controllers].map(([ky, vl]) => vl.initComponent && vl.initComponent()));

    [..._launcher].forEach(name => this.get(name).open());
    Object.freeze(this);
  }

  // method
  debug(...name) { this._debug = name; }
  require(...link) { link.forEach(v => this._require.add(v)); }
  get(name, option={}) {
    if(!name) return error(`invalid Controller name`);

    const {_controllers, _resource:resource, _debug:debug} = this;
    if(!_controllers.has(name)) return error(`cannot find controller "${name}"`);

    return _controllers.get(name).option(prop(option, {debug, resource}));
  }
  view(_name, _procedure) {
    if(!this._checkController('view', _name, _procedure)) return;
    const {_controllers} = this;
    _controllers.set(_name, View.GET({_name, _procedure}));
  }
  popup(_name, _procedure) {
    if(!this._checkController('popup', _name, _procedure)) return;
    const {_controllers} = this;
    _controllers.set(_name, Popup.GET({_name, _procedure}));
  }
  component(_name, _procedure) {
    if(!this._checkController('component', _name, _procedure)) return;
    const {_controllers} = this;
    _controllers.set(_name, Component.GET({_name, _procedure}));
  }
  directive(name, procedure) {
    if(!name || !procedure) return error(`directive invalid parameter: pname, procedure`);
    if(typeof procedure != 'function') return error(`directive type error: procedure is function`);

    const handle = {};
    procedure(handle);
    const {init, update} = handle;

    ko.bindingHandlers[name] = {
			init(el, vl, bind, model, context) { init && init(el, vl(), model.ctrl); }, 
			update(el, vl, bind, model, context) { update && update(el, vl(), model.ctrl); }
		};
  }
  service(name, procedure) {
    if(!name || !procedure) return error(`service method invalid parameter: pname, procedure`);
    if(typeof procedure != 'function') return error(`service type error: procedure is function`);
    if(this[name]) return;

    this[name] = procedure;
  }
  _checkController(type, name, procedure) {
    if(!name || !procedure) return error(`"${type}" contorller invalid parameter: name, procedure`);
    if(typeof procedure != 'function') return error(`"${type}:${name}" constorller type error: procedure is function`);
    return true;
  }

  // utils
  // 에러로그 가저오는 기능 추가
  error(vl) { error(vl, false); }
  queryResource(vl) { return this._resource.querySelector(vl); }
  appendResource(vl) { return this._resource.appendChild(vl); }
  removeResource(vl) { this._resource.removeChild(vl); }
  animation(selector, befor) { return animation(selector, befor); }
  loadLibrary(...link) {
    return Promise.all(link.map(vl => new Promise((resolve, reject) => {
      if(!/\.js$|\.css$/.test(vl)) return reject(`cannot include: ${vl}`);

      const lib = document.head.appendChild(el(/\.js$/.test(vl) ? 'script' : 'link'));
      if(/\.js$/.test(vl)) lib.src = `${vl}?v=${datetime('YMD')}`;
      else {
        lib.rel = 'stylesheet';
        lib.href = `${vl}?v=${datetime('YMD')}`;
      }
      lib.onload = x => resolve({ load: true, name: vl });
      lib.onerror = x => resolve({ load: false, name: vl });
    })));
  }
}

