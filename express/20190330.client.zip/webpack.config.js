// webpack --env.version=2.1 웹팩 CLI에 파라메터 넘길때

const webpack = require('webpack');
const package = require('./package.json');

module.exports = (env, {mode='production'}) => {
	let outdir = '/asset';
	const entry = {};
	const rules = [];
	const module = {rules};
	const rulesTransfile = {
		test: /\.js$/,
		loader: 'babel-loader',
		exclude: /node_modules/,
		query: {
			// presets: [[
			// 	'env',
			// 	{ targets: {ie:6}, debug: true, useBuiltIns: true,}
			// ]],
			presets: [['env']]
		},
	};
	const rulesSass = {
		test: /\.scss$|\.sass$|\.css$/,
		use: [
			{ loader: 'style-loader', options: { insertAt: 'top' } },
			{ loader: 'css-loader' },
			{ loader: 'sass-loader' },
		],
	};

	entry[`make-up`] = [
		'whatwg-fetch',
		'babel-polyfill',
		'./src/app.js',
	];

	rules.push(rulesTransfile);
	rules.push(rulesSass);

	return {
		mode,
		module,
		entry,
		output: {
			path: __dirname + outdir,
			filename: '[name].js',
		},
		plugins: [
			new webpack.BannerPlugin(({chunk:{name}}) => {
				return {
					'make-up': [
						`${package.name} JavaScript library v${package.version}`,
						package.libLicense.knockoutjs,
					].join('\n'),
				}[name] || '';
			}),
		],
	}
};
