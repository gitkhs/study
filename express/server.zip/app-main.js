global.appRequire = require('module').createRequireFromPath('./');
global.throwRestful = (req, res, next, err)=> {
  req.headers['content-type'] = 'application/json';
  next(err);
};

require('dotenv').config();
const express = require('express');
const path = require('path');
const cookie = require('cookie-parser');
const session = require('express-session');
const log = require('./log');
const app = express();

const {env: {APP_PORT, NODE_ENV, COOKIE_SECRET}} = process;
const isProd = NODE_ENV == 'production';

app.set('port', APP_PORT);
app.set('views', path.join(__dirname, 'views/main'));
app.set('view engine', 'pug');

app.use(express.static(path.join(__dirname, 'views/main/public')));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookie(COOKIE_SECRET));
app.use(session({
  secret: COOKIE_SECRET,
  resave: false,  // 요청이 왔을때 수정사항이 존재시 저장 여부 (true:강제저장)
  saveUninitialized: false, // 세션 내용이 존재시 저장 여부 (true:강제저장)
  cookie: {
    httpOnly: true,   // 클라이언트에서 쿠키값 확인 가능여부 (true: 조회불가능)
    secure: false,    // https 필수 사용여부
  },
}));

// 라우터 로드
const router = require('./router');
router(app, {dir:'main'});
// 서버 스타드
app.listen(APP_PORT, _=> {
  log.info('server start:', isProd ? {APP_PORT} : {URL:`http://localhost:${APP_PORT}`});
  // setInterval(_=>{
  //   log.info('-main test-');
  // }, 5000);
});
