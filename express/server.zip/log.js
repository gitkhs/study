const timestamp = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]||'');
const datetime = color => isDev ? `\x1b[${color}m${timestamp()}\x1b[0m` : timestamp();
const isDev = !process.env.NODE_ENV;

const log = {};
log.debug = (...vl) => isDev && console.log(datetime('34'), 'debug| ', ...vl);
log.info = (...vl) => console.log(datetime('33'), 'info | ' , ...vl);
log.error = (...vl) => console.error(datetime('31'), 'error| ' , ...vl);
module.exports = log;