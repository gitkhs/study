const pm2 = require('pm2');
const {prop, calcByte} = appRequire('./util');

const remap = (vl, isAll) => vl.map(({
  pid,
  monit:{memory=0, cpu=0}={},
  pm2_env: {
    username, status, name, pm_id,
    pm_out_log_path:out_path, pm_err_log_path:err_path, restart_time:restart
  }={},
}) => prop({
  name, pm_id, status, cpu, restart,
  memory: calcByte(memory),
}, isAll && {
  out_path, err_path,
}));

exports.disconnect = x => new Promise((s, j)=> pm2.disconnect(e=> (e ? j(e) : s())));
exports.connect = x => new Promise((s, j)=> pm2.connect(e=> (e ? j(e) : s())));
exports.list = x => new Promise((s, j)=> pm2.list((e, l)=> (e ? j(e) : s(remap(l)))));
exports.restart = pid => new Promise((s, j)=> pm2.restart(pid, (e, l)=> (e ? j(e) : s(remap(l)))));
exports.stop = pid => new Promise((s, j)=> pm2.stop(pid, (e, l)=> (e ? j(e) : s(remap(l)))));
exports.describe = pid => new Promise((s, j)=> pm2.describe(pid, (e, l)=> (e ? j(e) : s(remap(l,1)))));

// const pm2Start = pid => new Promise((s, j) =>
//   pm2.restart(pid, (e, l) => e ? j(e) : s(pm2Remap(l))));
// const pm2Stop = pid => new Promise((s, j) => pm2.stop(pid, (e, l) => e ? j(e) : s(pm2Remap(l))));
// const pm2Describe = pid => new Promise((s, j) => pm2.describe(pid, (e, l) => e ? j(e) : s(pm2Remap(l, true))));
