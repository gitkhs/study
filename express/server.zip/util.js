const menu = appRequire('./views/manager/public/menu.json');
const timestamp = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]||'');

const prop = (...v) => Object.assign(...v);
const isFunction = vl => typeof vl == 'function';
const calcByte = (v, c=0, k=1024) => (v<k ? `${v.toFixed(2)} ${' KMGT'.split('')[c]}B` : calcByte(v/k,++c));
const mangle = (vl, wt) => {
	if(wt === 0) return '';
	return decodeURIComponent(vl.split('').map(v => String.fromCharCode(v.charCodeAt(0)>>wt)).join('').substr(8));
};
const viewData = (d1, d2, ...vl)=> prop({now: timestamp('YMD')}, d1===undefined || menu[d1].links[d2], ...vl);

module.exports = {
	prop,
	isFunction, calcByte, mangle,
	timestamp,
	viewData,
};
