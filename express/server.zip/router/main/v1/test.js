const router = require('express').Router();
const log = appRequire('./log');

/**
 * @swagger
 * /test:
 *   get:
 *     tags:
 *     - "test"
 *     summary: "get 샘플"
 *     description: "파라메터값을 쿼리스트링(?xxx=xxx) 형식으로 전달
 *       abcd"
 *     operationId: "get"
 *     parameters:
 *     - name: "number"
 *       in: "query"
 *       description: "숫자입력(필수입력)"
 *       type: "integer"
 *       required: true
 *     - name: "string"
 *       in: "query"
 *       description: "문자입력"
 *       type: "string"
 *     responses:
 *       200:
 *         description: "정상"
 *         schema:
 *           type: "object"
 *           properties:
 *             method:
 *               type: "string"
 *             query:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 */

router.get('/', (req, res, next)=> {
  // throwRestful(req, res, next, {message:'xxxbbb'});
  const {query} = req;
  log.debug('/test', {query});
  res.json({test:1})
});

module.exports = router;
