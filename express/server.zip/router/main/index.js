const router = require('express').Router();

// restful document
const ui = require('swagger-ui-express');
const doc = require('swagger-jsdoc');
const { env: {APP_PORT} } = process;
router.use('/doc', ui.serve, ui.setup(doc({
  swaggerDefinition: {
    info: {
      title: 'test API',
      version: '1.0.0',
      description: 'api Specitication',
    },
    host: `localhost:${APP_PORT}`,
    basePath: '/v1'
  },
  apis: [
    'router/main/v1/*.js',
    'router/main/v1/*/*.js',
  ],
})));

// set cors(Cross-Origin Resource Sharing)
const cors = require('cors');
router.use((req, res, next)=> {
  cors({origin:req.get('origin')})(req, res, next);
  // if(req.get('origin') == 'http://127.0.0.1:4444')
  //   cors({origin:req.get('origin')})(req, res, next);
  // else next();
});

router.get('/', (req, res, next)=> {
  throwRestful(req, res, next, {message:'xxxbbb'});
});
module.exports = router;
