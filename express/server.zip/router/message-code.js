const message = new Map;
const invalidToken = Symbol('invalidToken');
message.set(invalidToken, '유효하지 않은 인증정보 입니다.');

const expiredToken = Symbol('expiredToken');
message.set(expiredToken, '만료된 인증정보 입니다.');

const accessDenied = Symbol('accessDenied');
message.set(accessDenied, '접근 권한이 없습니다.');

const invalidParam = Symbol('invalidParam');
message.set(invalidParam, '유효하지 않은 입력정보 입니다.');

    //   '400': '유효하지 않은 요청 입니다.',    // 400: 잘못된 요청
    //   '401': '유효하지 않은 인증서 입니다.',  // 401: 권한없음: 로그인필요, 인증실패
    //   // '402': '유효하지 않은 권한 입니다.',    // 402: 결제필요(접근권한)
    //   '403': '접근 권한이 없습니다.',         // 403: 접근금지: 로그인성공, 접근권한없음
    //   '412': '유효하지 않은 입력 입니다.',    // 412: 사전조건 실패: 입력값 오류
    //   '500': '처리가 지연되어 죄송합니다.',

module.exports = {
  invalidToken, expiredToken, accessDenied, invalidParam,
  getMessage(code) { return message.get(code) || '서버오류'; }
};