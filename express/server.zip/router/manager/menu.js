const router = require('express').Router();

router.get('/', (req, res)=> res.json(appRequire('./views/manager/public/menu.json')));
module.exports = router;
