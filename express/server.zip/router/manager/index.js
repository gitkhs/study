const router = require('express').Router();
const {viewData} = appRequire('./util');

router.get('/', (req, res)=> res.render('default', viewData()));

module.exports = router;
