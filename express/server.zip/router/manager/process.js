const router = require('express').Router();
const {viewData} = appRequire('./util');
const pm2 = appRequire('./modules/pm2');

// 화면
router.get('/', (req, res)=> res.render('default', viewData(0,1)));
// 조회
router.get('/list', (req, res)=> pm2.list().then(data => res.json(data)));
// 시작
router.post('/start', ({originalUrl, body:{pm_id}}, res, next)=> {
  if(pm_id === undefined) return next({originalUrl, message:'프로세스 아이디 미입력.'});
  pm2.restart(pm_id).then(([data]) => res.json(data));
  // const {jwt:{mangle:{pid,han}={}}={}} = req;
  // if(pid === undefined) return next({status:412});
  // logger.debug('processStart', {pid,han});
  // pm2.restart(pid).then(data => res.json(data));
});
// 종료
router.post('/stop', ({originalUrl, body:{pm_id}}, res, next)=> {
  if(pm_id === undefined) return next({originalUrl, message:'프로세스 아이디 미입력.'});
  pm2.stop(pm_id).then(([data]) => res.json(data));
});

module.exports = router;
