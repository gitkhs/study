const router = require('express').Router();
const root = 'template';

router.get('/pop-alert', (req, res)=> res.render(`${root}/pop-alert`));
router.get('/pop-confirm', (req, res)=> res.render(`${root}/pop-confirm`));

router.get('/nav-top', (req, res)=> res.render(`${root}/nav-top`));
router.get('/nav-side', (req, res)=> res.render(`${root}/nav-side`));

router.get('/deploy', (req, res)=> res.render(`${root}/deploy`));
router.get('/process', (req, res)=> res.render(`${root}/process`));
router.get('/process/logs', (req, res)=> res.render(`${root}/process/logs`));

module.exports = router;
