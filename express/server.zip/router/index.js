const fs = require('fs');
const log = appRequire('./log');
const readdir = vl => fs.readdirSync(`router/${vl}`);
const isdir = vl => fs.statSync(`router/${vl}`).isDirectory();

module.exports = (app, {dir=''}) => {
  const useRouter = path => {
    readdir(path).forEach(v => {
      if(isdir(`${path}/${v}`)) useRouter(`${path}/${v}`);
      else {
        if(/\.js$/.test(v) == false) return;

        const router = require(`./${path}/${v}`);
        if(typeof router == 'function' && router.name == 'router') {
          const url = `/${path}/${v.replace(/index.js$|\.js$/, '')}`.replace(RegExp(`^/${dir}`), '');
          app.use(url, router);
          log.info('load router: ', {url, file:`/${path}/${v}`});
        }
      }
    });
  };

  // 라우터 로드
  useRouter(dir);

  // 페이지없음 처리
  app.use((req, res) => {
    const isJson = /application\/json/.test(req.headers['content-type']);
    res.status(404);
    isJson ? res.json({message:'지원하지 않는 서비스입니다.[404]'}) : res.render('error-404', {title:'page notfound'});
  });

  // 오류처리
  app.use((err, req, res, next) => {
    const isJson = /application\/json/.test(req.headers['content-type']);
    const {message} = err;

    log.error({err});
    res.status(500);
    isJson ? res.json({message}) : res.render('error', {message});
  });
};