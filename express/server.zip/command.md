# 서버커맨드

## pm2
```
# 프로세스 조회
pm2 list

# 프로세스 시작
pm2 start <id|name>
# -i: 클러스터 개수, 0일경우 가능한 갯수로 시작
# --name: 프로세스 별칭 지정
pm2 start app.js -i 2 --name app-main

# 프로세스 재시작
pm2 restart <id|name>

# 프로세스 종료
pm2 stop <id|name>

# 프로세스 로그확인
pm2 logs <id|name>
# 모든로그 삭제
pm2 flush

# 프로세스 모니터링
pm2 monit
```