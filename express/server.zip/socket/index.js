const fs = require('fs');
const socketIO = require('socket.io');
const log = appRequire('./log');
const readdir = vl => fs.readdirSync(`socket/${vl}`);
const isdir = vl => fs.statSync(`socket/${vl}`).isDirectory();

module.exports = (server, opt) => {
  const {dir, path} = opt;
  socketIO(server, {path}).on('connection', socket=> {
    const distroy = [];
    const {request, id} = socket;
    const ip = request.headers['x-forwarded-for'] || request.connection.remoteAddress;
    const socketListener = path => {
      readdir(path).forEach(v => {
        if(isdir(`${path}/${v}`)) useRouter(`${path}/${v}`);
        else {
          if(/\.js$/.test(v) == false) return;

          Object.entries(require(`./${path}/${v}`)).forEach(([ky,vl])=>
            vl && distroy.push(vl(socket, (...vl)=>
              log.info('socket', {id, file:`${path}/${v}`, procedure:ky}, ...vl)
            ))
          );
        }
      });
    };

    // 소켓 접속
    log.info('socket connect', {id, ip});
    // 소켓 리스너 등록
    socketListener(dir);
    // 소켓 종료
    socket.on('disconnect', x => {
      log.info('socket disconnect', {id});
      distroy.forEach(v=> v && v());
    });
  });
};