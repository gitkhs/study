const fs = require('fs');
const pm2 = appRequire('./modules/pm2');
exports.status = (socket, loger)=> {
  let isWork = true;
  socket.on('process/status', _=> {
    const getList = async _=> {
      socket.emit('process/status', await pm2.list());
      isWork && setTimeout(getList, 1000);
    };
    getList();
  });
  return _=> { isWork = false; };
};

exports.logs = (socket, loger)=> {
  let isWork = true;
  socket.on('process/logs', async pm_id=> {
    if(pm_id === undefined) return socket.emit('process/logs', {message:'프로세스 아이디 미입력'});
    isWork = true;

    const MAX = 1024;
    const [{out_path, err_path}] = await pm2.describe(pm_id);
    const outFd=fs.openSync(out_path, 'r'), errFd=fs.openSync(err_path, 'r');
    const println = (tag, data)=> {
      const text = data.toString();
      const out = text.substr(0, text.indexOf('\n')+1);
      out && socket.emit('process/logs', {[tag]:out});
      return out.length;
    };
    const readFile = (outStart, errStart)=> {
      isWork && fs.createReadStream(out_path, {
        start:outStart, end:outStart+MAX
      }).on('data', data=> {
        outStart += println('out', data);
      }).on('end', _=> {
        const {size} = fs.fstatSync(outFd);
        fs.createReadStream(err_path, {
          start:errStart, end:errStart+MAX
        }).on('data', data=> {
          errStart += println('err', data);
        }).on('end', _=> {
          setTimeout(_=> readFile(outStart, errStart), size > outStart ? 100 : 500);
          // setTimeout(_=> readFile(outStart, errStart), size > outStart ? 100 : 500);
          // watch를 사용하면 좋은데 파일에대한 리터칭이 발생해야 노티가 온다.
          //fs.watch(path, readToNotify);
        });
      });
    };

    const {size:outSize} = fs.fstatSync(outFd);
    const outStart = outSize < MAX ? 0 : outSize-MAX;
    const {size:errSize} = fs.fstatSync(errFd);
    const errStart = errSize < MAX ? 0 : errSize-MAX;
    const tailPosition = (data, cnt=10)=> {
      const text = data.toString();
      let pos=len=text.length;
      while(len--) {
        if(text[len] == '\n') {
          if(cnt-- < 0) break;
          pos = len;
        }
      }
      return pos+1;
    };

    let outTail;
    fs.createReadStream(out_path, {start:outStart}).on('data', data=> {
      outTail = outStart + tailPosition(data)
    }).on('end', _=> {
      fs.createReadStream(err_path, {start:errStart}).on('data', data=> {
        readFile(outTail, errStart + tailPosition(data));
      });
    });
  }).on('process/logs/close', ({pm_id})=> {
    isWork = false;
  });

  return _=> { isWork = false; };
};