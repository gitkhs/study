exports.deploy = (socket, loger)=> {
  socket.on('deploy', data=> {
    // id = setInterval(_=> {
    //   loger('deploy', {data});
    //   socket.emit('deploy/out', {xxx:1});
    // }, 1000);

    loger('deploy', {data});
    socket.emit('deploy', {out:'process stop'});
    socket.emit('deploy', {out:'source backup'});
    socket.emit('deploy', {out:'xxx'});
    socket.disconnect();
  });
};
