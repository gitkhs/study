(app=> {
app.require('/socket-io/socket.io.js');
app.view('index', ctrl=> {
  const http=ctrl.http();
  const socket = io.connect(location.origin, {path: '/socket-io'});
  ctrl.url = '/template/process/';
  ctrl.css({row:1});

  ctrl.vo.list = ctrl.observer([]);
  http.get('/process/list').then(data=> {
    const {assign} = app.util;
    const toggleProcess = (act, vo)=> {
      const {pm_id} = vo;
      http.post(`/process/${act}`, {pm_id}).then(({restart, status, cpu, memory})=>
        vo.cpu(cpu).restart(restart).memory(memory).status(status).online(status=='online')
      );
    };

    data.forEach(vl=> {
      const {status, restart, cpu, memory} = vl;
      ctrl.vo.list.push(assign(vl, {
        restart: ctrl.observer(restart),
        cpu: ctrl.observer(cpu),
        memory: ctrl.observer(memory),
        status: ctrl.observer(status),
        online: ctrl.observer(status=='online'),
        start: ctrl.handler().event('click', (evt, vo)=> toggleProcess('start', vo)),
        stop: ctrl.handler().event('click', (evt, vo)=> toggleProcess('stop', vo)),
        log: ctrl.handler().event('click', (evt, vo)=> ctrl.open('logs', {socket, item:vo}))
      }));
    });
    return data.length;
  }).then(pss=> {
    if(!pss) return;

    socket.emit('process/status');
    socket.on('process/status', data=> {
      data.forEach(({pm_id, restart, status, cpu, memory})=> {
        ctrl.vo.list.$data.some(vo=> {
          if(pm_id == vo.pm_id) {
            vo.status(status).cpu(cpu).restart(restart).memory(memory).online(status=='online');
            return true;
          }
        });
      });
    });
  });
});

// 로그조회
app.popup('logs', (ctrl, {socket, item})=> {
  const {vo, on} = ctrl;
  ctrl.url = '/template/process/logs';
  ctrl.css({sheet:true});
  ctrl.onload = _=> {
    const {pm_id} = item;
    socket.emit('process/logs', pm_id);
    socket.on('process/logs', ({out, err, message})=> {
      if(message) return ctrl.alert(message).then(_=>ctrl.close());
      out && vo.outList.push(out);
      err && vo.errList.push(err);
    });
  };

  // value
  vo.out = ctrl.observer(true);
  vo.err = ctrl.observer(false);
  vo.outList = ctrl.observer([]);
  vo.errList = ctrl.observer([]);
  vo.status = item.status;
  vo.memory = item.memory;
  vo.cpu = item.cpu;
  vo.online = item.online;
  // event
  on.close = ctrl.handler().event('click', _=> {
    const {pm_id} = item;
    socket.emit('process/logs/close', {pm_id});
    ctrl.close();
  });
  on.out = ctrl.handler().event('click', _=> vo.out(true).err(false));
  on.err = ctrl.handler().event('click', _=> vo.out(false).err(true));
});
})(MakeApp());