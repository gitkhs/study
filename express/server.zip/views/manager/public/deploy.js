(app=> {
app.require('/socket-io/socket.io.js');
app.view('index', ctrl=> {
  const {vo, on} = ctrl;
  ctrl.url = '/template/deploy/';
  ctrl.css({row:1});

  vo.list = ctrl.observer([]);
  on.deploy = ctrl.handler().event('click', _=> {
    const socket = io.connect(location.origin, {path: '/socket-io'});

    vo.list.removeAll();
    socket.emit('deploy', {start:1});
    socket.on('deploy', data => {
      ctrl.log({data});
      vo.list.push(data);
    });
  });
});
})(MakeApp());