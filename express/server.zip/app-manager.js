global.appRequire = require('module').createRequireFromPath('./');

require('dotenv').config();
const express = require('express');
const morgan = require('morgan');
const path = require('path');
const cookie = require('cookie-parser');
const session = require('express-session');
const log = require('./log');
const app = express();

const {env: {APP_PORT, NODE_ENV, COOKIE_SECRET}} = process;
const isProd = NODE_ENV == 'production';

app.set('port', APP_PORT);
app.set('views', path.join(__dirname, 'views/manager'));
app.set('view engine', 'pug');

// app.use(morgan(isProd ? 'combined' : 'dev'));
// isProd && app.use(morgan('combined'));
app.use(express.static(path.join(__dirname, 'views/manager/public')));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookie(COOKIE_SECRET));
app.use(session({
  secret: COOKIE_SECRET,
  resave: false,  // 요청이 왔을때 수정사항이 존재시 저장 여부 (true:강제저장)
  saveUninitialized: false, // 세션 내용이 존재시 저장 여부 (true:강제저장)
  cookie: {
    httpOnly: true,   // 클라이언트에서 쿠키값 확인 가능여부 (true: 조회불가능)
    secure: false,    // https 필수 사용여부
  },
}));


// 라우터 로드
const router = require('./router');
router(app, {dir:'manager'});
// 서버 스타드
const server = app.listen(app.get('port'), _=> {
  log.info('server start:', isProd ? {APP_PORT} : {URL:`http://localhost:${APP_PORT}`});
});
// 소켓 로드
const socket = require('./socket');
socket(server, {dir:'manager', path:'/socket-io'});

// const socketIO = require('socket.io');
// socketIO(server, {path: '/socket-io'}).on('connection', socket=> {
//   // req.connection.server
//   // res.connection.server
//   const {request, id} = socket;
//   const ip = request.headers['x-forwarded-for'] || request.connection.remoteAddress;

//   log.debug('socket connection', {id, ip});
//   socket.on('disconnect', x => {
//     log.debug('socket disconnect', {id, ip});
//     // ctrl.clearSocket(socket);
//   });

//   socket.on('deploy', data => {
//     log.debug('deploy', {data});
//     socket.emit('deploy', {xxx:1});
//   });
// //   socket.on('pm-list', data => ctrl.onSocket('pm-list', socket, data));
// });
