global.requireApp = require('module').createRequireFromPath('./');

require('dotenv').config();
const express = require('express');
const morgan = require('morgan');
const path = require('path');
const cookie = require('cookie-parser');
const session = require('express-session');
const app = express();

const {env: {APP_PORT, NODE_ENV, COOKIE_SECRET}} = process;
const {logger} = requireApp('./util');

app.set('port', APP_PORT);
app.set('views', path.join(__dirname, 'views/manager'));
app.set('view engine', 'pug');

NODE_ENV == 'production' || app.use(morgan(NODE_ENV == 'production' ? 'combined' : 'dev'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookie(COOKIE_SECRET));
app.use(session({
  secret: COOKIE_SECRET,
  resave: false,  // 요청이 왔을때 수정사항이 존재시 저장 여부 (true:강제저장)
  saveUninitialized: false, // 세션 내용이 존재시 저장 여부 (true:강제저장)
  cookie: {
    httpOnly: true,   // 클라이언트에서 쿠키값 확인 가능여부 (true: 조회불가능)
    secure: false,    // https 필수 사용여부
  },
}));

// 컨트롤러 등록
const ctrl = requireApp('./controller').GET(app, 'manager');
app.use('/', ctrl.router);
// 페이지없음 처리
app.use((req, res) => {
  res.status(404);
  req.method.toUpperCase() == 'GET' ?
  res.render('error', {message: '페이지가 존재하지 않습니다.'}) :
  res.render({status:404, message: '지원하지 않는 서비스입니다.'})
});
// 오류처리
app.use((err, req, res, next) => {
  console.log('----------- app error --------------');
  const {status=500, type='json', code='100'} = err;
  const defMessage = {
    '400': '유효하지 않은 요청 입니다.',    // 400: 잘못된 요청
    '401': '유효하지 않은 인증서 입니다.',  // 401: 권한없음: 로그인필요, 인증실패
    // '402': '유효하지 않은 권한 입니다.',    // 402: 결제필요(접근권한)
    '403': '접근 권한이 없습니다.',         // 403: 접근금지: 로그인성공, 접근권한없음
    '412': '유효하지 않은 입력 입니다.',    // 412: 사전조건 실패: 입력값 오류
    '500': '처리가 지연되어 죄송합니다.',
  };
  const message = err.message || defMessage[status];

  res.status(status);
  type == 'render' ?
  res.render('error', {message}) :
  res.json({status, message});
});

const socketIO = require('socket.io');
const server = app.listen(app.get('port'), x => logger.info('server start', {APP_PORT}));
socketIO(server, {path: '/socket.io'}).on('connection', socket => {
  const {request, id} = socket;
  const ip = request.headers['x-forwarded-for'] || request.connection.remoteAddress;

  logger.debug('socket connection', {id, ip});
  socket.on('disconnect', x => {
    logger.debug('socket disconnect', {id, ip});
    ctrl.clearSocket(socket);
  });

  socket.on('deploy', data => ctrl.onSocket('deploy', socket, data));
  socket.on('pm-list', data => ctrl.onSocket('pm-list', socket, data));
});
