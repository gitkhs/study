var timestamp = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]||'');

const prop = (...v) => Object.assign(...v);
const isDev = !process.env.NODE_ENV;
const datetime = color => isDev ? `\x1b[${color}m${timestamp()}\x1b[0m` : timestamp();
const logger = {
  div(v='') { isDev && console.log(v.repeat(30)); return logger; },
  debug(...vl) { isDev && console.log(datetime('34'), 'debug| ', ...vl); return logger; },
  info(...vl) { console.log(datetime('33'), 'info | ' , ...vl); return logger; },
  error(...vl) { console.error(datetime('31'), 'error| ' , ...vl); return logger; },
};
const error = (req, {out, view, status, message}) => {
	logger.error({out, view, status, message});
	req.error = {out, view, status, message};
};
const isFunction = vl => typeof vl == 'function';
const calcByte = (v, c=0, k=1024) => (v<k ? `${v.toFixed(2)} ${' KMGT'.split('')[c]}B` : calcByte(v/k,++c));


module.exports = {
	prop, logger, error,
	isFunction, calcByte,
};
