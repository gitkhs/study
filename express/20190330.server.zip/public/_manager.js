(app => {


app.require('/socket.io/socket.io.js');
app.view('signIn', ctrl => {
  ctrl.onload(prm => {
    ctrl.vo.deactive(false);
    const name = location.pathname.substr(1);
    name && app.controller()[name].open();
  });

  ctrl.vo.deactive = ctrl.observer(true);

  ctrl.vo.email = ctrl.observer('');
  ctrl.on.email = ctrl.event(handle => {
    handle.check = (vl) => {
      if(!vl) return 'invalid email';
      if(/^\d|^@|@$/.test(vl) || !/\w+@\w+\.\w+$/.test(vl)) return 'check email input value';
    };
  });

  ctrl.vo.password = ctrl.observer('');
  ctrl.on.password = ctrl.event(handle => {
    handle.check = (vl) => {
      if(!vl) return 'invalid password';
      if(vl.length < 4) return 'check password input value';
    };
    handle.keyup = (vo, evt) => {
      const {deactive} = ctrl.vo;
      const {email: onEmail, password: onPassword} = ctrl.on;
      deactive(onEmail.invalidate() || onPassword.invalidate());
    };
  });

  ctrl.on.login = ctrl.event(listener => {
    listener.click = (obs, evt) => {
      // const {email: voEmail, password: voPassword} = ctrl.vo;
      // const {email: onEmail, password: onPassword} = ctrl.on;

      // if(onEmail.invalidate()) return;
      // if(onPassword.invalidate()) return;

      // ctrl.log(`email: ${voEmail()}\npassword: ${voPassword()}`);
      const http = app.http({ctrl, focus: evt});
      http.post('/sign-in', {email:'2109@2109.com', password: '1234'})
        .then(x => location.reload());
    };
  });
});

// ----- dashboard ----- //
app.view('dashboard', ctrl => {
  const {processMonit} = app.controller();
  processMonit.initialize({type: 'list'});

  ctrl.onload(prm => {
  });

  ctrl.vo.socket = ctrl.observer();
});

// ----- process ----- //
app.view('process', ctrl => {
  const {processMonit} = app.controller();
  processMonit.initialize({type: 'card'});

  ctrl.onload();
});

// ----- processMonit ----- //
app.component('processMonit', ctrl => {
  let _socket;
  ctrl.onload(({type}) => {
    const {isList} = ctrl.vo;
    const http = app.http({ctrl});
    _socket = io.connect(location.origin, {path: '/socket.io'});
    _socket.on('process', data => _procProcess.forEach(vl => vl(data)));
    _socket.on('tracelog', data => _procTracelog.forEach(vl => vl(data)));

    isList(type == 'list');
    http.get('/dashboard/process').then(data => {
      if(!data || !data.length) return;

      const {process} = ctrl.vo;
      const f = (item = data.shift()) => {
        if(!item) return;

        const {name, pm_id, status, memory, cpu, restart} = item;
        const isOnline = status=='online';
        process.push({
          name, pm_id,
          restart: ctrl.observer(restart),
          status: {
            text: ctrl.observer(status),
            css: ctrl.observer({
              'text-success': isOnline,
              'text-danger': !isOnline,
            }),
            textButton: ctrl.observer(isOnline ? 'stop' : 'start'),
            cssButton: ctrl.observer({
              'btn-danger': isOnline,
              'btn-primary': !isOnline,
            }),
            attrRestart: ctrl.observer({disabled: !isOnline}),
          },
          memory: ctrl.observer(memory),
          cpu: ctrl.observer(cpu),
          errorlog: ctrl.observer(''),
        });

        _socket.emit('tracelog', {target: `out_${pm_id}`, on: true});
        setTimeout(f, 200);
      };

      process.removeAll(), f();
      _socket.emit('process');
    });

    ctrl.onProcess(data => data.forEach(vl => _setData(vl)));
    ctrl.onTracelog(({target, log}) => {
      if(!/^out_/.test(target)) return;

      const [, id] = target.split('_');
      const {process} = ctrl.vo;
      const item = process().find(vl => id == vl.pm_id);
      item.errorlog(log + item.errorlog());
    });
  });

  const _procTracelog = [], _procProcess = [];
  ctrl.append('onProcess', proc => _procProcess.push(proc));
  ctrl.append('onTracelog', proc => _procTracelog.push(proc));

  ctrl.vo.process = ctrl.observer([]);
  ctrl.vo.isList = ctrl.observer(true);
  ctrl.on.log = ctrl.event(hnd => {
    hnd.click = (vl, evt) => {
      // const {processLog} = app.controller({focus: evt});
      // processLog.open();
      // const socket = ctrl.vo.socket();
      // socket.emit('tracelog', {target: `out_1`});
      // socket.emit('tracelog', {target: `out_0`});
      _socket.emit('tracelog', {target: `out_0`});
      _socket.emit('tracelog', {target: `out_1`});
    };
  });
  ctrl.on.restart = ctrl.event(hnd => {
    hnd.click = async (vl, evt) => {
      const {pm_id:id} = vl;
      const http = app.http({ctrl, focus: evt});
      const [data] = await http.submit(`/process/start`, {id});

      data && _setData(data);
    };
  });
  ctrl.on.stopStart = ctrl.event(hnd => {
    hnd.click = async (vl, evt) => {
      const {status:{textButton}, pm_id:id} = vl;
      const http = app.http({ctrl, focus: evt});
      const [data] = await http.submit(`/process/${textButton()}`, {id});

      data && _setData(data);
    };
  });
  const _setData = ({pm_id, restart, status, memory, cpu}) => {
    const {process} = ctrl.vo;
    const item = process().find(vl => pm_id == vl.pm_id);
    const isOnline = status=='online';
    if(!item) return;

    item.restart(restart);
    item.memory(memory);
    item.cpu(cpu);
    item.status.text(status);
    item.status.css({
      'text-success': isOnline,
      'text-danger': !isOnline,
    });
    item.status.textButton(isOnline ? 'stop' : 'start');
    item.status.cssButton({
      'btn-primary': !isOnline,
      'btn-danger': isOnline,
    });
    item.status.attrRestart({disabled: !isOnline});
  };

  const _itemData = `
  <div class="badge mr-2 mb-1">
    <span>name: </span>
    <span data-bind="text: $data.name" class="text-secondary">name</span>
  </div>
  <div class="badge mr-2 mb-1">
    <span>restart: </span>
    <span data-bind="text: $data.restart" class="text-primary">0</span>
  </div>
  <div class="badge mr-2 mb-1">
    <span>status: </span>
    <span data-bind="text: $data.status.text, css: $data.status.css">online</span>
  </div>
  <div class="badge mr-2 mb-1">
    <span>cpu: </span>
    <span data-bind="text: $data.cpu" class="text-info">cpu</span>
  </div>
  <div class="badge mr-2 mb-1">
    <span>memory: </span>
    <span data-bind="text: $data.memory" class="text-info">memory</span>
  </div>
  `;
  ctrl.html(`
  <!-- ko if: vo.isList --><!-- ko foreach: vo.process -->
    <li class="list-group-item d-flex flex-row justify-content-start flex-wrap">${_itemData}</li>
  <!-- /ko --><!-- /ko -->

  <!-- ko ifnot: vo.isList --><!-- ko foreach: vo.process -->
    <div class="col-12 col-sm-4 mb-3">
      <div class="card">
        <div class="card-body">
          <div class="d-flex flex-row justify-content-start flex-wrap mb-2">${_itemData}</div>
          <pre data-bind="text: $data.errorlog" class="code alert alert-secondary" style="height:10rem; overflow-y:auto;"></pre>
        </div>
        <div class="card-footer text-right">
          <button data-bind="event: $parent.on.log" class="btn btn-sm btn-secondary mr-2">log</button>
          <button data-bind="event: $parent.on.restart, attr: $data.status.attrRestart" class="btn btn-sm btn-success mr-2">restart</button>
          <button data-bind="
            text: $data.status.textButton,
            event: $parent.on.stopStart,
            css: $data.status.cssButton" class="btn btn-sm mr-2">stop</button>
        </div>
      </div>
    </div>
  <!-- /ko --><!-- /ko -->
  `);
});

// ----- log popup ----- //
app.popup('processLog', ctrl => {
  let cnt = 0;
  ctrl.onload(x => {
    const {logs} = ctrl.vo;
    while(cnt < 20) {
      logs.unshift(`Error: bind EADDRINUSE null:${cnt++}`);
    }
  });

  ctrl.vo.logs = ctrl.observer([]);
  ctrl.on.flush = ctrl.event(hndl => {
    hndl.click = (obs, evt) => {
      const {logs} = ctrl.vo;
      logs.unshift(`Error: bind EADDRINUSE null:${cnt++}`);
    };
  });
  ctrl.on.close = ctrl.event(hndl => {
    hndl.click = (obs, evt) => {
      ctrl.close();
    };
  });

  ctrl.clss({ 'bottom-sheet': true });
  ctrl.html([
    '<div class="card" data-app-motion>',
      '<div class="card-header d-flex flex-row justify-content-between flex-wrap">',
        '<div>',
          '<button data-bind="event: on.flush" class="btn btn-sm btn-secondary mr-2">flush</button>',
          '<button class="btn btn-sm btn-secondary mr-2">log</button>',
          '<button class="btn btn-sm btn-secondary">error</button>',
        '</div>',
        '<div>',
          '<button data-bind="event: on.close" class="btn btn-sm btn-primary">close</button>',
        '</div>',
      '</div>',
      '<div data-bind="foreach: vo.logs" class="card-body">',
        '<p data-bind="text: $data">message</p>',
      '</div>',
    '</div>',
  ]);
});

// ----- deploy ----- //
app.view('deploy', ctrl => {
  ctrl.onload(prm => {
    const http = app.http({ctrl});
    http.get('/dashboard/process').then(data => {
      if(!data || !data.length) return;

      const {process} = ctrl.vo;
      data.forEach(({name, pm_id, status}) => {
        name=='app' && process.push({
          pm_id,
          text: ctrl.observer(`${pm_id}: ${status}`),
          class: ctrl.observer({
            'text-success': status=='online',
            'text-danger': status!='online',
          }),
        });
      });
    });
  });

  ctrl.vo.process = ctrl.observer([]);
  ctrl.vo.listWork = ctrl.observer([]);
  ctrl.vo.isWorking = ctrl.observer(false);
  ctrl.on.deploy = ctrl.event(hand => {
    hand.click = (obs, evt) => {
      const {isWorking, listWork} = ctrl.vo;

      listWork.removeAll();
      isWorking(true);
      _socket.emit('deploy', {start:true});
    };
  });

  const _socket = io.connect(location.origin, {path: '/socket.io'});
  _socket.on('deploy', data => {
    const {isWorking, listWork, process} = ctrl.vo;
    const {end, pm_status, execute, output} = data;

    end && isWorking(false);

    execute && listWork.unshift({
      text: execute,
      offset: {'offset-1': true},
      type: {
        'alert-secondary': true,
        'text-right': true,
      },
    });

    output && listWork.unshift({
      text: output,
      type: {'alert-info': true},
    });

    pm_status && pm_status.forEach(({pm_id, status}) => {
      const item = process().find(vl => pm_id == vl.pm_id);
      if(!item) return;

      item.text(`${pm_id}: ${status}`);
      item.class({
        'text-success': status=='online',
        'text-danger': status!='online',
      });

      listWork.unshift({
        text: `app(${pm_id}): ${status}`,
        type: {'alert-info': true},
      });        
    });
  });

  _socket.on('process', data => {
    const {process} = ctrl.vo;
    data.forEach(({pm_id, status}) => {
      const item = process().find(vl => pm_id == vl.pm_id);
      if(!item) return;

      item.text(`${pm_id}: ${status}`);
      item.class({
        'text-success': status=='online',
        'text-danger': status!='online',
      });
    });
  });
});

// ----- alert ----- //
app.popup('alert', ctrl => {
  ctrl.onload(({msg='', ok='ok'}) => {
    const {message, btnok} = ctrl.vo;
    message(msg);
    btnok(ok);
  });

  ctrl.vo.message = ctrl.observer('');
  ctrl.vo.btnok = ctrl.observer('ok');
  ctrl.on.btnok = ctrl.event(handle => {
    handle.click = obs => ctrl.close();
  });

  ctrl.clss({ 'modal-layer': true });
  ctrl.html([
    '<div class="card" data-app-motion>',
      '<div class="card-body">',
        '<div data-bind="html: vo.message" class="card-text">message</div>',
      '</div>',
      '<div class="card-footer text-right">',
        '<button data-bind="text: vo.btnok, event: on.btnok" class="btn btn-sm btn-primary">ok</button>',
      '</div>',
    '</div>',
  ]);
});

// ========== common library ========== //
// invalid check
app.directive('invalidate', handle => {
  handle.init = (el, prm, ctrl) => {
		const fb = el.parentNode.insertBefore(document.createElement('div'), el.nextSibling);
    fb.classList.add('invalid-tooltip');

    prm.invalidate = () => {
      const msg = prm.check(el.value);
      if(msg) {
        fb.innerText = msg;
        el.classList.add('is-invalid');
        el.focus();
      } else el.classList.remove('is-invalid');

      return !!msg;
    };

    el.addEventListener('keyup', evt => prm.invalidate());
  };
});

// http
app.append('http', ({focus, progress, ctrl}={}) => {
  let _finish=null;
  const loading = bar => {
    if(bar === undefined) {
      let httpProgress = document.querySelector('[data-app-resource] .http-progress');
      if(httpProgress) return httpProgress;

      httpProgress = app.appendResource(document.createElement('div'));
      httpProgress.style.cssText = 'left:0; top:0; width:100vw; height:100vh;';
      httpProgress.innerHTML = '<div class="http-progress"></div>';
      return httpProgress;
    }

    bar && app.removeResource(bar);
  };
  const ajax = ({url, method, param}) => new Promise(async (resolve, reject) => {
    const {alert} = app.controller({focus});
    /^\/access/.test(url) ||
      ctrl && ctrl.log('style:{color:#aaf}', {url}, {method}, {param});

    try {
      const bar = loading();
      const rs = await fetch(url, {
        method,
        body: param && JSON.stringify(param),
        credentials: 'include',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });
      const {status, headers:rsHeaders} = rs;
      const contentType = rsHeaders.get('Content-Type');
      const data = (/text/.test(contentType) && await rs.text()) ||
        (/json/.test(contentType) && await rs.json());

      loading(progress == 'infinite' ? _finish : bar);
      /^\/access/.test(url) ||
        ctrl && ctrl.log('style:{color:#faa}', {url}, {data});

        if(status == 200) {
        resolve(data);
      }
      else {
        const {message} = data || {};
        alert.open({msg: message || 'error'}).then(x => {
          // 419: 만료된세션, 208: 기로그인
          if(status == 419 || status == 208) return location.reload();
          http.finish();
          loading(_finish);
          reject({status, message});
        });
      }
    } catch(e) {
      /^\/access/.test(url) ||
        ctrl && ctrl.log('style:{color:#faa}', {url}, e);

      alert.open({msg: 'server transaction fail'}).then(x => {
        http.finish();
        loading(_finish);
        reject({status:-100, message: e});
      });
    }
  });

  const http = {};
  http.finish = x => {
    _finish = document.querySelector('[data-app-resource] .http-progress');
    _finish = _finish && _finish.parentNode;
    return http;
  };
  http.get = url => ajax({ url, method: 'GET' });
  http.post = (url, param) => ajax({ url, method: 'POST', param});
  http.submit = (url, param) => http.get(`/access/${url.substr(1).replace(/\//g, '-')}`)
    .then(x => http.post(url, param));

  return http;
});


})(MakeApp('signIn'));
