(app => {
app.debug('localhost');

// ---------- view ---------- //
app.view('navbar', ctrl => {
  ctrl.vo.menu = { open: ctrl.observer(false) };
  ctrl.on.menu = ctrl.event(hd => {
    hd.click = x => {
      const {menu:{open}} = ctrl.vo;
      open(!open.$);
    };
  });
  ctrl.on.signout = ctrl.event(hd => {
    hd.click = async x => {
      await app.http().post('/sign-out');
      await app.get('alert').open({message: '로그아웃 되었습니다.'});
      location.href = '/';
    };
  });
});
// ---------- popup ---------- //
app.popup('alert', ctrl => {
  ctrl.onload(({message='', ok='ok'}) => {
    ctrl.vo.message(message);
    ctrl.vo.btnok(ok);
  });

  ctrl.vo.message = ctrl.observer('');
  ctrl.vo.btnok = ctrl.observer('ok');
  ctrl.on.btnok = ctrl.event(hd => {
    hd.click = x => ctrl.close();
  });

  ctrl.css = { 'modal-layer': true };
  ctrl.html = [
  '<div class="card" data-app-motion>',
    '<div class="card-body">',
      '<div data-bind="html: vo.message" class="card-text">message</div>',
    '</div>',
    '<div class="card-footer text-right">',
      '<button data-bind="text: vo.btnok, event: on.btnok"',
      ' class="btn btn-sm btn-primary">ok</button>',
    '</div>',
  '</div>',
  ].join('');
});

// ---------- directive ---------- //
app.directive('invalidate', hd => {
  hd.init = (el, prm={}, ctrl) => {
    const tolltip = el.parentNode.insertBefore(document.createElement('div'), el.nextSibling);
    tolltip.classList.add('invalid-tooltip');

    const {invalidate} = prm;
    if(!invalidate) return ctrl.error('directive:invalid', 'can not find', el.outerHTML);
    if(typeof invalidate != 'function')
      return ctrl.error('directive:invalid', 'type error', el.outerHTML);

    Object.defineProperty(prm, 'invalidate', {
      get() {
        const msg = invalidate(el.value);
        if(msg) {
          tolltip.innerText = msg;
          el.classList.add('is-invalid');
          el.focus();
        } else el.classList.remove('is-invalid');

        return !!msg;
      },
    });

    el.addEventListener('keyup', evt => prm.invalidate);
  };
});

// ---------- service ---------- //
app.service('goHome', x => (location.href='/'));
app.service('http', ({focus, progress, ctrl}={}) => {
  const alert = app.get('alert', {focus});  
  const loading = bar => {
    if(progress == 'none') return;
    if(bar === undefined) {
      const hp = app.queryResource('.http-progress');
      if(hp) return hp.parentNode;

      const nhp = app.appendResource(document.createElement('div'));
      nhp.style.cssText = 'left:0; top:0; width:100vw; height:100vh;';
      nhp.innerHTML = '<div class="http-progress"></div>';
      return nhp;
    } else progress == 'infinite' || app.removeResource(bar);
  };
  const finish = x => {
    const hp = app.queryResource('.http-progress');
    hp && app.removeResource(hp.parentNode);
  };
  const ajax = ({url, method, param}) => new Promise(async (resolve, reject) => {
    try {
      ctrl && ctrl.log('style:{color:#aaf}', {method, url, param});
      const bar = loading();
      const rs = await fetch(url, {
        method,
        body: param && JSON.stringify(param),
        credentials: 'include',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });
      const {status, headers:rsHeaders} = rs;
      const contentType = rsHeaders.get('Content-Type');
      const data = (/text/.test(contentType) && await rs.text()) ||
        (/json/.test(contentType) && await rs.json());

      ctrl && ctrl.log('style:{color:#faa}', {url, data});
      loading(bar);

      if(status == 200) resolve(data);
      else {
        const {message='error'} = data || {};
        alert.open({message}).then(x => {
          // 401: 인증만료, 208: 기로그인
          if(status == 208) return location.reload();
          if(status == 401) return (location.href = '/sign');

          reject({status, message});
        });
      }
    } catch(error) {
      ctrl && ctrl.log('style:{color:#f00}', {url, error});
      alert.open({message: 'server transaction fail'}).then(x => {
        finish();
        reject({status:-100, message: error});
      });
    }
  });

  // return object
  const http = {};
  http.finish = finish;
  http.get = url => ajax({ url, method:'GET' });
  http.post = (url, param={}) => ajax({url, method:'POST', param});
  http.submit = (url, param) => {
    const submit = `/submit/${url.replace(/^\//, '').replace(/\//g, '.')}`;
    return http.post(submit).then(x => http.post(url, param));
  };
  http.all = (vl, ...arg) => {
    progress = 'infinite';
    return Promise.all(arg.concat(vl)).then(data => (finish(), data));
  };
  return http;
});
app.service('expires', x => {
  const convtime = (
    str, tick=0,
    s=1000, m=s*60, h=m*60, d=h*24, w=d*7, y=d*365.25
  ) => {
    const match = /^((?:\d+)?\-?\d?\.?\d+) *(ms|s|m|h|d|w|y)?$/i.exec(str);
    if (!match) return;
  
    const type = (match.pop()||'ms').toLowerCase();
    const n = parseFloat(match.pop());
    return { ms:n, s:n*s, m:n*m, h:n*h, d:n*d, w:n*w, y:n*y }[type] - tick;
  };
  const bootstrap = x => fetch('/sign-expires', {
    method: 'POST',
    credentials: 'include',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
  }).then(rs => rs.json()).then(({expires}) => (expires ?
    setTimeout(bootstrap, convtime(expires, 2000)) :
    app.get('alert').open({message: 'expires auth'}).then(app.goHome)
  ));
  bootstrap();
});
})(MakeApp());
