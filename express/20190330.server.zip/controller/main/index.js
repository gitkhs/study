const router = require('express').Router();
const {logger} = requireApp('./util');

module.exports = ctrl => {
  logger.debug('-main-');
  return router;
};
