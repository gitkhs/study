const {expires} = requireApp('./controller/manager/libs/jwt');

const appError = class extends Error {
  static notfound(res, message) { new appError(res, message) }
  constructor(res, message='') {
    super();
    this.name = 'appError';
    this.message = message;
    this.stackTraceLimit = -1;
  }
};

// 로그인- 인증서 발급
exports.signIn = (req, res, next) => {
  const {body:{email, password}} = req;
  if(!email || !password) return next({status:412, message: '이메일 또는 비밀번호를 입력 해주세요.'});
  if(email != '2109@2109.com' || password != '2109a')
    return next({status:412, message: '이메일 또는 비밀번호를 잘못 입력했습니다.'});

  res.json({expires});
};
// 로그인- 인증서 삭제
exports.signOut = (req, res) => res.json({});
// 로그인- 인증서 갱신
exports.signExpires = (req, res) => res.json({expires});
