const router = require('express').Router();
const jwt = requireApp('./controller/manager/libs/jwt');

module.exports = ctrl => {

  // ========== 화면 ==========
  const {verifyRender, signRender} = jwt;
  const {wsDeploy, wsProcess} = require('./socket')(ctrl);
  const {home, sign, dashboard, deploy, process} = require('./view');

  router.get('/', verifyRender, home);                      // 홈
  router.get('/sign', signRender, sign);                    // 로그인
  router.get('/dashboard', verifyRender, dashboard);        // 대쉬보드
  router.get('/deploy', verifyRender, wsDeploy, deploy);    // 배포
  router.get('/process', verifyRender, wsProcess, process); // 프로세스

  // ========== 데이터 ==========
  const {verifyAuth, signAuth, removeAuth, signSubmit, verifySubmit} = jwt;

  // 권한키 발급
  router.post('/submit/:url', verifyAuth, signSubmit, (req, res) => res.json({}));

  // 로그인
  const {signIn, signOut, signExpires} = require('./sign');
  router.post('/sign-out', removeAuth, signOut);                    // 인증토큰삭제
  router.post('/sign-in', signAuth, signIn);                        // 인증토큰발급
  router.post('/sign-expires', verifyAuth, signAuth, signExpires);  // 인증토큰갱신

  // 프로세스
  const {processList, processStart, processStop} = require('./process');
  router.post('/process-list', verifyAuth, processList);    // 리스트
  router.post('/process-start', verifyAuth, verifySubmit, processStart); // 스타트
  router.post('/process-stop', verifyAuth, verifySubmit, processStop);   // 종료

  return router;
};
