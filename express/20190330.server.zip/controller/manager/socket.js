const {logger} = requireApp('./util');
const pm2 = requireApp('./controller/manager/libs/pm2');

module.exports = ctrl => {
  const wsDeploy = (req, res, next) => {
    const {addSocketListener} = ctrl;
    addSocketListener('deploy', (socket, data, clear) => {
      logger.debug('deploy', {data});
      socket.emit('deploy', {xxx:1});

      clear('deploy', x => {
        logger.debug('deploy clear');
      });
    });
    next();
  };

  const wsProcess = (req, res, next) => {
    const {addSocketListener} = ctrl;
    addSocketListener('pm-list', (socket, data, clear) => {
      let isWork = true;
      const getList = async x => {
        logger.debug('-getList-');
        socket.emit('pm-list', await pm2.list());
        isWork && setTimeout(getList, 1000);
      };
      getList();

      clear('pm-list', x => (isWork = false));
    });

    next();
  };

  return {wsProcess, wsDeploy}
};