const {logger} = requireApp('./util');
const pm2 = requireApp('./controller/manager/libs/pm2');

// 프로세스- 리스트
exports.processList = (req, res) => pm2.list().then(data => res.json(data));

// 프로세스- 시작
exports.processStart = (req, res) => {
  const {body:{pid}} = req;
  if(pid === undefined) return next({status:412});

  pm2.restart(pid).then(data => res.json(data));
};
// 프로세스- 종료
exports.processStop = (req, res) => {
  const {body:{pid}} = req;
  if(pid === undefined) return next({status:412});

  pm2.stop(pid).then(data => res.json(data));
};