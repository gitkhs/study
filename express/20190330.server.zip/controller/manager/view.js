const {prop, logger} = requireApp('./util');
const menus = requireApp('./views/manager/menus.json');
const property = {};

exports.set = (k, v) => { prop(property, {[k]:v}); }
// 홈
exports.home = (req, res) => res.redirect('/sign');
// 로그인- 화면
exports.sign = (req, res) => res.render('sign');
// 대쉬보드
exports.dashboard = (req, res) => {
  res.render('dashboard', {
    menus, title:'Dashboard', path:'/dashboard'
  });
};
// 디플로이
exports.deploy = (req, res) => {
  // const {ctrl:{addSocketListener}} = property;
  // addSocketListener('deploy', (socket, data, clear) => {
  //   logger.debug('deploy', {data});
  //   socket.emit('deploy', {xxx:1});

  //   clear('deploy', x => {
  //     logger.debug('deploy clear');
  //   });
  // });
  res.render('deploy', {
    menus,
    title: 'Deploy',
    path: '/deploy',
  });
};
// 프로세스
exports.process = (req, res) => {
  // const {ctrl:{addSocketListener}} = property;
  // addSocketListener('pm-list', process.pmList);
  res.render('process', {
    menus,
    title: 'Process',
    path: '/process',
  });
};