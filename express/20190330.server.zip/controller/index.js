const fs = require('fs');
const router = require('express').Router();
const {logger, prop, isFunction} = requireApp('./util');

const dirRoot = 'controller';
const socketListener = new Map;
const socketClear = new WeakMap;
const property = {};

const Controller = class {
  static GET(app, root, path=root) { return new Controller(app, root, path); }

  constructor(_app, _root, _path) {
    prop(this, {
      _app, _root, _path,
      _child: null,
    });

    this._child = fs.readdirSync(`${dirRoot}/${_path}`).reduce((dir, vl) => {
      fs.statSync(`${dirRoot}/${_path}/${vl}`).isDirectory() &&
        dir.push(Controller.GET(_app, _root, `${_path}/${vl}`));
      return dir;
    }, []);

    if(_root == _path) this._attach();
  }
  get router() { return router; }
  _attach() {
    this._load();
    this._child.forEach(ctrl => ctrl._attach());
  }
  _load() {
    const {_path, _root} = this;
    if(!fs.existsSync(`./${dirRoot}/${_path}/index.js`)) return;

    const url = _path.replace(_root, '') || '/';
    const sub = require(`./${_path}`);
    if(!isFunction(sub)) return;

    logger.info('load controller', {url, _path});
    router.use(`${url}`, sub(this));
  }

  addSocketListener(name, proc) { socketListener.set(name, proc); }
  clearSocket(socket) {
    const clear = socketClear.get(socket);
    clear && Object.entries(clear).forEach(([k, p]) => isFunction(p) && p());
    socketClear.delete(socket);
  }
  onSocket(name, socket, data) {
    socketClear.has(socket) || socketClear.set(socket, {});

    const channel = socketListener.get(name);
    channel && channel(socket, data, (k, p) => prop(socketClear.get(socket), {[k]:p}));
  }
};

module.exports = Controller;