const App = require('./app');
window.shcApp = init=> App(require('../libs/knockout-shc'), init);