// const ko = require('../libs/knockout-3.4.3');
// const valeObject = vo=> Object.defineProperties(vo, {
//   $data:{get() {return ko.unwrap(vo);}, set(vl) {vo(vl);}},
//   $length:{get() {return ko.unwrap(vo).length;}}
// });
// window.koApp = class {
//   constructor(version='1.0.0') {
//     Object.assign(this, {version});
//   }
//   observe(vl) {return valeObject(ko.observable(vl));}
//   observeArray(vl) {return valeObject(ko.observableArray(vl));}
//   event(proc) {
//     const handle = {};
//     proc && proc(handle);
//     return Object.entries(handle).reduce((handle, [ky, vl])=> Object.assign(handle, {
//       [ky](...arg) {
//         const evt=arg.pop(), vo=arg.pop()||{};
        
//         if(evt instanceof Event) {
//           const dataset = Object.assign({}, (evt.currentTarget||evt.target).dataset);
//           return vl(evt, vo.ctrl?dataset:vo, dataset);
//         }
//         return vl;
//     }}), {});
//   }

//   bindingElement(element, {vo, on, ctrl}) {
//     ko.cleanNode(element);
//     ko.applyBindings({vo, on, ctrl}, element);
//   }
//   bindingComponent(name, template, middle) {
//     let isWorking;
//     const createViewModel = (_, {element}) => {
//       if(isWorking) throw `embedded element is open: ${name}`;
//       const {$data:{ctrl:parent}} = ko.contextFor(element); // 모 컨트롤러 취득
//       const {vo, on, ctrl} = middle && middle(parent, _=> (isWorking = false));

//       isWorking = true;
//       ko.applyBindingsToNode(element, {ctrl});
//       return {vo, on, ctrl};
//     };
//     ko.components.register(name, {template, viewModel:{createViewModel}});
//   }
//   bindingDirective(name, init) {
//     ko.bindingHandlers[name] = {
//       init(el, vl, bind, vo, context) {
//         const {ctrl} = vo;
//         const {$parents:[parent]} = context;
//         init && init(parent ? parent.ctrl : ctrl, el, vl());
//       }
//     };
//   }
// };
// /*
// 디렉티브에서 observable 객체 변경시 처리
// vl.subscribe(function(vl) {
//   console.log('--change--', vl);
// });
// */
