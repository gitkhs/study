const error = (...vl) => { console.error(...vl); }
const assign = (...v) => Object.assign(...v);
const istype = (vl, tp) => (/^array$/.test(tp) ? Array.isArray(vl) : typeof vl == tp);
const array = (vl=[]) => Array.isArray(vl) ? vl : [vl];
const clone = vl => {
  if(istype(vl, 'array')) return [].concat(vl);
  return istype(vl, 'object') ? assign({}, vl) : vl;
};
// element util
const el = t => document.createElement(t);
// app util
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`).replace(/^-/, '');
const datetime = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]);

const $app = {};
const $controller = new Map;
const isController = ins=> (ins instanceof Controller);
const clearPrivate = vl=> assign(vl, {
  parent:null, openResolve:null, closeResolve:null,
  vo:null, on:null, css:null, attr:null, style:null,
  element:null, html:null, url:null,
});

// ---------- Controller ---------- //
const Controller = class {
  static CREATE(type, name, procedure, initialize) {
    const Class = class extends Controller {
      constructor() {
        super(type, name, procedure);
        initialize && initialize(Class.prototype);
      }
    };
    return Object.freeze(new Class);
  }
  constructor(_type, _name, procedure) {
    assign(this, {
      _name, _type,
      _property: {x:1},
      _private: { oninit:null, onload:null, onclose:null }
    });
    clearPrivate(this._private);

    this._create && this._create();
    procedure && procedure(this);
  }
  get debug() {
    const isChrome = navigator.userAgent.toLowerCase().indexOf('chrome') >= 0;
    const {_error, type, name} = this;
    const label = isChrome ? [`%c${type}:${name}`, 'font-weight:bold;color:#1ab'] : [`${type}:${name}`];
    return {
      break() { if($app.debug) debugger; },
      log(...vl) { $app.debug && console.log(...label, ...vl); },
      hierarchy(...vl) {
        $app.debug && console.log(...label, ...vl.map(vl=> JSON.stringify(vl,'','  ')));
      },
      error(...vl) {
        const text = `${type}:${name}\n${vl.join('\n')}`;
        console.error(...label, ...vl);
        _error && _error(new Date().getTime(), text, new Error().stack);
        return vl.join(',');
      },
    };
  }
  set oninit(oninit) { assign(this._private, {oninit}); }
  set onload(onload) { assign(this._private, {onload}); }
  set onclose(onclose) { assign(this._private, {onclose}); }
  get name() { return this._name; }
  get type() { return this._type; }
  get parent() { return this._private.parent; }
  get param() { return this._private.param; }
  get property() { return this._property; };
  get vo() {  return this._private.vo; }
  get on() { return this._private.on; }
  get element() { return this._private.element; }
  set element(element) { assign(this._private, {element}); }
  set url(url) { assign(this._private, {url}); }
  set html(html) { assign(this._private, {html}); }
  attr(vl) {
    const {_private:{attr}}=this;
    if(!vl) return attr();
    attr(assign(attr(), vl));
  }
  css(vl) {
    const {_private:{css}}=this;
    if(!vl) return css();
    css(assign(css(), vl));
  }
  style(vl) {
    const {_private:{style}}=this;
    if(!vl) return style();
    style(assign(style(), vl));
  }

  animation(target) {
    return new Promise(resolve => {
      if(!target) return resolve();

      let nonAni = true;
      const animationstart = _=> {
        nonAni = false;
        target.removeEventListener('animationstart', animationstart)
      };
      const animationend = _=> {
        target.removeEventListener('animationend', animationend), resolve();
      };
      target.addEventListener('animationstart', animationstart);
      target.addEventListener('animationend', animationend);

      setTimeout(_=> nonAni && resolve(), 100);
    });
  }
  observer(vl) {
    const vo=istype(vl, 'array') ? $app.ko.observableArray(vl) : $app.ko.observable(vl);
    return Object.defineProperties(vo, {
      $data: {get() { return $app.ko.unwrap(vo);}, set(vl) { vo(vl); }},
      $length: {get() { return $app.ko.unwrap(vo).length;}},
    });
  }
  event() {
    const handle={};
    handle.on = (name, fnc) => {
      if(name == 'on') return handle;
      if(!istype(name, 'string') || !istype(fnc, 'function'))
        return this.debug.error(`invalid event listener`);

      return assign(handle, {
        [name](...arg) {
          const ev = arg.pop(), vo = arg.pop() || {};
          return ev instanceof Event ? fnc(ev, vo.ctrl == this || vo) : fnc;
        }
      });
    };
    return handle;
  }


  get(name) {
    this.debug.log(`get Controller "${name}"`);
    return $controller.get(name);
  }
  _open() { this.debug.error(`open is overrided`); }
  open(name, param) {
    return new Promise((resolve, reject)=> {
      const child = $controller.get(name);
      if(!child) return reject(this.debug.error(`invalid controller "${name}"`));

      const {parent} = child;
      if(parent) return reject(this.debug.error(`is open "${child.name}"`));
  
      resolve(child.run(this, clone(param)));
    });
  }
  run(parent, param) {
    return new Promise(async (resolve, reject)=> {
      if(!isController(parent)) return reject(this.debug.error('invalid parent'));

      const vo={}, on={};
      const css=$app.ko.observable({});
      const attr=$app.ko.observable({});
      const style=$app.ko.observable({});
      assign(this._private, { parent, param, vo, on, css, attr, style });

      const {oninit, onload} = this._private;
      oninit && oninit(vo, on);
      this._open();

      const {element, html, url} = this._private;
      if(!element) return reject(this.debug.error('invalid element'));

      const tpl = html || url && await fetch(url).then(rs => rs.text());
      element.setAttribute('tabindex', '0');
      if(element && tpl) element.innerHTML = tpl;

      // ko binding
      $app.ko.cleanNode(element);
      $app.ko.applyBindingsToNode(element, { css, attr, style });
      $app.ko.applyBindings({ vo, on, ctrl:this }, element);

      await new Promise(r=> r(this._onload && this._onload()));
      assign(this._private, { openResolve:resolve });
      onload && onload();
    });
  }
  _close() { this.debug.error(`close is overrided`); }
  close(param) {
    new Promise(async (resolve, reject)=> {
      const {openResolve, closeResolve, onclose} = this._private;
      if(!openResolve) return reject(this.debug.error('not open'));
      if(closeResolve) return reject(this.debug.error('close is working'));
      assign(this._private, { closeResolve:resolve });

      await new Promise(r=> r(this._onclose && this._onclose()));

      const {attr, css, style} = this._private;
      attr(Object.entries(attr()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
      css(Object.entries(css()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
      style(Object.entries(style()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
  
      onclose && onclose();
      resolve(), openResolve(clone(param));
      this._close();
      clearPrivate(this._private);
    });
  }
};

window.App = class {
  constructor(create) {
    create && create(this, Controller.prototype);

    window.koPrefix = $app.prefix||'ko';
    $app.ko = require('../libs/knockout');
    Object.freeze(this);
  }
  get isWorking() { return $app.isWorking; }
  set debug(vl) { assign($app, { debug:array(vl).indexOf(location.hostname)>=0 }); }
  set prefix(prefix) { assign($app, {prefix}); }
  get prefix() { return `data-${$app.prefix||'ko'}`; }

  createController(tp, nm, prc, init) {
    if(!tp || !nm || !prc || !init)
      return error('invalid param: type, name, procedure, initialize');
    if($controller.has(nm)) return error(`"${nm}" duplicate controller`);
    $controller.set(nm, Controller.CREATE(tp, nm, prc, init));
  }
  createComponent(nm, prc, init) {
    this.createController('Component', nm, prc, co=> {
      init && init(co);
      co.isComponent = true;
      co.open = co.run = function() { this.debug.error(`open is can not support`); };
      co.close = function() { this.debug.error(`close is can not support`); };
      co.load = function() {
        return new Promise(async (resolve, reject)=> {
          const {name, _private:{template:tpl, oninit}} = this;
          if(tpl) return reject(this.debug.error('is working'));

          const vo={}, on={};
          assign(this._private, { vo, on });
          oninit && oninit(vo, on);

          const {url, html} = this._private;
          const template = html || url && await fetch(url).then(rs => rs.text());
          const createViewModel = (_, {element}) => {
            assign(this._private, { element });

            // const {$data:{ctrl:_parent}} = ko.contextFor(element); // 모 컨트롤러 취득 방법
            $app.ko.applyBindingsToNode(element, {ctrl:this});
            return {vo, on, ctrl:this};
          };
          // 화면 바인딩
          $app.ko.components.register(snake(name), {
            template,
            viewModel: { createViewModel }
          });
          assign(this._private, { template });
          this.debug.log('load');
          resolve();
        });
      };
    });
  }
  createDirective(name, init) {
    $app.ko.bindingHandlers[name] = {
      init(el, vl, bind, vo, context) {
        const {ctrl} = vo;
        const {$parents:[parent]} = context;
        init && init(parent ? parent.ctrl : ctrl, el, vl());
      },
      // update(el, vl, bind, vo, context) {
      //   const {ctrl} = vo;
      //   const {$parents:[parent]} = context;
      //   update && update(parent ? parent.ctrl : ctrl, el, vl());
      // }
    };
  }

  ready(prc) {
    return new Promise(rs=> document.addEventListener('DOMContentLoaded', _=> {
      $app.isWorking = true;
      rs(prc && prc());
    })).then(_=> Promise.all(([...$controller]).map(([_, ctrl])=> {
      // 콤포넌트 로드
      if(ctrl.isComponent) return ctrl.load();
    })));
  }
  loadScript(vl) {
    const js = new Set(vl);
    return Promise.all([...js].map(vl => new Promise(resolve => {
      if(!/\.js$/.test(vl)) return resolve({ load: false, name: vl });

      const lib = document.head.appendChild(el('script'));
      lib.src = `${vl}?v=${datetime('YMD')}`;
      lib.onload = _=> resolve({ load: true, name: vl });
      lib.onerror = _=> resolve({ load: false, name: vl });
    }))).then(ls=> {
      const err = ls.reduce((err, vl)=> ((vl.load || err.push(vl.name)), err), []);
      if(err.length) throw `load script failed ${err.join(', ')}`
    });
  }
};
