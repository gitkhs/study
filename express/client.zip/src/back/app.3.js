
const error = (...vl) => { console.error && console.error(...vl); }
const assign = (...v) => Object.assign(...v);
const istype = (vl, tp) => (/^array$/.test(tp) ? Array.isArray(vl) : typeof vl == tp);
const array = (vl=[]) => Array.isArray(vl) ? vl : [vl];
const clone = vl => {
  if(istype(vl, 'array')) return [].concat(vl);
  return istype(vl, 'object') ? assign({}, vl) : vl;
};

// element util
const el = t => document.createElement(t);
const qr = (s, d = document) => d.querySelector(s);
// app util
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`).replace(/^-/, '');
const datetime = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]);
const clsName = ({type, name}) => `${type}:${name}`;

const $app = {
  ko: null,
  container: null, resource:null,
  prefix: {}, extend: {},
  debug: false, isOpen: false,
  openTrigger:null, closeTrigger:null,
};
const $controller = new Map;
const $property = new WeakMap;
const initProp = ctrl=> assign($property.get(ctrl), {
  param:null, parent:null, openResolve:null,
  element:null, url:null, html:null,
  openTrigger:null, closeTrigger:null,
  vo:null, on:null, active:null, attr:null, css:null, style:null,
});

// ---------- App Controller ---------- //
const App = class {};
// ---------- Controller Controller ---------- //
const Controller = class extends App {
  constructor({name, type, proc, append}) {
    super();
    $property.set(this, {
      name, type, proc,
    });
    initProp(this);

    const extend = assign({}, $app.extend);
    append && append(extend);
    Object.entries(extend).forEach(([ky, vl])=> {
      if(ky in this) return;
      this[ky] = istype(vl, 'function') ? (...v)=> vl(this, ...v) : clone(vl);
    });
  }

  get name() { const {name}=$property.get(this); return name; }
  get type() { const {type}=$property.get(this); return type; }
  get param() { const {param}=$property.get(this); return param; }
  get isOpen() { const {parent}=$property.get(this); return !!parent; }
  get vo() { const {vo}=$property.get(this); return vo; }
  get on() { const {on}=$property.get(this); return on; }

  set url(url) { assign($property.get(this), {url}); }
  set html(html) { assign($property.get(this), {html}); }

  active(vl=true) {
    const {active}=$property.get(this);
    active(vl);
    return this;
  }
  attr(vl) {
    const {attr}=$property.get(this);
    istype(vl, 'object') &&
    attr(Object.entries(vl).reduce((tg, [ky,vl])=> assign(tg, {[snake(ky)]:vl}), attr()||{}));
    return this;
  }
  css(vl) {
    const {css}=$property.get(this);
    istype(vl, 'object') &&
    css(Object.entries(vl).reduce((tg, [ky,vl])=> assign(tg, {[snake(ky)]:vl}), css()||{}));
    return this;
  }
  style(vl) {
    const {style}=$property.get(this);
    istype(vl, 'object') &&
    style(Object.entries(vl).reduce((tg, [ky,vl])=> assign(tg, {[snake(ky)]:vl}), style()||{}));
    return this;
  }
  observer(vl) {
    const {ko}=$app, vo=istype(vl, 'array') ? ko.observableArray(vl) : ko.observable(vl);
    return Object.defineProperties(vo ,{
      $data: {get() { return ko.unwrap(vo);}, set(vl) { vo(vl); }},
      $length: {get() { return ko.unwrap(vo).length;}},
    });
  }
  event(handle = {}) {
    handle.on = (name, fnc) => {
      if(name == 'on') return handle;
      if(!istype(name, 'string') || !istype(fnc, 'function'))
        return error(`${clsName(this)}| invalid param`);

      return assign(handle, {
        [name](...arg) {
          const ev = arg.pop(), vo = arg.pop() || {};
          return ev instanceof Event ? fnc(ev, vo.ctrl == this || vo) : fnc;
        }
      });
    };
    return handle;
  }

  log(...vl) { $app.debug && console.log(`%c${clsName(this)}`, 'font-weight:bold;color:#1ab', ...vl); }
  get(name) { return $controller.get(name); }
  open(name, param) {
    const child = $controller.get(name);
    if(!child) return error(`can not open: invalid controller "${name}"`);

    const {parent} = $property.get(child);
    if(parent) return error(`${clsName(child)}| is open`);

    return child.run(this, clone(param));
  }

  _run() { error(`${clsName(this)}| open is overrided`); }
  run(parent, param) {
    const {ko} = $app;
    assign($property.get(this), {
      parent, param,
      vo:{}, on:{},
      active:ko.observable(true),
      css:ko.observable(), attr:ko.observable(), style:ko.observable(),
    });

    const {proc} = $property.get(this);
    proc && proc(this);

    return new Promise(async (resolve, reject)=> {
      assign($property.get(this), {openResolve:resolve});
      this._run();

      // get template
      const {element, template, html, url} = $property.get(this);
      const tpl = template || html || url && await fetch(url).then(rs => rs.text());
      element.setAttribute('tabindex', '0');
      element.setAttribute('data-bind', 'if:active');
      tpl && assign(element, { innerHTML:tpl });
      // if(this instanceof Popup) element.focus();

      // ko binding
      const {css, attr, style} = $property.get(this);
      const {active, vo, on} = $property.get(this);
      ko.cleanNode(element);
      ko.applyBindingsToNode(element, { css, attr, style });
      ko.applyBindings({ active, vo, on, ctrl:this }, element);
    });
  }
  _close() { error(`${clsName(this)}| close is overrided`); }
  close(param) {
    const {openResolve} = $property.get(this);
    openResolve(clone(param));

    this._close();
    initProp(this);
  }
};

// ---------- View Controller ---------- //
const View = class extends Controller {
  static GET(vl) { return Object.freeze(new View(vl)); }
  constructor(vl) {
    super(assign(vl, {type:'View'}));
  }
  _run() {
    const {name} =  $property.get(this);
    const {container, prefix:{view}} = $app;
    const selector = `[${view}=${snake(name)}]`;
    const makeView = parent=> {
      if(!parent) return error(`can not find container "${container}"`);
      const div = parent.appendChild(el('div'));
      div.setAttribute(view, snake(name));
      return div;
    };
    const element = qr(selector) || makeView(qr(container));
    assign($property.get(this), {element});
  }
  _close() {
    const {element, css, attr, style} = $property.get(this);
    assign($property.get(this), { template:element.innerHTML });

    element.innerHTML = '';
    style(Object.entries(style()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
    css(Object.entries(css()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
    attr(Object.entries(attr()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
  }
};

// ---------- Popup Controller ---------- //
const Popup = class extends Controller {
  static GET(vl) { return Object.freeze(new Popup(vl)); }
  constructor(vl) {
    super(assign(vl, {type:'Popup'}));
  }
  _run() {
    const {name} =  $property.get(this);
    const {resource, prefix:{popup}} = $app;
    const element = resource.appendChild(el('div'));
    element.setAttribute(popup, snake(name));
    assign($property.get(this), {element});
  }
  _close() {
    const {element} = $property.get(this);
    const {resource} = $app;
    resource.removeChild(element);
  }
};

// ---------- Component Controller ---------- //
const Component = class extends Controller {
  static GET(vl) { return Object.freeze(new Component(vl)); }
  constructor(vl) {
    super(assign(vl, {type:'Component'}));
  }
  open() { error(`${clsName(this)}| open is not use`); }
  close() { error(`${clsName(this)}| close is not use`); }
  load() {
    const {ko} = $app;
    assign($property.get(this), {
      vo:{}, on:{},
      active:ko.observable(true),
      css:ko.observable(), attr:ko.observable(), style:ko.observable(),
    });

    return new Promise(async resolve => {
      const {proc, element} = $property.get(this);
      if(element) return;
      proc(this);

      const {name, url, html} = $property.get(this);
      const template = html || url && await fetch(url).then(rs => rs.text());
      const createViewModel = (param, {element}) => {
        // 모 컨트롤러 취득 방법
        // const {$data:{ctrl:_parent}} = ko.contextFor(element);
        const {vo, on} = $property.get(this);
        ko.applyBindingsToNode(element, {ctrl:this});
        return {vo, on, ctrl:this};
      };

      // 화면 바인딩
      assign($property.get(this), {element:template});
      ko.components.register(snake(name), {
        template,
        viewModel: { createViewModel }
      });

      resolve();
    });
  }
};

module.exports = ({ko})=> {
  window.Controller = class extends App {
    constructor({container, prefix='app'}={}) {
      super();

      if(!container) return error('can not create "Contoller": invalid container');
      assign($app, {container, ko});

      const {prefix:_prefix} = $app;
      'view,popup,motion,resource'.split(',')
      .forEach(v=> assign(_prefix, {[v]:`data-${prefix}-${v}`}));

      $controller.set('main', View.GET({name:'main'}));      
      Object.freeze(this);
    }

    view(name, proc, append) {
      if($controller.has(name)) error(`"${name}" is duplicate controller`);
      else $controller.set(name, View.GET({name, proc, append}));
    }
    popup(name, proc, append) {
      if($controller.has(name)) error(`"${name}" is duplicate controller`);
      else $controller.set(name, Popup.GET({name, proc, append}));
    }
    component(name, proc, append) {
      if($controller.has(name)) error(`"${name}" is duplicate controller`);
      else $controller.set(name, Component.GET({name, proc, append}));
    }
    directive(name, procedure) {
      const {ko} = $app;
      ko.bindingHandlers[name] = {
        init(el, vl, bind, vo, context) {
          const {ctrl} = vo;
          const {$parents:[parent]} = context;
          procedure && procedure(parent ? parent.ctrl : ctrl, el, vl());
        }
        // update는 처리하지 않는 거로
        // update(el, vl, bind, {ctrl}, context) { update && update(el, vl(), ctrl); }
      };
    }

    ready() {
      return new Promise((resolve, reject)=> document.addEventListener('DOMContentLoaded', _=> {
        const {prefix:{resource:prefix}} = $app;
        const resource = document.body.appendChild(el('dev'));
        resource.setAttribute(prefix, '');
        assign($app, {resource});

        resolve();
      }));
    }
    loadScript(vl) {
      const js = new Set(vl);
      return Promise.all([...js].map(vl => new Promise((resolve, reject) => {
        if(!/\.js$/.test(vl)) return reject(`script file type(*.js) error: '${vl}'`);
            const lib = document.head.appendChild(el('script'));
        lib.src = `${vl}?v=${datetime('YMD')}`;
        lib.onload = _=> resolve({ load: true, name: vl });
        lib.onerror = _=> reject(`script load failed: ${vl}`);
      })));
    }
    open(vl) {
      if($app.isOpen) return error('is running');
      $app.isOpen = true;

      const target = new Set(vl);
      const {openTrigger, closeTrigger} = $app;
      return Promise.all([...$controller].map(([name, ctrl])=> {
        // 오픈, 종료 트리거 등록
        target.has(name) || assign($property.get(ctrl), {openTrigger, closeTrigger});
        return ctrl.load && ctrl.load();
      })).then(_=> {
        // load component
        target.forEach(name=> $controller.get('main').open(name));
      });
    }
    setTrigger(openTrigger, closeTrigger) {
      assign($app, {openTrigger, closeTrigger});
    }

    set debug(vl) { assign($app, { debug:array(vl).indexOf(location.hostname)>=0 }); }
    get extend() { return $app.extend; }
    get resource() { return $app.resource; }
  };
};