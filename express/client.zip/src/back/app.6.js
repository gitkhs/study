module.exports = (ko, init)=> {
  const define = Object.defineProperties;
  const entries = Object.entries;
  const assign = (...v) => Object.assign(...v);
  const istype = (vl, tp) => (/^array$/.test(tp) ? Array.isArray(vl) : typeof vl == tp);
  const array = (vl=[]) => Array.isArray(vl) ? vl : [vl];
  const clone = vl => {
    if(istype(vl, 'array')) return [].concat(vl);
    return istype(vl, 'object') ? assign({}, vl) : vl;
  };
  // element util
  const el = t => document.createElement(t);
  // app util
  const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`).replace(/^-/, '');
  const datetime = (
    f='Y.M.D hh:mi:ss:ms',
    d=new Date,
    r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
    t={
      Y: r(d.getFullYear(),4),
      M: r(d.getMonth()+1,2),
      D: r(d.getDate(),2),
      hh: r(d.getHours(),2),
      mi: r(d.getMinutes(),2),
      ss: r(d.getSeconds(),2),
      ms: r(d.getMilliseconds(),3),
    }
  ) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]);

  const $app = {};
  const $controller = new Map;
  // const property = (name, )=> {
  // };

  const getProp = name=> $controller.get(name).prop;
  const clearProp = name=> assign(getProp(name), {
    parent:null, data:null, openResolve:null, closeResolve:null,
    vo:null, on:null, css:null, attr:null, style:null,
    element:null, html:null, url:null,
  });
  
  // ---------- Controller ---------- //
  const Controller = class {
    static CREATE(type, create) {
      return (name, open, extend)=> {
        if($controller.has(name)) return console.error(`duplicate "${name}"`);
        $controller.set(name, {
          prop:{type, name, open},
          ctrl:Object.freeze(new class extends Controller {
            constructor() {
              super(name, type);
              create && create(this);
              extend && extend(this);
            }
          }),
        });
      };
    }

    constructor(_name, _type) {
      assign(this, {_name, _type});
      this._create && this._create();
    }
    get name() { return this._name; }
    get type() { return this._type; }
    get parent() { return getProp(this.name).parent; }
    get property() { return getProp(this.name).data; };
    get vo() {  return getProp(this.name).vo; }
    get on() { return getProp(this.name).on; }
    get isOpen() { return !!getProp(this.name).parent; }
    get el() {
      const prop=getProp(this.name);
      const {element}=prop;
      const el = {
        get target() {return element;},
        set target(element) {assign(prop, {element});}
      };
      el.html = html=> (assign(prop, {html}), el);
      el.url = url=> (assign(prop, {url}), el);
      el.css = (vl, {css}=prop)=> (vl && css(assign(css(), vl)), el);
      el.attr = (vl, {attr}=prop)=> (vl && attr(assign(attr(), vl)), el);
      el.style = (vl, {style}=prop)=> (vl && style(assign(style(), vl)), el);
      return el;
    }
    get debug() {
      const isChrome = navigator.userAgent.toLowerCase().indexOf('chrome') >= 0;
      const {type, name, _error} = this;
      const label = isChrome ? [`%c${type}:${name}`, 'font-weight:bold;color:#1ab'] : [`${type}:${name}`];
      return {
        log(...vl) { $app.debug && console.log(...label, ...vl); },
        info({hierarchy, text, color='#333'}={}, ...vl) {
          $app.debug && text && isChrome ? console.log(
            `%c${type}:${name} %c${text}\n`,
            'font-weight:bold;color:#1ab',
            `color:#${color.replace(/^#/, '')}`,
            ...vl.map(vl=> (hierarchy ? JSON.stringify(vl,'','  ') : vl))
          ) : console.log(...label, ...vl.map(vl=> (hierarchy ? JSON.stringify(vl,'','  ') : vl)));
        },
        break() { if($app.debug) debugger; },
        hierarchy(...vl) {
          $app.debug && console.log(...label, ...vl.map(vl=> JSON.stringify(vl,'','  ')));
        },
        error(vl) {
          if(_error) return _error(new Date(), `${type}:${name} ${vl}`, new Error().stack), vl;
          return console.error(`${type}:${name} ${vl}`), vl;
        },
      };
    }
    onload(onload) { assign(getProp(this.name), {onload}); return this; }
    onclose(onclose) { assign(getProp(this.name), {onclose}); return this; }
    run(parent, param) {
      return new Promise(async (resolve, reject)=> {
        if(!parent) return resolve();
  
        const vo={}, on={}, data={};
        const css=ko.observable({});
        const attr=ko.observable({});
        const style=ko.observable({});
        const prop=getProp(this.name);
        assign(prop, { parent, data, vo, on, css, attr, style, openResolve:resolve });
  
        const {open}=prop;
        open && open(this, param);
        this._open();
  
        const {onload, element, html, url} = prop;
        if(!element) return reject(this.debug.error('invalid element'));
  
        const tpl = html || url && await fetch(url).then(rs => rs.text());
        element.setAttribute('tabindex', '0');
        if(tpl) element.innerHTML = tpl;
  
        // ko binding
        ko.cleanNode(element);
        ko.applyBindingsToNode(element, { css, attr, style });
        ko.applyBindings({ vo, on, ctrl:this }, element);
  
        await new Promise(r=> r(this._onload && this._onload(this)));
        onload && onload();
      });
    }
    open(name, param) {
      return new Promise((resolve, reject)=> {
        const {ctrl:child} = $controller.get(name);
        if(!child) return reject(this.debug.error(`invalid controller "${name}"`));
  
        const {parent} = child;
        if(parent) return reject(this.debug.error(`is open "${child.name}"`));
    
        resolve(child.run(this, clone(param)));
      });
    }
    _open() { this.debug.error(`_open is overrided`); }
    close(param) {
      new Promise(async (resolve, reject)=> {
        const prop=getProp(this.name);
        const {openResolve, closeResolve, onclose} = prop;
        if(!openResolve) return reject(this.debug.error('not open'));
        if(closeResolve) return reject(this.debug.error('close is working'));
        assign(prop, { closeResolve:resolve });
  
        await new Promise(r=> r(this._onclose && this._onclose(this)));
  
        const {attr, css, style} = prop;
        attr(entries(attr()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
        css(entries(css()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
        style(entries(style()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
    
        onclose && onclose();
        resolve(), openResolve(clone(param));
        this._close();
  
        clearProp(this.name);
      });
    }
    _close() { this.debug.error(`_close is overrided`); }
    get(name) {
      return $controller.get(name).ctrl;
      // const {ctrl, prop:{openResolve}} = $controller.get(name);
      // return openResolve && ctrl;
    }
  };
  // app instance
  new class {
    constructor() {
      assign(this, {
        version: '1.0.5'
      });
      init && init(this, Controller);
    }
    set debug(vl) { assign($app, { debug:array(vl).indexOf(location.hostname)>=0 }); }
    get component() {
      return Controller.CREATE('Component', ctrl=> {
        ctrl.open = function() { ctrl.debug.error(`open is can not support`); };
        ctrl.close = function() { ctrl.debug.error(`close is can not support`); };
        ctrl.run = _=> new Promise(async (resolve, reject)=> {
          const {name} = ctrl;
          const prop = getProp(name);
          if(prop.template) return reject(ctrl.debug.error('is working'));

          const vo={}, on={};
          assign(prop, { vo, on });

          const {open} = prop;
          open && open(ctrl);

          const {url, html} = prop;
          const template = html || url && await fetch(url).then(rs => rs.text());
          const createViewModel = (_, {element}) => {
            assign(prop, { element });
            // const {$data:{ctrl:_parent}} = ko.contextFor(element); // 모 컨트롤러 취득 방법
            ko.applyBindingsToNode(element, {ctrl});
            return {vo, on, ctrl};
          };
  
          // 화면 바인딩
          ko.components.register(snake(name), {
            template,
            viewModel: { createViewModel }
          });
          assign(prop, { template });
          resolve();
        });  
      });
    }

    ready(prc) {
      return new Promise(rs=> document.addEventListener('DOMContentLoaded', _=> {
        $app.isWorking = true;
        rs(prc && prc());
        // 콤포넌트 로드
      })).then(_=> Promise.all(([...$controller]).map(([_, {ctrl}])=> ctrl.run())));
    }
    loadScript(vl) {
      const js = new Set(vl);
      return Promise.all([...js].map(vl => new Promise(resolve => {
        if(!/\.js$/.test(vl)) return resolve({ load: false, name: vl });

        const lib = document.head.appendChild(el('script'));
        lib.src = `${vl}?v=${datetime('YMD')}`;
        lib.onload = _=> resolve({ load: true, name: vl });
        lib.onerror = _=> resolve({ load: false, name: vl });
      }))).then(ls=> {
        const err = ls.reduce((err, vl)=> ((vl.load || err.push(vl.name)), err), []);
        if(err.length) throw `load script failed ${err.join(', ')}`;
      });
    }
    animation(target) {
      return new Promise(resolve => {
        if(!target) return resolve();
  
        let nonAni = true;
        const animationstart = _=> {
          nonAni = false;
          target.removeEventListener('animationstart', animationstart)
        };
        const animationend = _=> {
          target.removeEventListener('animationend', animationend), resolve();
        };
        target.addEventListener('animationstart', animationstart);
        target.addEventListener('animationend', animationend);
  
        setTimeout(_=> nonAni && resolve(), 100);
      });
    }
    directive(name, init, update) {
      ko.bindingHandlers[name] = {
        init(el, vl, bind, vo, context) {
          const {ctrl} = vo;
          const {$parents:[parent]} = context;
          init && init(parent ? parent.ctrl : ctrl, el, vl());
        },
        // update(el, vl, bind, vo, context) {
        //   const {ctrl} = vo;
        //   const {$parents:[parent]} = context;
        //   update && update(parent ? parent.ctrl : ctrl, el, vl());
        // }
      };
    }
  
    error(vl) {this._error ? this._error(vl) : console.error(vl);}
    _value(vl) {
      const vo=istype(vl, 'array') ? ko.observableArray(vl) : ko.observable(vl);
      return define(vo, {
        $data: {get() { return ko.unwrap(vo);}, set(vl) { vo(vl); }},
        $length: {get() { return ko.unwrap(vo).length;}},
      });
    }
    _event(handle={}) {
      handle.on = (name, fnc) => {
        if(name == 'on') return handle;
        if(!istype(name, 'string') || !istype(fnc, 'function'))
          return this.error(`invalid event listener`);
  
        return assign(handle, {
          [name](...arg) {
            const ev=arg.pop(), vo=arg.pop()||{};
            return ev instanceof Event ? fnc(ev, vo.ctrl==this || vo) : fnc;
          }
        });
      };
      return handle;
    }

  };
};
