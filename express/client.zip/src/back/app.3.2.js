const error = (...vl) => { console.error(...vl); }
const assign = (...v) => Object.assign(...v);
const istype = (vl, tp) => (/^array$/.test(tp) ? Array.isArray(vl) : typeof vl == tp);
const array = (vl=[]) => Array.isArray(vl) ? vl : [vl];
const clone = vl => {
  if(istype(vl, 'array')) return [].concat(vl);
  return istype(vl, 'object') ? assign({}, vl) : vl;
};
// element util
const el = t => document.createElement(t);
const qr = (s, d = document) => d.querySelector(s);
// app util
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`).replace(/^-/, '');
const datetime = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]);
const clsName = ({type, name}) => `${type}:${name}`;

const $app = {};
const $controller = new Map;
const $property = new WeakMap;
// ---------- Controller ---------- //
const Controller = class {
  static make(Class, name, procedure) { return Object.freeze(new Class({name, procedure})); }
  constructor({name, type, procedure}) {
    const {ko} = $app;

    this._create && this._create();
    $property.set(this, {
      name, type, procedure,
      vo:{}, on:{},
      active:ko.observable(true), style:ko.observable({}),
      css:ko.observable({}), attr:ko.observable({}),
    });

    assign(this, {
      _xxx:name
    });

    procedure(this);
  }
  get xxx() { return this._xxx; }
  // $property
  get type() { return $property.get(this).type; }
  get name() { return $property.get(this).name; }
  get parent() { return $property.get(this).parent; }
  set element(element) { assign($property.get(this), {element}); }
  get element() { return $property.get(this).element; }
  set oninit(oninit) { assign($property.get(this), {oninit}); }
  get oninit() { return $property.get(this).oninit; }
  set onload(onload) { assign($property.get(this), {onload}); }
  get onload() { return $property.get(this).onload; }
  set onclose(onclose) { assign($property.get(this), {onclose}); }
  get onclose() { return $property.get(this).onclose; }

  get vo() {  return $property.get(this).vo; }
  get on() { return $property.get(this).on; }
  set url(url) { assign($property.get(this), {url}); }
  set html(html) { assign($property.get(this), {html}); }
  set css(vl) { const {css}=$property.get(this); css(assign(css(), vl)); }
  get css() { const {css}=$property.get(this); return css(); }
  set style(vl) { const {style}=$property.get(this); style(assign(style(), vl)); }
  get style() { const {style}=$property.get(this); return style(); }
  set attr(vl) { const {attr}=$property.get(this); attr(assign(attr(), vl)); }
  get attr() { const {attr}=$property.get(this); return attr(); }

  log(...vl) { $app.debug && console.log(`%c${clsName(this)}`, 'font-weight:bold;color:#1ab', ...vl); }
  property(ky, func) {
    const {get, set} = func ? func(this) : {};
    return Object.defineProperties(this, {[ky]:{get,set}}), this;
  }
  animation(target) {
    return new Promise(resolve => {
      if(!target) return resolve();

      const animationstart = _=> target.removeEventListener('animationstart', animationstart);
      const animationend = _=> {
        target.removeEventListener('animationend', animationend), resolve();
      };
      target.addEventListener('animationstart', animationstart);
      target.addEventListener('animationend', animationend);
    });
  }

  observer(vl) {
    const {ko} = $app;
    const vo=istype(vl, 'array') ? ko.observableArray(vl) : ko.observable(vl);
    return Object.defineProperties(vo ,{
      $data: {get() { return ko.unwrap(vo);}, set(vl) { vo(vl); }},
      $length: {get() { return ko.unwrap(vo).length;}},
    });
  }
  event() {
    const handle={};
    handle.on = (name, fnc) => {
      if(name == 'on') return handle;
      if(!istype(name, 'string') || !istype(fnc, 'function'))
        return error(`${clsName(this)}| invalid param`);

      return assign(handle, {
        [name](...arg) {
          const ev = arg.pop(), vo = arg.pop() || {};
          return ev instanceof Event ? fnc(ev, vo.ctrl == this || vo) : fnc;
        }
      });
    };
    return handle;
  }

  load() {
    return new Promise(async resolve=> {
      setTimeout(_=> {
        console.log('load controll', this.xxx);
        resolve();
      }, 1000);
    });
  }
  open(name, param) {
    return new Promise((resolve, reject)=> {
      const child = $controller.get(name);
      if(!child) return reject(`${clsName(this)}| invalid controller "${name}"`);
  
      const {parent} = $property.get(child);
      if(parent) return reject(`${clsName(child)}| is open`);
  
      resolve(child.run(this, clone(param)));
    });
  }
  _open() { error(`${clsName(this)}| open is overrided: hook "_open"`); }
  run(parent, param) {
    return new Promise(async (openResolve, reject)=> {
      if(parent instanceof Controller == false)
        return reject(`${clsName(this)}| invalid parent`);
  
      assign($property.get(this), { parent, vo:{} });
      this._open();
      this._oninit && this._oninit();

      const {element, template, html, url} = $property.get(this);
      if(!element) return reject(`${clsName(this)}| invalid element`);

      const tpl = html || url && await fetch(url).then(rs => rs.text()) || template;
      element.setAttribute('tabindex', '0');
      element.setAttribute('data-bind', 'if:active');
      if(element) element.innerHTML = tpl;

      // ko binding
      const {ko} = $app;
      const {css, attr, style} = $property.get(this);
      const {active, vo, on} = $property.get(this);
      ko.cleanNode(element);
      ko.applyBindingsToNode(element, { css, attr, style });
      ko.applyBindings({ active, vo, on, ctrl:this }, element);

      await new Promise(r=> r(this._onload && this._onload()));
      assign($property.get(this), {openResolve});
    });
  }
  _close() { error(`${clsName(this)}| close is overrided: hook "_close"`); }
  close(param) {
    const {openResolve, closeResolve} = $property.get(this);
    if(!openResolve || closeResolve) return;

    new Promise(async (closeResolve)=> {
      assign($property.get(this), {closeResolve});
      await new Promise(r=> r(this._onclose && this._onclose()));

      this.css = Object.entries(this.css).reduce((css, [ky])=> assign(css, {[ky]:false}), {});
      this.style = Object.entries(this.style).reduce((style, [ky])=> assign(style, {[ky]:false}), {});
      this.attr = Object.entries(this.attr).reduce((attr, [ky])=> assign(attr, {[ky]:false}), {});
      const {css,style,attr} = $property.get(this);
      css({}), style({}), attr({});

      closeResolve(), openResolve(clone(param));
      this._close();

      assign($property.get(this), {
        closeResolve:null, openResolve:null,
        parent:null, element:null,
      });
    });
  }
};
// ---------- View Controller ---------- //
const View = class extends Controller {
  constructor(vl) { super(assign(vl, {type:'View'})); }
};
// ---------- Popup Controller ---------- //
const Popup = class extends Controller {
  constructor(vl) { super(assign(vl, {type:'Popup'})); }
};
// ---------- Component Controller ---------- //
const Component = class extends Controller {
  constructor(vl) {
    super(assign(vl, {type:'Component'}));
  }
  open() { error(`${clsName(this)}| can not use open`); }
  close() { error(`${clsName(this)}| can not use close`); }
  load() {
    return new Promise(async resolve=> {
      setTimeout(_=> {
        console.log('load Component', this.xxx);
        resolve();
      }, 1000);
    });
    // const {ko} = $app;
    // console.log('load xxx', this.name);
    // // $property.set(this, {
    // //   name, type:, procedure,
    // //   vo:{}, on:{},
    // //   active:ko.observable(true), style:ko.observable({}),
    // //   css:ko.observable({}), attr:ko.observable({}),
    // // });

    // return new Promise(async resolve=> {
    //   const {element} = $property.get(this);
    //   if(element) return;

    //   // procedure(this);
    //   const {name, url, html} = $property.get(this);
    //   const template = html || url && await fetch(url).then(rs => rs.text());
    //   const createViewModel = (param, {element}) => {
    //     // 모 컨트롤러 취득 방법
    //     // const {$data:{ctrl:_parent}} = ko.contextFor(element);
    //     const {vo, on} = $property.get(this);
    //     ko.applyBindingsToNode(element, {ctrl:this});
    //     assign($property.get(this), {element});

    //     return {vo, on, ctrl:this};
    //   };

    //   // 화면 바인딩
    //   ko.components.register(snake(name), {
    //     template,
    //     viewModel: { createViewModel }
    //   });

    //   resolve();
    // });
  }
};

window.App = class {
  constructor(extend) {
    extend && extend(this);

    window.prefix = $app.prefix||'ko';
    $app.ko = require('../libs/knockout');
    Object.freeze(this);
  }
  set debug(vl) { assign($app, { debug:array(vl).indexOf(location.hostname)>=0 }); }
  set prefix(prefix) { assign($app, {prefix}); }
  get prefix() { return `data-${$app.prefix||'ko'}`; }
  get Controller() { return Controller.prototype; }
  get View() { return View.prototype; }
  get Popup() { return Popup.prototype; }
  get Component() { return Component.prototype; }
  set resource(resource) { assign($app, {resource}); }
  get resource() { return $app.resource; }
  property(ky, func) {
    const {get, set} = func ? func(this) : {};
    return Object.defineProperties(this, {[ky]:{get,set}}), this;
  }
  create({constructor:{name:typeName}}, name, procedure) {
    if(!name) return error(`invalid name`);
    if(!procedure) return error(`"${name}" is invalid procedure`);
    if($controller.has(name)) return error(`"${name}" is duplicate controller`);

    const {prototype:{constructor:{name:viewName}}}=View;
    const {prototype:{constructor:{name:popupName}}}=Popup;
    const {prototype:{constructor:{name:compName}}}=Component;
    const Class = { [viewName]: View, [popupName]: Popup, [compName]: Component };
    const ctrl = Controller.make(Class[typeName], name, procedure);
    return $controller.set(name, ctrl), ctrl;
  }
  ready(proc) {
    return new Promise(rs=> document.addEventListener('DOMContentLoaded', _=> rs(proc && proc())));
  }
  loadScript(vl) {
    const js = new Set(vl);
    return Promise.all([...js].map(vl => new Promise((resolve, reject) => {
      if(!/\.js$/.test(vl)) return reject(`script file type(*.js) error: '${vl}'`);
          const lib = document.head.appendChild(el('script'));
      lib.src = `${vl}?v=${datetime('YMD')}`;
      lib.onload = _=> resolve({ load: true, name: vl });
      lib.onerror = _=> reject(`script load failed: ${vl}`);
    })));
  }
  bootstrap(openName) {
    if(!$controller.has(openName)) return error(`can not found controller "${openName}"`);
    Promise.all(([...$controller]).map(([name, ctrl])=> {
      return ctrl.load();
    }))
    .then(_=> {
      console.log('load after');
      // const ctrl = $controller.get(openName);
      // const {procedure} = $property.get(ctrl);
      // procedure(ctrl);
    });
  }
};