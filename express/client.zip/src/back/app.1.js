const ko = require('../libs/knockout-3.4.2');

// object util
const istype = vl => {
  if(vl.length < 2) return error('istype check param: array');

  while(vl.length) {
    const tg = vl.shift(), tp = vl.shift();
    if(Array.isArray(tg) && tp == 'array') continue;
    if(typeof tg != tp) return false;
  }
  return true;
};
const prop = (...v) => Object.assign(...v);
const arr = vl => Array.isArray(vl) ? vl : (vl ? [vl] : []);
const clone = vl => {
  if(istype([vl, 'array'])) return [].concat(vl);
  else if(istype([vl, 'object'])) return prop({}, vl);
  else return vl;
};
const error = (...vl) => console.error && console.error(...vl);

// element util
const el = t => document.createElement(t);
const qr = (s, d = document) => d.querySelector(s);
const script = vl => {
  return Promise.all(arr(vl).map(vl => new Promise((resolve, reject) => {
    if(!/\.js$/.test(vl)) return error(`file type(*.js) error: '${vl}'`);

    const lib = document.head.appendChild(el('script'));
    lib.src = `${vl}?v=${datetime('YMD')}`;
    lib.onload = x => resolve({ load: true, name: vl });
    lib.onerror = x => resolve({ load: false, name: vl });
  })));
};
const animation = (selector, befor) => {
  const target = typeof selector == 'string' ? qr(selector) : selector;
  befor && befor(target);

  return new Promise(resolve => {
    let nonAni=true;
    const animationstart = x => {
      nonAni = false;
      target.removeEventListener('animationstart', animationstart);
    };
    const animationend = x => {
      resolve({target, status:'animationend'});
      target.removeEventListener('animationend', animationend);
    };

    target.addEventListener('animationstart', animationstart);
    target.addEventListener('animationend', animationend);
    setTimeout(x => nonAni && resolve({target}), 100);
  });
};

// app util
const snakeCase = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`).replace(/^-/, '');
const datetime = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]);
const clsName = ({_type, _name}) => `${_type}:${_name}`;

let $resource, $trace;
const $debug = new Set;
const $launcher = new Set;
const $require = new Set;
const $controller = new Map;
const $component = [];

const DIF_PREFIX = 'data-app';
const DIF_VIEW = `${DIF_PREFIX}-view`;
const DIF_POPUP = `${DIF_PREFIX}-popup`;
const DIF_MOTION = `${DIF_PREFIX}-motion`;
const DIF_RESOURCE = `${DIF_PREFIX}-resource`;

// ---------- class Trace ---------- //
const Trace = class {
  static MAKE(name) { return new Trace(name); }
  constructor(name) {
    prop(this, {name, max:10});
  }

  log(...vl) {
    if(!vl.length || !$debug.has(location.hostname)) return;
    const opt = vl.pop();
    const {option, bold, color='#2a4'} = opt || {};
    const title = option ? [`%c${option}\n`,`color:${color};${bold&&'font-weight:bold;'}`] : [];
    console.log(...title, ...vl, option?'':opt);
  }
  error(...vl) {
    if(!localStorage) return;
    const errors = localStorage.__app_errors__ ? JSON.parse(localStorage.__app_errors__) : [];
    const {max} = this;

    if(!vl.length) return localStorage.__app_errors__;

    errors.unshift({
      time: new Date().getTime(),
      stack: new Error().stack,
      log: JSON.stringify(vl),
    }) > max && (errors.length = max);
    localStorage.__app_errors__ = JSON.stringify(errors);
    console.error(...vl);
  }
  stack(vl) {
    const errors = vl ? JSON.parse(vl) : [];
    errors.forEach(vl => {
      const {time, log, stack} = vl;
      this.log(...JSON.parse(log), '\n', stack, {
        option: `error stack: ` + datetime('Y.M.D hh:mi:ss:ms', new Date(time))
      })
    });
  }
  clear() { localStorage.__app_errors__ = ''; }
};
// ---------- class Directive ---------- //
const Directive = class {
  static MAKE(vl) { return new Directive(vl); }
  constructor(vl) {
    const {_name, _procedure} = vl;
    ko.bindingHandlers[_name] = {
      init(el, vl, bind, vo, context) {
        const {ctrl} = vo;
        const {$parents:[parent]} = context;
        _procedure && _procedure(parent ? parent.ctrl : ctrl, el, vl());
      }
      // update는 처리하지 않는 거로
      // update(el, vl, bind, {ctrl}, context) { update && update(el, vl(), ctrl); }
		};
  }
};

// ---------- class Controller ---------- //
const Controller = class {
  static MAKE({CLASS, _name, _procedure}) {
    if(!_name) return error(`controller error| invalid name`);
    if(!istype([_name, 'string', _procedure, 'function']))
      return error(`controller error| check parameter: string, function`);

    return Object.freeze(CLASS.MAKE({_name, _procedure}));
  }

  constructor(vl) {
    const _property = {
      html:null, url:null,
      vo:{}, on:{}, active:ko.observable({}),
      css:ko.observable({}), attr:ko.observable({}),style:ko.observable({}),
      openResolve:null, element:null, parent:null, childs:new Set,
      openTrigger:null, closeTrigger:null,
    };
    const _method = {
      onload:null,
    };

    prop(this, vl, {
      _property,
      _method,
      _option: {}
    });
  }

  observer(vl) {
    const vo = istype([vl, 'array']) ? ko.observableArray(vl) : ko.observable(vl);
    return Object.defineProperties(vo ,{
      $data: {get() { return ko.unwrap(vo);}, set(vl) { vo(vl); }},
      $length: {get() { return ko.unwrap(vo).length;}},
    });
  }
  handler(handle = {}) {
    handle.event = (name, fnc) => {
      if(name == 'event') return handle;
      if(!istype([name, 'string', fnc, 'function'])) return error(`${clsName(this)}| invalid param`);

      return prop(handle, {
        [name]: (...arg) => {
          const ev = arg.pop(), vo = arg.pop() || {};
          return ev instanceof Event ? fnc(ev, vo.ctrl == this || vo) : fnc;
        }
      });
    };
    return handle;
  }

  // property
  get type() { return this._type; }
  get name() { return this._name; }
  set onload(onload) { istype([onload, 'function']) && prop(this._method, {onload}); }
  set url(url) { istype([url, 'string']) && prop(this._property, {url}); }
  set html(html) { istype([html, 'string']) && prop(this._property, {html}); }
  get vo() { return this._property.vo; }
  get on() { return this._property.on; }
  get el() { return this._property.element; }
  get parent() { return this._property.parent; }
  set active(vl) { this._property.active(!!vl); }
  set attr(vl) { this._property.attr(vl); }
  set css(vl) { this._property.css(vl); }
  set style(vl) { this._property.style(vl); }
  get ex() { return this._option; }

  // method
  log(...vl) {
    const {type, name} = this;
    $trace.log(...vl, {option:`${type}:${name}`, color:'#61f'});
  }
  setTrigger(ctrl, openTrigger, closeTrigger) {
    prop(this._property, {openTrigger, closeTrigger});
  }
  alert(...vl) {
    const {_option:{alert}} = this;
    return alert && alert(...vl);
  }
  confirm(...vl) {
    const {_option:{confirm}} = this;
    return confirm && confirm(...vl);
  }

  _addChild(ctrl) {
    const {_property:{childs}} = this;
    childs.add(ctrl);
  }
  _motion(type) {
    const {_property:{element}} = this;
    const motion = qr(`[${DIF_MOTION}]`, element);
    motion && motion.setAttribute(DIF_MOTION, type);
    return animation(element);
  }

  // open, close
  _open() { error(`${clsName(this)}| open is overrided`); }
  open(parent, param) {
    const {_name, _type, _property, _method, _procedure} = this;
    const binding = element => {
      const {css, attr, style, vo, on, active} = _property;

      active(true);
      ko.cleanNode(element);
      ko.applyBindingsToNode(element, { css, attr, style });
      ko.applyBindings({ active, vo, on, ctrl:this }, element);
    };

    // open 처리
    return new Promise(openResolve => {
      const {element} = _property;

      if(parent instanceof Controller == false) return error(`${clsName(this)}| invalid controller`); 
      if(element) return error(`${clsName(this)}| is opened`);
      if(!this._open()) return error(`${clsName(this)}| "${snakeCase(_name)}" not found`);
  
      parent._addChild(this);
      _procedure(this, clone(param));
      prop(_property, {openResolve, parent});

      const motion = new Promise(async resolve => {
        const {element, html, url, openTrigger} = _property;

        const tpl = html || url && await fetch(url).then(rs => rs.text());
        element.setAttribute('tabindex', '0');
        element.setAttribute('data-bind', 'if:active');
        tpl && prop(element, {innerHTML:tpl});

        binding(element);
        if(this instanceof Popup) element.focus();

        openTrigger && openTrigger(this);
        await this._motion('open');

        resolve();
      });

      setTimeout(_=>{
        const {onload} = _method;
        onload && onload(motion);
      }, 100);
    });
  }
  _close() { error(`${clsName(this)}| close is overrided`); }
  close(result) {
    const {_property} = this;
    const {element, openResolve, closeTrigger} = _property;
    if(!element || !openResolve) return;

    return new Promise(async resolve => {
      const {childs} = _property;
      // 열려있는 차일드 종료
      childs.forEach(v => v.close()), childs.clear();

      closeTrigger && closeTrigger(this);
      // 오픈프로미스 리졸브
      openResolve(clone(result), 123);
      await this._motion('close');

      this._close();
      prop(_property, {
        vo:{}, on:{}, active:ko.observable({}),
        css:ko.observable({}), attr:ko.observable({}),style:ko.observable({}),
        openResolve:null, element:null,
      });

      resolve();
    });
  }
};

// ---------- class View ---------- //
const View = class extends Controller {
  static MAKE(vl) { return new View(vl); }
  constructor(vl) {
    super(vl), prop(this, { _type:'View' });
  }
  _open() {
    const {_name, _property} = this;
    const element = qr(`[${DIF_VIEW}=${snakeCase(_name)}]`);
    return element && prop(_property, {element});
  }
  _close() {
    const {_property:{element}} = this;
    if(element) element.innerHTML = '';
  }
};

// ---------- class Popup ---------- //
const Popup = class extends Controller {
  static MAKE(vl) { return new Popup(vl); }
  constructor(vl) {
    super(vl), prop(this, { _type:'Popup' });
  }
  _open() {
    const {_name, _property} = this;
    const element = $resource.appendChild(el('div')); 
    element.setAttribute(DIF_POPUP, snakeCase(_name));
    return element && prop(_property, {element});
  }
  _close() {
    const {_property:{element}} = this;
    if(element) $resource.removeChild(element);
  }
};

// ---------- class Component ---------- //
const Component = class extends Controller {
  static MAKE(vl) { return new Component(vl); }
  constructor(vl) {
    super(vl), prop(this, { _type:'Component' });
  }
  close() {}
  open() {
    const {_name, _procedure, _property, _method} = this;

    return new Promise(async resolve => {
      const {element} = _property;
      if(element) return error(`${clsName(this)}| is opened`);

      _procedure(this);

      const {url, html} = _property;
      const template = html || url && await fetch(url).then(rs => rs.text());
      const createViewModel = (prm, {element}) => {
        // 모 컨트롤러 취득 (사용할 일이 없네...)
        // const {$data:{ctrl:_parent}} = ko.contextFor(element);
        const {vo, on} = _property;
        const {onload} = _method;

        ko.applyBindingsToNode(element, {ctrl:this});
        onload && onload();

        return {vo, on, ctrl:this};
      };

      // 화면 바인딩
      prop(_property, {element:template});
      ko.components.register(snakeCase(_name), {
        template,
        viewModel: { createViewModel }
      });

      resolve();
    });
  }
};

// ---------- class MakeApp ---------- //
new class MakeApp extends Controller {
  constructor(vl) {
    super();

    const _name = 'MakeApp';
    prop(this, vl, {
      _name, _onload:[],
    });

    prop(this._property, {
      isWorking: false, root: '',
    });

    $trace = Trace.MAKE(_name);
    window[_name] = vl => (arr(vl).forEach(v => $launcher.add(v)), this);
    document.addEventListener('DOMContentLoaded', x => this._bootstrap());
    Object.freeze(this);
  }
  _bootstrap() {
    return new Promise(async resolve => {
      this._onload.forEach(v => v());

      prop(this._property, { isWorking: true });
      $resource = document.body.appendChild(el('div'));
      $resource.setAttribute(DIF_RESOURCE, '');

      const {_option, _property:{openTrigger, closeTrigger}} = this;
      // 스크립트 로드
      await script([...$require]);
      // 콤포넌트 생성 대기
      await Promise.all($component.map(c => c.open()));
      $component.length = 0;

      // 등록컨트롤러 옵션값 등록
      $controller.forEach(ctrl => {
        // 컨트롤러 옵션값 세팅
        Object.entries(_option)
        .forEach(([ky, vl]) => prop(ctrl.ex, {[ky]:(...v) => vl(ctrl, ...v)}));

        // 트리거 세팅
        $launcher.has(ctrl.name) || ctrl.setTrigger(this, openTrigger, closeTrigger);
      });
      // 등록 컨트롤러 오픈
      $launcher.forEach(v => $controller.get(v).open(this));

      // Object.freeze(this);
      resolve();
    });
  }
  // 로그추적 도구
  get trace() { return $trace; }
  set root(root) { prop(this._property, {root}); }

  // method
  debug(vl) { arr(vl).forEach(v => $debug.add(v)); };
  onload(fn) {
    if(this._property.isWorking) return;
    istype([fn, 'function']) && this._onload.push(fn);
  }
  require(vl) {
    if(this._property.isWorking) error(`app is working`);
    else arr(vl).forEach(v => v && $require.add(v));
  }
  path(vl='') {
    const {_property:{root}} = this;
    return `${root}/${vl.replace(/^\//, '')}`;
  }

  // controller
  set ctrlOpen(openTrigger) {
    istype([openTrigger, 'function']) && prop(this._property, {openTrigger});
  }
  set ctrlClose(closeTrigger) {
    istype([closeTrigger, 'function']) && prop(this._property, {closeTrigger});
  }
  set router(fn) {
    if(!istype([fn, 'function'])) return error('invalid param');
    window.onpopstate = history.onpushstate = fn;
  }

  // get ctrlEx() { return this._option; }

  ctrl(vl) { return this.controller(vl); }
  controller(name) { return $controller.get(name); }

  view(_name, _procedure) {
    if($controller.has(_name)) return error(`"${_name}" is duplicate`);
    return $controller.set(_name, Controller.MAKE({_name, _procedure, CLASS:View})).get(_name);
  }
  popup(_name, _procedure) {
    if($controller.has(_name)) return error(`"${_name}" is duplicate`);
    return $controller.set(_name, Controller.MAKE({_name, _procedure, CLASS:Popup})).get(_name);
  }
  component(_name, _procedure) {
    if($controller.has(_name)) return error(`"${_name}" is duplicate`);
    const ctrl = Controller.MAKE({_name, _procedure, CLASS:Component});
    $component.push(ctrl);
    $controller.set(_name, ctrl);
    return ctrl;
  }
  directive(_name, _procedure) {
    Directive.MAKE({_name, _procedure});
  }

  // resource
  getResource(selector) { return selector ? qr(selector, $resource) : $resource; }
  removeResource(selector) {
    if(!selector) return;
    const target = istype([selector, 'string']) ? qr(selector, $resource) : selector;
    $resource.removeChild(target);
  }
  insertResource(selector, position='after') {
    const insert = vl => vl ?
      $resource.insertBefore(el('div'), vl) :
      $resource.appendChild(el('div'));
    if(selector === undefined) return insert();

    const target = istype([selector, 'string']) ? qr(selector, $resource) : selector;
    if(position == 'after') return insert(target && target.nextSibling);
    if(position == 'before') return insert(target);
  }
};
