const error = (...vl) => { console.error(...vl); }
const def = Object.defineProperties;
const assign = (...v) => Object.assign(...v);
const istype = (vl, tp) => (/^array$/.test(tp) ? Array.isArray(vl) : typeof vl == tp);
const array = (vl=[]) => Array.isArray(vl) ? vl : [vl];
const clone = vl => {
  if(istype(vl, 'array')) return [].concat(vl);
  return istype(vl, 'object') ? assign({}, vl) : vl;
};
// element util
const el = t => document.createElement(t);
// app util
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`).replace(/^-/, '');
const datetime = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]);

const $app = {};
const $controller = new Map;
const getProp = name=> $controller.get(name).prop;
const clearProp = name=> assign(getProp(name), {
  parent:null, data:null, openResolve:null, closeResolve:null,
  vo:null, on:null, css:null, attr:null, style:null,
  element:null, html:null, url:null,
});


// ---------- Controller ---------- //
const Controller = class {
  static CREATE(type, name, open, init) {
    if($controller.has(name)) return console.error(`duplicate "${name}"`);
    const Class = class extends Controller {
      constructor() {
        super(name, type);
        init && init(this);
      }
    };
    $controller.set(name, {
      ctrl:Object.freeze(new Class),
      prop:{type, name, open},
    });
  }
  constructor(_name, _type) {
    assign(this, {_name, _type});
    this._create && this._create();
  }
  get name() { return this._name; }
  get type() { return this._type; }
  get element() { return getProp(this.name).element; }
  set element(element) { assign(getProp(this.name), {element}); }
  set url(url) { assign(getProp(this.name), {url}); }
  set html(html) { assign(getProp(this.name), {html}); }
  get parent() { return getProp(this.name).parent; }
  get data() { return getProp(this.name).data; };
  get vo() {  return getProp(this.name).vo; }
  get on() { return getProp(this.name).on; }

  set onload(onload) { assign(getProp(this.name), {onload}); }
  set onclose(onclose) { assign(getProp(this.name), {onclose}); }
  get el() {
    const {css, attr, style}=getProp(this.name);
    const el={};
    el.css = vl=> {
      if(!vl) return css();
      css(assign(css(), vl));
    };
    el.attr = vl=> {
      if(!vl) return attr();
      attr(assign(attr(), vl));
    };
    el.style = vl=> {
      if(!vl) return style();
      style(assign(style(), vl));
    };
    return el;
  }
  get debug() {
    const isChrome = navigator.userAgent.toLowerCase().indexOf('chrome') >= 0;
    const {type, name, _error} = this;
    const label = isChrome ? [`%c${type}:${name}`, 'font-weight:bold;color:#1ab'] : [`${type}:${name}`];
    return {
      log(...vl) { $app.debug && console.log(...label, ...vl); },
      info({hierarchy, text, color='#333'}={}, ...vl) {
        $app.debug && text && isChrome ? console.log(
          `%c${type}:${name} %c${text}\n`,
          'font-weight:bold;color:#1ab',
          `color:#${color.replace(/^#/, '')}`,
          ...vl.map(vl=> (hierarchy ? JSON.stringify(vl,'','  ') : vl))
        ) : console.log(...label, ...vl.map(vl=> (hierarchy ? JSON.stringify(vl,'','  ') : vl)));
      },
      break() { if($app.debug) debugger; },
      hierarchy(...vl) {
        $app.debug && console.log(...label, ...vl.map(vl=> JSON.stringify(vl,'','  ')));
      },
      error(vl) {
        if(_error) return _error(new Date(), `${type}:${name} ${vl}`, new Error().stack), vl;
        return console.error(...label, vl), vl;
      },
    };
  }

  value(vl) {
    const vo=istype(vl, 'array') ? $app.ko.observableArray(vl) : $app.ko.observable(vl);
    return Object.defineProperties(vo, {
      $data: {get() { return $app.ko.unwrap(vo);}, set(vl) { vo(vl); }},
      $length: {get() { return $app.ko.unwrap(vo).length;}},
    });
  }
  event() {
    const handle={};
    handle.on = (name, fnc) => {
      if(name == 'on') return handle;
      if(!istype(name, 'string') || !istype(fnc, 'function'))
        return this.debug.error(`invalid event listener`);

      return assign(handle, {
        [name](...arg) {
          const ev = arg.pop(), vo = arg.pop() || {};
          return ev instanceof Event ? fnc(ev, vo.ctrl == this || vo) : fnc;
        }
      });
    };
    return handle;
  }
  animation(target) {
    return new Promise(resolve => {
      if(!target) return resolve();

      let nonAni = true;
      const animationstart = _=> {
        nonAni = false;
        target.removeEventListener('animationstart', animationstart)
      };
      const animationend = _=> {
        target.removeEventListener('animationend', animationend), resolve();
      };
      target.addEventListener('animationstart', animationstart);
      target.addEventListener('animationend', animationend);

      setTimeout(_=> nonAni && resolve(), 100);
    });
  }

  get(name) {
    const {ctrl, prop:{openResolve}} = $controller.get(name);
    return openResolve && ctrl;
  }
  open(name, param) {
    return new Promise((resolve, reject)=> {
      const {ctrl:child} = $controller.get(name);
      if(!child) return reject(this.debug.error(`invalid controller "${name}"`));

      const {parent} = child;
      if(parent) return reject(this.debug.error(`is open "${child.name}"`));
  
      resolve(child.run(this, clone(param)));
    });
  }
  _open() { this.debug.error(`open is overrided`); }
  close(param) {
    new Promise(async (resolve, reject)=> {
      const prop=getProp(this.name);
      const {openResolve, closeResolve, onclose} = prop;
      if(!openResolve) return reject(this.debug.error('not open'));
      if(closeResolve) return reject(this.debug.error('close is working'));
      assign(prop, { closeResolve:resolve });

      await new Promise(r=> r(this._onclose && this._onclose()));

      const {attr, css, style} = prop;
      attr(Object.entries(attr()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
      css(Object.entries(css()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
      style(Object.entries(style()).reduce((tg, [ky])=> assign(tg, {[ky]:false}), {}));
  
      onclose && onclose();
      resolve(), openResolve(clone(param));
      this._close();

      clearProp(this.name);
    });
  }
  _close() { this.debug.error(`close is overrided`); }
  run(parent, param) {
    return new Promise(async (resolve, reject)=> {
      if(!parent) return resolve();

      const vo={}, on={}, data={};
      const css=$app.ko.observable({});
      const attr=$app.ko.observable({});
      const style=$app.ko.observable({});

      const prop=getProp(this.name);
      assign(prop, { parent, data, vo, on, css, attr, style, openResolve:resolve });

      const {open}=prop;
      open && open(this, param);
      this._open();

      const {onload, element, html, url} = prop;
      if(!element) return reject(this.debug.error('invalid element'));

      const tpl = html || url && await fetch(url).then(rs => rs.text());
      element.setAttribute('tabindex', '0');
      if(tpl) element.innerHTML = tpl;

      // ko binding
      $app.ko.cleanNode(element);
      $app.ko.applyBindingsToNode(element, { css, attr, style });
      $app.ko.applyBindings({ vo, on, ctrl:this }, element);

      await new Promise(r=> r(this._onload && this._onload()));
      onload && onload();
    });
  }
};

window.App = class {
  constructor(create) {
    create && create(this);
    $app.ko = require('../libs/knockout-shc');
    // $app.ko.f.re(
    //   RegExp(`^\\s*${$app.prefix||'ko'}(?:\\s+([\\s\\S]+))?\\s*$`),
    //   RegExp(`^\\s*\\/${$app.prefix||'ko'}\\s*$`)
    // );
    Object.freeze(this);
  }
  get Controller() { return Controller.prototype; }
  get isWorking() { return $app.isWorking; }
  set debug(vl) { assign($app, { debug:array(vl).indexOf(location.hostname)>=0 }); }
  set prefix(prefix) { assign($app, {prefix}); }
  get prefix() { return `data-${$app.prefix||'ko'}`; }

  // error(...vl) {
  //   console.error(...vl);
  //   this._error && this._error(new Date().getTime(), vl.join('\n'), new Error().stack);
  // }
  createController(type, name, open, init) { Controller.CREATE(type, name, open, init); }
  component(name, open) {
    Controller.CREATE('Component', name, open, ctrl=> {
      ctrl.open = function() { ctrl.debug.error(`open is can not support`); };
      ctrl.close = function() { ctrl.debug.error(`close is can not support`); };
      ctrl.run = _=> new Promise(async (resolve, reject)=> {
        const prop = getProp(name);
        if(prop.template) return reject(ctrl.debug.error('is working'));
        
        const vo={}, on={};
        assign(prop, { vo, on });
        open && open(ctrl);

        const {url, html} = prop;
        const template = html || url && await fetch(url).then(rs => rs.text());
        const createViewModel = (_, {element}) => {
          assign(prop, { element });
          // const {$data:{ctrl:_parent}} = ko.contextFor(element); // 모 컨트롤러 취득 방법
          $app.ko.applyBindingsToNode(element, {ctrl});
          return {vo, on, ctrl};
        };

        // 화면 바인딩
        $app.ko.components.register(snake(name), {
          template,
          viewModel: { createViewModel }
        });
        assign(prop, { template });
        resolve();
      });
    });
  }
  directive(name, init, update) {
    $app.ko.bindingHandlers[name] = {
      init(el, vl, bind, vo, context) {
        const {ctrl} = vo;
        const {$parents:[parent]} = context;
        init && init(parent ? parent.ctrl : ctrl, el, vl());
      },
      // update(el, vl, bind, vo, context) {
      //   const {ctrl} = vo;
      //   const {$parents:[parent]} = context;
      //   update && update(parent ? parent.ctrl : ctrl, el, vl());
      // }
    };
  }

  property(name, prop) { return def(this, {[name]:prop}); }
  ready(prc) {
    return new Promise(rs=> document.addEventListener('DOMContentLoaded', _=> {
      $app.isWorking = true;
      rs(prc && prc());
      // 콤포넌트 로드
    })).then(_=> Promise.all(([...$controller]).map(([_, {ctrl}])=> ctrl.run())));
  }
  loadScript(vl) {
    const js = new Set(vl);
    return Promise.all([...js].map(vl => new Promise(resolve => {
      if(!/\.js$/.test(vl)) return resolve({ load: false, name: vl });

      const lib = document.head.appendChild(el('script'));
      lib.src = `${vl}?v=${datetime('YMD')}`;
      lib.onload = _=> resolve({ load: true, name: vl });
      lib.onerror = _=> resolve({ load: false, name: vl });
    }))).then(ls=> {
      const err = ls.reduce((err, vl)=> ((vl.load || err.push(vl.name)), err), []);
      if(err.length) throw `load script failed ${err.join(', ')}`;
    });
  }
};
