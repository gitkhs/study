const error = (...vl) => { console.error(...vl); }
const assign = (...v) => Object.assign(...v);
const istype = (vl, tp) => (/^array$/.test(tp) ? Array.isArray(vl) : typeof vl == tp);
const array = (vl=[]) => Array.isArray(vl) ? vl : [vl];
const clone = vl => {
  if(istype(vl, 'array')) return [].concat(vl);
  return istype(vl, 'object') ? assign({}, vl) : vl;
};
// element util
const el = t => document.createElement(t);
const qr = (s, d = document) => d.querySelector(s);
// app util
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`).replace(/^-/, '');
const datetime = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]);
const clsName = ({type, name}) => `${type}:${name}`;
const animation = (selector, befor) => {
  const target = typeof selector == 'string' ? qr(selector) : selector;
  befor && befor(target);

  return new Promise(resolve => {
    let nonAni=true;
    const animationstart = _=> {
      nonAni = false;
      target.removeEventListener('animationstart', animationstart);
    };
    const animationend = _=> {
      resolve({target, status:'animationend'});
      target.removeEventListener('animationend', animationend);
    };

    target.addEventListener('animationstart', animationstart);
    target.addEventListener('animationend', animationend);
    setTimeout(_=> nonAni && resolve({target}), 100);
  });
};

module.exports = ko=> {
  const $app = {};
  const $controller = new Map;
  const $property = new WeakMap;

  // ---------- Controller ---------- //
  const Controller = class {
    static make(Class, name, procedure) {
      return Object.freeze(new Class({name, procedure}));
    }
    constructor({name, type, procedure}) {
      $property.set(this, {
        name, type, vo:{}, on:{},
        active:ko.observable(true), style:ko.observable({}),
        css:ko.observable({}), attr:ko.observable({}),
      });
      procedure && procedure(this);
    }

    // $property
    get type() { return $property.get(this).type; }
    get name() { return $property.get(this).name; }
    set onload(onload) { assign($property.get(this), {onload}); }
    get element() { return $property.get(this).element; }
    get parent() { return $property.get(this).parent; }    
    get param() { return $property.get(this).param; }
    get vo() {  return $property.get(this).vo; }
    get on() { return $property.get(this).on; }
    set url(url) { assign($property.get(this), {url}); }
    set html(html) { assign($property.get(this), {html}); }

    log(...vl) {
      $app.debug && console.log(`%c${clsName(this)}`, 'font-weight:bold;color:#1ab', ...vl);
    }
    active(vl=true) {
      const {active}=$property.get(this);
      active(vl);
      return this;
    }
    attr(vl) {
      const {attr}=$property.get(this);
      istype(vl, 'object') && attr(assign(attr(), vl));
      return this;
    }
    css(vl) {
      const {css}=$property.get(this);
      istype(vl, 'object') && css(assign(css(), vl));
      return this;
    }
    style(vl) {
      const {style}=$property.get(this);
      istype(vl, 'object') && style(assign(style(), vl));
      return this;
    }
    value(vl) {
      const vo=istype(vl, 'array') ? ko.observableArray(vl) : ko.observable(vl);
      return Object.defineProperties(vo ,{
        $data: {get() { return ko.unwrap(vo);}, set(vl) { vo(vl); }},
        $length: {get() { return ko.unwrap(vo).length;}},
      });
    }
    event() {
      const handle={};
      handle.on = (name, fnc) => {
        if(name == 'on') return handle;
        if(!istype(name, 'string') || !istype(fnc, 'function'))
          return error(`${clsName(this)}| invalid param`);
  
        return assign(handle, {
          [name](...arg) {
            const ev = arg.pop(), vo = arg.pop() || {};
            return ev instanceof Event ? fnc(ev, vo.ctrl == this || vo) : fnc;
          }
        });
      };
      return handle;
    }
    openTrigger(openTrigger) {
      return assign($property.get(this), {openTrigger}), this;
    }
    closeTrigger(closeTrigger) {
      return assign($property.get(this), {closeTrigger}), this;
    }
    // closetrigger
  
    open(name, param) {
      const child = $controller.get(name);
      if(!child) return error(`${clsName(this)}| invalid controller "${name}"`);
  
      const {parent} = $property.get(child);
      if(parent) return error(`${clsName(child)}| is open`);
  
      return child.run(this, clone(param));
    }
    _run() { error(`${clsName(this)}| open is overrided`); }
    run(parent, param) {
      assign($property.get(this), {
        parent, param, vo:{}
      });
      this._run();

      return new Promise(async (resolve, reject)=> {
        const {element, template, html, url} = $property.get(this);
        const tpl = html || url && await fetch(url).then(rs => rs.text()) || template;
        element.setAttribute('tabindex', '0');
        element.setAttribute('data-bind', 'if:active');
        tpl && assign(element, { innerHTML:tpl });

        // ko binding
        const {css, attr, style} = $property.get(this);
        const {active, vo, on} = $property.get(this);
        ko.cleanNode(element);
        ko.applyBindingsToNode(element, { css, attr, style });
        ko.applyBindings({ active, vo, on, ctrl:this }, element);

        const {prefix} = $app;
        const {onload, openTrigger} = $property.get(this);
        // const motion = qr(`[${prefix}-motion]`, element);
        // motion && motion.setAttribute(`${prefix}-motion`, 'open');

        onload && onload(param);
        // await animation(element)
        await openTrigger && openTrigger(this);

        assign($property.get(this), {openResolve:resolve});
      });
    }
    _close() { error(`${clsName(this)}| close is overrided`); }
    close(param) {
      const {openResolve, closeResolve} = $property.get(this);
      if(!openResolve || closeResolve) return;

      new Promise(async closeResolve=> {
        assign($property.get(this), {closeResolve});

        const {prefix} = $app;
        const {element} = $property.get(this);
        const motion = qr(`[${prefix}-motion]`, element);
        motion && motion.setAttribute(`${prefix}-motion`, 'close');

        openResolve(clone(param));
        closeResolve();
        await animation(element)

        const {closeTrigger} = $property.get(this);
        (parent.name == 'main') || closeTrigger && closeTrigger(this);

        this._close();
        assign($property.get(this), {
          parent:null, openResolve:null, closeResolve:null
        });
      });
    }
  };
  // ---------- View Controller ---------- //
  const View = class extends Controller {
    static GET(vl) { return Object.freeze(new View(vl)); }
    constructor(vl) {
      super(assign(vl, {type:'View'}));
    }
    _run() {
      const {name, parent} = $property.get(this);
      const {prefix} = $app;
      const selector = `[${prefix}-view=${snake(name)}]`;
      const makeView = _=> {
        if(name == 'main') return el('div');

        const {element} = $property.get(parent);
        if(!element) return error(`${clsName(this)}| invalid element`);

        const {nextSibling, parentNode} = element;
        const div = parentNode.insertBefore(el('div'), nextSibling);
        div.setAttribute(`${prefix}-view`, snake(name));
        return div;
      };
      const element = qr(selector) || makeView();
      const getCss = (list)=> ({
        reduce(fn, tg) {
          let pos=0;
          while(pos < list.length) tg = fn(tg, list[pos++]);
          return tg;
        }
      });
      const oldCss = getCss(element.classList||[])
        .reduce((css, name)=> assign(css, {[name]:true}), {});
      const oldStyle = (element.getAttribute('style')||'').split(';').reduce((st, v)=> {
        const [ky, vl] = v.trim().split(':');
        return ky ? assign(st, {[ky]:vl}) : st;
      }, {});
      const oldHTML = element.innerHTML;
      assign($property.get(this), {element, oldCss, oldStyle, oldHTML});
    }
    _close() {
      const {element, css, attr, style} = $property.get(this);
      const {oldCss, oldStyle, oldHTML} = $property.get(this);
      const clear = (tg, org)=> {
        Object.entries(tg()).forEach(([ky])=> tg({[ky]:false}));
        tg(org||{});
      };

      clear(css, oldCss);
      clear(style, oldStyle);
      clear(attr);
      element.innerHTML = oldHTML || '';
    }
  };
  // ---------- Popup Controller ---------- //
  const Popup = class extends Controller {
    static GET(vl) { return Object.freeze(new Popup(vl)); }
    _close() {
      const {css, attr, style} = $property.get(this);
      css({}), attr({}), style({});
    }
  };
  // ---------- Component Controller ---------- //
  const Component = class extends Controller {
    static GET(vl) { return Object.freeze(new Component(vl)); }
    load() {
      console.log('--Component:load--');
    }
  };

  window.App = class {
    constructor(extend) {
      extend && extend(this);
      assign($app, {prefix:`data-app`});
      Object.freeze(this);
    }
    set getter(get) {
      return get.name && Object.defineProperties(this, {[get.name]:{get}}), this;
    }
    set setter(set) {
      return set.name && Object.defineProperties(this, {[set.name]:{set}}), this;
    }

    // $app
    set debug(vl) { assign($app, { debug:array(vl).indexOf(location.hostname)>=0 }); }
    set prefix(vl) { assign($app, {prefix:`data-${vl}`}); }
    get prefix() { return $app.prefix; }
    get isRun() { return $app.isRun; }
    get resource() { return $app.resource; }

    ready(proc) {
      return new Promise(rs=> {
        document.addEventListener('DOMContentLoaded', _=> {
          rs(proc && proc());

          const {prefix} = $app;
          const resource = document.body.appendChild(el('dev'));
          resource.setAttribute(`${prefix}-resource`, '');
          assign($app, {resource});
        });
      });
    }
    loadScript(vl) {
      const js = new Set(vl);
      return Promise.all([...js].map(vl => new Promise((resolve, reject) => {
        if(!/\.js$/.test(vl)) return reject(`script file type(*.js) error: '${vl}'`);
            const lib = document.head.appendChild(el('script'));
        lib.src = `${vl}?v=${datetime('YMD')}`;
        lib.onload = _=> resolve({ load: true, name: vl });
        lib.onerror = _=> reject(`script load failed: ${vl}`);
      })));
    }
    run(vl) {
      if($app.isRun) return error('app is run');
      $app.isRun = true;

      $controller.set('main', Controller.make(View, 'main', ctrl=> {
        ctrl.onload = st=> {
          Promise.all(([...$controller]).map(([name, ctrl])=> {
            // 콤포넌트 로드
            return ctrl.load && ctrl.load();
          })).then(_=> {
            // 스타트 컨트롤러 오픈
            st.forEach(name=> ctrl.open(name));
          });
        };
      })).get('main').run(this, new Set(vl));
    }

    get Controller() { return Controller.prototype; }
    get View() { return View.prototype; }
    get Popup() { return Popup.prototype; }
    create(prototype, name, procedure) {
      if($controller.has(name)) error(`"${name}" is duplicate controller`);

      const Class = {
        [View.prototype.constructor.name]: View,
        [Popup.prototype.constructor.name]: Popup,
        [Component.prototype.constructor.name]: Component,
      };
      const ctrl = Controller.make(Class[prototype.constructor.name], name, procedure);
      return $controller.set(name, ctrl).get(name);
    }

    animation(selector, befor) {
      const target = typeof selector == 'string' ? qr(selector) : selector;
      befor && befor(target);
    
      return new Promise(resolve => {
        let nonAni=true;
        const animationstart = _=> {
          nonAni = false;
          target.removeEventListener('animationstart', animationstart);
        };
        const animationend = _=> {
          resolve({target, status:'animationend'});
          target.removeEventListener('animationend', animationend);
        };
    
        target.addEventListener('animationstart', animationstart);
        target.addEventListener('animationend', animationend);
        setTimeout(_=> nonAni && resolve({target}), 100);
      });
    }
  };
};
