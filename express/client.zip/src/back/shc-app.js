/*
let $resource, $trace;
const $debug = new Set;
const $launcher = new Set;
const $require = new Set;
const $controller = {};

const DIF_PREFIX = 'data-shc';
const DIF_VIEW = `${DIF_PREFIX}-view`;
const DIF_POPUP = `${DIF_PREFIX}-popup`;
const DIF_MOTION = `${DIF_PREFIX}-motion`;
const DIF_RESOURCE = `${DIF_PREFIX}-resource`;

// library
const ko = require('../libs/knockout-shc');

// object util
const istype = (vl, tp) => (/^array$/.test(tp) ? Array.isArray(vl) : typeof vl == tp);
const prop = (...v) => Object.assign(...v);
const arr = (vl=[]) => Array.isArray(vl) ? vl : [vl];
const error = (...vl) => console.error && console.error(...vl);
const clone = vl => {
  if(istype(vl, 'array')) return [].concat(vl);
  return istype(vl, 'object') ? prop({}, vl) : vl;
};

// element util
const el = t => document.createElement(t);
const qr = (s, d = document) => d.querySelector(s);
const script = vl => {
  return Promise.all(arr(vl).map(vl => new Promise((resolve, reject) => {
    if(!/\.js$/.test(vl)) return error(`file type(*.js) error: '${vl}'`);

    const lib = document.head.appendChild(el('script'));
    lib.src = `${vl}?v=${datetime('YMD')}`;
    lib.onload = _=> resolve({ load: true, name: vl });
    lib.onerror = _=> resolve({ load: false, name: vl });
  })));
};
const animation = (selector, befor) => {
  const target = typeof selector == 'string' ? qr(selector) : selector;
  befor && befor(target);

  return new Promise(resolve => {
    let nonAni=true;
    const animationstart = _=> {
      nonAni = false;
      target.removeEventListener('animationstart', animationstart);
    };
    const animationend = _=> {
      resolve({target, status:'animationend'});
      target.removeEventListener('animationend', animationend);
    };

    target.addEventListener('animationstart', animationstart);
    target.addEventListener('animationend', animationend);
    setTimeout(_=> nonAni && resolve({target}), 100);
  });
};

// app util
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`).replace(/^-/, '');
const datetime = (
	f='Y.M.D hh:mi:ss:ms',
	d=new Date,
	r=(v, c, d='0') => (d.repeat(c)+v).substr(v.toString().length),
	t={
		Y: r(d.getFullYear(),4),
		M: r(d.getMonth()+1,2),
		D: r(d.getDate(),2),
		hh: r(d.getHours(),2),
		mi: r(d.getMinutes(),2),
		ss: r(d.getSeconds(),2),
		ms: r(d.getMilliseconds(),3),
	}
) => f.replace(/Y|M|D|hh|mi|ss|ms/g, v => t[v]);
const clsName = ({_type, _name}) => `${_type}:${_name}`;

// ---------- class Trace ---------- //
const Trace = class {
  static MAKE(name) { return Object.freeze(new Trace(name)); }
  constructor(name) {
    prop(this, {name, _property:{max:10}});
  }

  set max(max) { prop(this._property, {max}); }
  log(...vl) {
    if(!vl.length || !$debug.has(location.hostname)) return;
    const opt = vl.pop();
    const {option, bold, color='#2a4'} = opt || {};
    const title = option ? [`%c${option}\n`,`color:${color};${bold&&'font-weight:bold;'}`] : [];
    console.log(...title, ...vl, option?'':opt);
  }
  error(...vl) {
    if(!localStorage) return;
    const errors = localStorage.__app_errors__ ? JSON.parse(localStorage.__app_errors__) : [];
    const {_property:{max}} = this;

    if(!vl.length) return localStorage.__app_errors__;

    errors.unshift({
      time: new Date().getTime(),
      stack: new Error().stack,
      log: JSON.stringify(vl),
    }) > max && (errors.length = max);
    localStorage.__app_errors__ = JSON.stringify(errors);
    console.error(...vl);
  }
  stack(vl) {
    const errors = vl ? JSON.parse(vl) : [];
    errors.forEach(vl => {
      const {time, log, stack} = vl;
      this.log(...JSON.parse(log), '\n', stack, {
        option: `error stack: ` + datetime('Y.M.D hh:mi:ss:ms', new Date(time))
      })
    });
  }
  clear() { localStorage.__app_errors__ = ''; }
};

// ---------- class Directive ---------- //
const Directive = class {
  static MAKE(vl) { return new Directive(vl); }
  constructor(vl) {
    const {_name, _procedure} = vl;
    ko.bindingHandlers[_name] = {
      init(el, vl, bind, vo, context) {
        const {ctrl} = vo;
        const {$parents:[parent]} = context;
        _procedure && _procedure(parent ? parent.ctrl : ctrl, el, vl());
      }
      // update는 처리하지 않는 거로
      // update(el, vl, bind, {ctrl}, context) { update && update(el, vl(), ctrl); }
		};
  }
};

// ---------- class Controller ---------- //
const Controller = class {
  static MAKE(CLASS, prop) {
    return Object.freeze(CLASS.MAKE(prop));
  }
  constructor({_name, _type, _procedure, _extend={}}) {
    const _property = {
      child:null, parent:null, onload:null, onclose:null,
      vo:{}, on:{}, html:null, url:null, element:null,
      openResolve:null, closeResolve:null, openTrigger:null, closeTrigger:null,
      active:ko.observable({}), css:ko.observable({}),
      attr:ko.observable({}), style:ko.observable({}),
    };
    prop(this, { _name, _type, _procedure, _property });
    Object.entries(_extend).forEach(([ky, vl]) => {
      if(ky in this) return;
      this[ky] = istype(vl, 'function') ? (...v) => vl(this, ...v) : clone(vl);
    });
  }

  // property
  get type() { return this._type; }
  get name() { return this._name; }
  get vo() { return this._property.vo; }
  get on() { return this._property.on; }
  get el() { return this._property.element; }
  get attr() { return this._property.attr; }
  get css() { return this._property.css; }
  get style() { return this._property.style; }
  get parent() { return this._property.parent; }
  // get child() { return this._property.child; }

  set active(vl) { this._property.active(!!vl); }
  set onload(onload) { istype(onload, 'function') && prop(this._property, {onload}); }
  set onclose(onclose) { istype(onclose, 'function') && prop(this._property, {onclose}); }
  set url(url) { istype(url, 'string') && prop(this._property, {url}); }
  set html(html) { istype(html, 'string') && prop(this._property, {html}); }

  observer(vl) {
    const vo = istype(vl, 'array') ? ko.observableArray(vl) : ko.observable(vl);
    return Object.defineProperties(vo ,{
      $data: {get() { return ko.unwrap(vo);}, set(vl) { vo(vl); }},
      $length: {get() { return ko.unwrap(vo).length;}},
    });
  }
  handler(handle = {}) {
    handle.event = (name, fnc) => {
      if(name == 'event') return handle;
      if(!istype(name, 'string') || !istype(fnc, 'function'))
        return error(`${clsName(this)}| invalid param`);

      return prop(handle, {
        [name](...arg) {
          const ev = arg.pop(), vo = arg.pop() || {};
          return ev instanceof Event ? fnc(ev, vo.ctrl == this || vo) : fnc;
        }
      });
    };
    return handle;
  }
  log(...vl) {
    const {type, name} = this;
    $trace.log(...vl, {option:`${type}:${name}`, color:'#61f'});
  }
  setTrigger(openTrigger, closeTrigger) {
    prop(this._property, {openTrigger, closeTrigger});
  }
  _motion(type) {
    const {_property:{element}} = this;
    const motion = qr(`[${DIF_MOTION}]`, element);
    motion && motion.setAttribute(DIF_MOTION, type);
    return animation(element);
  }

  // open: this -> target open
  async open(name, prm) {
    const {_name, _property, get} = this;
    if(name == _name) return error(`${clsName(this)}| isopen`);
    if(name in $controller == false) return error(`"${name}" unknown controller`);

    const child = $controller[name];
    prop(_property, {child});
    // 차일드 바인딩 호출
    const result = await child.binding(this, clone(prm));
    prop(_property, {child:null});

    return clone(result);
  }
  // binding: this -> this open(binding)
  _binding() { error(`${clsName(this)}| bind is overrided`); }
  binding(parent, prm) {
    return new Promise(openResolve => {
      const {_name, _type, _property} = this;
      if(_property.openResolve) return error(`${clsName(this)}| isopen`);

      this._procedure(this, prm);
      this._binding();
      if(!_property.element) return error(`${clsName(this)}| [${DIF_PREFIX}-${_type}=${snake(_name)}] not find element`);

      prop(_property, {parent, openResolve});
      new Promise(async resolve => {
        const {element, html, url} = _property;
        const tpl = html || url && await fetch(url).then(rs => rs.text());

        // get template
        element.setAttribute('tabindex', '0');
        element.setAttribute('data-bind', 'if:active');
        tpl && prop(element, { innerHTML:tpl });
        if(this instanceof Popup) element.focus();

        // ko binding
        const {css, attr, style, vo, on, active} = _property;
        active(true);
        ko.cleanNode(element);
        ko.applyBindingsToNode(element, { css, attr, style });
        ko.applyBindings({ active, vo, on, ctrl:this }, element);

        // open noti
        const {openTrigger, onload} = _property;
        openTrigger && openTrigger(this);
        await this._motion('open');
        onload && onload();

        resolve();
      });
    });
  }
  // close: this -> this close
  _close() { error(`${clsName(this)}| close is overrided`); }
  close(result) {
    const {_property} = this;
    const {openResolve, closeResolve} = _property;
    // closeWorking
    if(closeResolve || !openResolve) return;

    new Promise(async closeResolve => {
      // close noti
      prop(_property, {closeResolve});
      const {closeTrigger, onclose} = _property;
      closeTrigger && closeTrigger(this);
      await this._motion('close');
      onclose && onclose();

      // 종료 및 초기화
      this._close();
      prop(_property, {
        vo:{}, on:{},
        openResolve:null, closeResolve:null, parent:null, onload:null, onclose:null,
        active:ko.observable({}), css:ko.observable({}),
        attr:ko.observable({}),style:ko.observable({}),
      });

      openResolve(result);
      closeResolve();
    });
  }
};

// ---------- class View ---------- //
const View = class extends Controller {
  static MAKE(vl) { return new View(vl); }  
  constructor(vl) {
    super(prop(vl, {_type:'view'}));
  }
  _binding() {
    const {_name, _property} = this;
    const makeView = (div=el('div')) => {
      div.setAttribute(DIF_VIEW, snake(_name));
      const {parent:{el:{nextSibling, parentNode}}} = _property;
      return nextSibling ? parentNode.insertBefore(div, nextSibling) : parentNode.appendChild(div);
    };
    const element = qr(`[${DIF_VIEW}=${snake(_name)}]`) || makeView();

    prop(_property, {element});
  }
  _close() {
    const {_property:{element}} = this;
    if(element) element.innerHTML = '';
  }
};

// ---------- class Popup ---------- //
const Popup = class extends Controller {
  static MAKE(vl) { return new Popup(vl); }  
  constructor(vl) {
    super(prop(vl, {_type:'popup'}));
  }
  _binding() {
    const {_name, _property} = this;
    const element = $resource.appendChild(el('div'));
    if(!element) return;

    prop(_property, {element});
    element.setAttribute(DIF_POPUP, snake(_name));
  }
  _close() {
    const {_property:{element}} = this;
    if(element) $resource.removeChild(element);
  }
};

// ---------- class Component ---------- //
const Component = class extends Controller {
  static MAKE(vl) { return new Component(vl); }  
  constructor(vl) {
    super(prop(vl, {_type:'comp'}));
  }
  binding(parent, prm) {}
  close(result) {}
  open(name, prm) {
    return new Promise(async resolve => {
      const {_name, _procedure, _property} = this;
      const {element} = _property;
      if(element) return error(`${clsName(this)}| isopen`);

      _procedure(this);

      const {url, html} = _property;
      const template = html || url && await fetch(url).then(rs => rs.text());
      const createViewModel = (prm, {element}) => {
        // 모 컨트롤러 취득 (사용할 일이 없네...)
        // const {$data:{ctrl:_parent}} = ko.contextFor(element);
        const {vo, on, onload} = _property;

        ko.applyBindingsToNode(element, {ctrl:this});
        onload && onload();

        return {vo, on, ctrl:this};
      };

      // 화면 바인딩
      prop(_property, {element:template});
      ko.components.register(snake(_name), {
        template,
        viewModel: { createViewModel }
      });
      resolve();
    });
  }
};

// ---------- class MakeApp ---------- //
new class MakeApp extends Controller {
  constructor() {
    const _name = 'ShcApp';
    super({_name});

    prop(this, { _name, _extend:{},  _onload:[], _service:{} });
    prop(this._property, { root: '', isWorking: false });

    $trace = Trace.MAKE(_name);
    window[_name] = vl => (arr(vl).forEach(v => $launcher.add(v)), this);
    document.addEventListener('DOMContentLoaded', _=> this._bootstrap());
  }
  _bootstrap() {
    Object.freeze(this);
    return new Promise(async resolve => {
      prop(this._property, { isWorking: true });
      $resource = document.body.appendChild(el('div'));
      $resource.setAttribute(DIF_RESOURCE, '');

      const {_property:{openTrigger, closeTrigger}} = this;
      // 스크립트 로드
      await script([...$require]);
      // 콤포넌트 오픈 대기
      await Promise.all(Object.values($controller).map(ctrl => {
        // 오픈, 종료 트리거 등록
        $launcher.has(ctrl.name) || ctrl.setTrigger(openTrigger, closeTrigger);
        return ctrl instanceof Component && ctrl.open();
      }));
      // 등록 컨트롤러 오픈
      $launcher.forEach(name => this.open(name));

      resolve();
    });
  }
  get trace() { return $trace; }
  set root(root) { prop(this._property, {root}); }

  // method
  debug(vl) { arr(vl).forEach(v => $debug.add(v)); };
  require(vl) {
    const {_property:{isWorking}} = this;
    isWorking ? error(`can not require: app is working`) : arr(vl).forEach(v => v && $require.add(v));
  }
  path(vl='') {
    const {_property:{root}} = this;
    return `${root}/${vl.replace(/^\//, '')}`;
  }
  // onload(fn) {
  //   if(this._property.isWorking) return;
  //   istype([fn, 'function']) && this._onload.push(fn);
  // }

  // controller
  set ctrlOpen(openTrigger) {
    istype(openTrigger, 'function') && prop(this._property, {openTrigger});
  }
  set ctrlClose(closeTrigger) {
    istype(closeTrigger, 'function') && prop(this._property, {closeTrigger});
  }
  set router(fn) {
    if(!istype(fn, 'function')) return error('invalid param');
    window.onpopstate = history.onpushstate = fn;
  }
  get ctrl() { return $controller; }
  get extend() { return this._extend; }
  view(name, proc, extend) { this._ctrlMake(View, name, proc, extend); }
  popup(name, proc, extend) { this._ctrlMake(Popup, name, proc, extend); }
  component(name, proc, extend) { this._ctrlMake(Component, name, proc, extend); }
  directive(_name, _procedure) { Directive.MAKE({_name, _procedure}); }
  _ctrlMake(CLASS, _name, _procedure, extend) {
    if(_name in $controller) return error(`"${_name}" is duplicate`);

    const _extend = clone(this._extend);
    extend && extend(_extend);
    $controller[_name] = Controller.MAKE(CLASS, {_name, _procedure, _extend});
  }

  // resource
  getResource(selector) { return selector ? qr(selector, $resource) : $resource; }
  removeResource(selector) {
    if(!selector) return;
    const target = istype(selector, 'string') ? qr(selector, $resource) : selector;
    $resource.removeChild(target);
  }
  insertResource(selector, position='after') {
    const insert = vl => vl ? $resource.insertBefore(el('div'), vl) : $resource.appendChild(el('div'));
    if(selector === undefined) return insert();

    const target = istype(selector, 'string') ? qr(selector, $resource) : selector;
    if(position == 'after') return insert(target && target.nextSibling);
    if(position == 'before') return insert(target);
  }
};
*/