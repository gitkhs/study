const App = require('./app');
window.koApp = init=> App(require('../libs/knockout-3.4.3'), init);