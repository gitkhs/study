module.exports = (lib) => {
	const Controller = require('./Controller')(lib);

	return class Bind extends Controller {
		constructor(fw, vl) {
			super(fw, vl);

			super.member({
				_parent: document.body,
			});
		}

		// 클래스 멤버변수 용
		member() {}

		// 화면 로드
		async load(param) {
			const {_onload} = super.member();

			this.render({
				append: false,
				created() {
					_onload && _onload(param);
				},
			});
		}
	};
};