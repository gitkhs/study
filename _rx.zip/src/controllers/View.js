module.exports = (lib) => {
	const Controller = require('./Controller')(lib);
	const {
		appQuery,
		appQueryAll,
	} = require('../utils');

	return class View extends Controller {
		constructor(fw, vl) {
			super(fw, vl);

			super.member({
				_parent: appQuery({ appContainer: '' }, document.body),
			});
		}

		// 클래스 멤버변수 용
		member() {}

		// 단일 뷰 로드
		async load(param) {
			const {_name, _parent, _onload} = super.member();
			const created = () => {
				const all = appQueryAll({ appView: '' }, _parent);
				for(let i=0; i<all.length; i++) {
					all[i].dataset.appView == _name || all[i].parentNode.removeChild(all[i]);
				}

				_onload && _onload(param);
			};

			await this.render({created});
		}
	};
};