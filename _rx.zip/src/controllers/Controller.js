module.exports = (lib) => {
	const localValue = new WeakMap();
	const {
		log,
		isIE,
		ajax,
		query,
		appQuery,
		appElement,
	} = require('../utils');
	const val = (obj, vl) => (vl ? Object.assign(localValue.get(obj), vl) : localValue.get(obj));
	const error = ({_clsName, _name}, ...vl) => {
		throw (_name ? `[${_clsName}::${_name}] ` : '') + vl.join(',');
	};

	// class: Controller
	// ================================================== //
	const Controller = class {
		constructor(_framework, {name: _name, tpl: _tpl, html: _html}) {
			const _clsName = this.constructor.name;
			_name || error({},`${_clsName} invalid name => ${_clsName.toLowerCase()}({name: ''}, function)`);
			_html || _tpl || error({}, `${_clsName} invalid template => ${_clsName.toLowerCase()}({name, html, tpl}, function)`);

			localValue.set(this, {
				_framework,
				_name,
				_tpl,
				_html,
				_clsName,
				_call: {},
				_vo: {},
				_on: {},
				_bindOn: {},
				_bindVo: {},
			});
		}

		// 클래스 멤버변수 용
		member(vl) {
			return val(this, vl);
		}

		// 로그
		log(...vl) {
			const {_name, _clsName} = val(this);

			if (isIE) log(`${_clsName}::${_name}\n`, ...vl);
			else log(`%c${_clsName}::${_name}\n`, 'font-weight:bold', ...vl);
		}

		// 포커스처리를 위한 DOM 객체
		prifixTarget(evt = {}) {
			const _target = typeof evt === 'string' ? query(evt) : evt.target;
			_target && val(this, { _target });

			return this;
		}

		// 컨트롤러 로드 함수 세팅
		onload(_onload) {
			val(this, { _onload });
		}

		// 화면 랜더링
		async render() {
			throw 'render method is override';
		}

		// 화면변수 관리 객체 세팅
		vo() {
			throw 'vo method is override';
		}

		// 화면 이벤트 관리 객체 세팅
		on() {
			throw 'on method is override';
		}

	};

	// class: Controller
	// ================================================== //
	const Knockout = class extends Controller {
		// 화면 랜더링
		async render({created, append=true} = {}) {
			const {
				_parent,
				_clsName,
				_tpl,
				_html,
				_name,
				_framework: ko,
				_bindOn: on,
				_bindVo: vo,
			} = val(this);
			const selector = `app${_clsName}`;
			const dom = appQuery({ [selector]: _name }, _parent) ||
				appElement({ [selector]: _name });
			const template = _html || await ajax(_tpl);

			val(this, {
				_html: template,
			});

			dom.innerHTML = template;
			append && _parent.appendChild(dom);

			ko.cleanNode(dom);
			ko.applyBindings({ vo, on }, dom);

			created && created();
		}

		// 화면변수 관리 객체 세팅
		vo(data) {
			const {
				_bindVo,
				_framework: ko,
			} = val(this);
			const isObject = vl => typeof vl == 'object' && !Array.isArray(vl);
			const observable = (vl) => Object.entries(vl).reduce((vo, [ky, vl]) => {
				if(isObject(vl)) {
					vo[ky] = observable(vl);
					return vo;
				}

				vo[ky] = Array.isArray(vl) ? ko.observableArray(vl) : ko.observable(vl);
				return vo;
			}, {});

			// ---------- 함수 구현부 ---------- //
			if(!data) return _bindVo;

			isObject(data) || error(val(this), '"vo" type error ==> type is Object');
			Object.assign(_bindVo, observable(data));

			return _bindVo;
		}

		// 화면 이벤트 관리 객체 세팅
		on(name, fn) {
			const {
				_on,
				_bindOn,
			} = val(this);

			if(!name) return _on;

			_on[name] = fn;

			Object.assign(_bindOn, {
				[name](...vl) {
					const evt = vl.pop();
					fn(evt, ...vl);
				},
			});
		}
	};

	// console.log('--knockout--', Knockout.name, fwName);
	if(lib == 'knockout') return Knockout;
	return Controller;
};
