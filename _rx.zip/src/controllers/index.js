module.exports = lib => {
	return {
		Bind: require('./Bind')(lib),
		View: require('./View')(lib),
		Modal: require('./Modal')(lib),
		Sheet: require('./Sheet')(lib),
		Controller: require('./Controller')(lib),
		// Component: require('./Component')(lib),
	};
};