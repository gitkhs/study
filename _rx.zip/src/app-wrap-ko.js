!function() {


const localValue = new WeakMap();
const ko = require('./libs/knockout-3.4.2');
const {
	log,
	date,
	snake,
	hash,
	element,
	appInfo,
	appQuery,
} = require('./utils');
const {
	Bind,
	View,
	Modal,
	Sheet,
	Controller,
	// Component,
} = require('./controllers')('knockout');
const Component = class extends Controller {
	// 클래스 멤버변수 용
	member() {}

	// 화면 로드
	load(param) {
		const {
			_name,
			_onload,
			_framework: ko,
			_html: template,
			_bindVo: vo,
			_bindOn: on,
		} = super.member();

		ko.components.register(snake(_name), {
			template,
			viewModel: function() {
				this.vo = vo;
				this.on = on;
				_onload && _onload(param);
			},
		});
	}
};


new class App {
	constructor() {
		window.rxApp = this;
		const head = document.head;

		// localValue
		localValue.set(this, {
			_bind: {},
			_view: {},
			_modal: {},
			_sheet: {},
			_component: {},
			_service: {},
		});

		// config includes append
		const today = date();
		appInfo.includes && appInfo.includes.forEach(vl =>
			head.appendChild(element('script', {
				attr: {
					src: `${vl}?=${today}`,
				},
			}))
		);

		// biz include
		const {biz} = hash();
		biz && head.appendChild(element('script', {
			attr: {
				src: `${biz}.js?=${today}`,
			},
		}));

		// ========== default layer popup ========== //
		const {
			name,
			path='',
			dailog: {
				alert = `${path}/${name}-alert.html`,
				confirm = `${path}/${name}-confirm.html`,
				toast = `${path}/${name}-toast.html`,
			},
		} = appInfo;

		// alert
		this.modal({name: 'modalAlert', tpl: alert}, ctrl => {
			const vo = ctrl.vo({ msg: '' });
			ctrl.onload(prm => vo.msg(prm));
			ctrl.on('close', () => ctrl.close());
		});
		// confirm
		this.modal({name: 'modalConfirm', tpl: confirm}, ctrl => {
			const vo = ctrl.vo({ msg: '', yes: '', no: '' });
			ctrl.onload(({msg, yes = 'yes', no = 'no'}) => {
				vo.msg(msg);
				vo.yes(yes);
				vo.no(no);
			});
			ctrl.on('yes', () => ctrl.close(true));
			ctrl.on('no', () => ctrl.close(false));
		});
		// toast
		this.sheet({name: 'sheetToast', tpl: toast}, ctrl => {
			const vo =ctrl.vo({ msg: '' });
			ctrl.onload(({msg, tm}) => {
				vo.msg(msg);
				setTimeout(() => ctrl.close(), (tm && typeof tm === 'number') || 3000);
			});
		});
		// 포커싱 디렉티브
		this.directive('focus', () => {
			const init = (el, vl, bind) => {
				setTimeout(() => el.focus(), 10);
			};
			const update = (el, bind) => {};
		
			return {init, update};
		});
	}

	// 프로그래스바
	progress(vl) {
		const prog = appQuery({ appProgressDailog: '' }, document.body);
		if(vl === undefined) {
			return prog.style.display == 'block';
		}

		prog.style.display = vl===false ? 'none' : 'block';
	}

	// 엘리먼트 바인드
	bind(vl, fn) {
		const {_bind} = localValue.get(this);
		if(typeof vl === 'string') return _bind[vl];

		const {name} = vl;
		const ctrl = new Bind(ko, vl);

		fn && fn(ctrl);
		ctrl.load();
		_bind[name] = ctrl;
	}

	// 뷰 컨트롤러
	view(vl, fn) {
		const {_view} = localValue.get(this);
		if(typeof vl === 'string') return _view[vl];

		const {name, auto} = vl;
		const ctrl = new View(ko, vl);

		fn && fn(ctrl);
		auto && ctrl.load();
		_view[name] = ctrl;
	}

	// 모달 컨트롤러
	modal(vl, fn) {
		const {_modal} = localValue.get(this);
		if(typeof vl === 'string') {
			return _modal[vl].prifixTarget(fn);
		};

		const {name} = vl;
		const ctrl = new Modal(ko, vl);

		fn && fn(ctrl);
		_modal[name] = ctrl;
	}

	// 바텀시트 컨트롤러
	sheet(vl, fn) {
		const {_sheet} = localValue.get(this);
		if(typeof vl === 'string') {
			return _sheet[vl].prifixTarget(fn);
		};

		const {name} = vl;
		const ctrl = new Sheet(ko, vl);

		fn && fn(ctrl);
		_sheet[name] = ctrl;
	}

	// 콤포넌트
	component(vl, fn) {
		const {_component} = localValue.get(this);
		if(typeof vl === 'string') {
			return _component[vl];
		}

		const {name} = vl;
		const ctrl = new Component(ko, vl);

		fn && fn(ctrl);
		ctrl.load();
		_component[name] = ctrl;
	}

	// 디렉티브
	directive(name, fn) {
		if(name && fn) {
			const {init, update} = fn();
			const val = (vl) => typeof vl === 'function' ? vl() : vl;

			ko.bindingHandlers[name] = {
				init(el, vl, bind) {
					init && init(el, val(vl()), bind().param);
				}, 

				update(el, vl, bind) {
					update && update(el, val(vl()), bind().param);
				},
			};
		}
	}

	// 서비스 모듈
	service(name, fn) {
		const {_service} = localValue.get(this);
		if(!fn) return _service[name];

		fn(_service[name] = {}, log);
	}

	// modal:: alert
	alert(msg, evt) {
		return this.modal('modalAlert', evt).open(msg);
	}

	// modal:: confirm
	confirm(msg, evt, {yes, no} = {}) {
		return this.modal('modalConfirm', evt).open({msg, yes, no});
	}

	// sheet:: toast
	toast(msg, tm) {
		return this.sheet('sheetToast').open({msg, tm});
	}

	// utility
	utils() {
		return require('./utils');
	}
};


}();