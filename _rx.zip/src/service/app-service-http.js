rxApp.service('http', function(svc, log) {
	var util = rxApp.utils();
	var isIE = util.isIE;
	var ajax = util.ajax;
	var promise = util.promise;
	var entries = util.entries;

	svc.get = function(url) {
        return ajax(url);
    };

    svc.post = function(url, param) {
        rxApp.progress(true);

        return promise(function(resolve, reject) {
            ajax(url, {
                method: 'POST',
                body: encodeURIComponent(JSON.stringify(param))
            }).then(function(data) {
                rxApp.progress(false);
                resolve(data);
            }).catch(function(err) {
                rxApp.progress(false);
                reject(err);
            });
        });
    };

    svc.submit = function(url, param) {
        rxApp.progress(true);

        return promise(function(resolve, reject) {
            ajax(url, {
                method: 'POST',
                body: entries(param).map(function(vl) {
                    return [
                        encodeURIComponent(vl[0]),
                        encodeURIComponent(
                            vl[1] instanceof Object ? JSON.stringify(vl[1]) : vl[1]
                        ),
                    ].join('=');
                }).join('&'),
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
                }
            }).then(function(data) {
                rxApp.progress(false);
                resolve(data);
            }).catch(function(err) {
                rxApp.progress(false);
                reject(err);
            });
        });
    };

    svc.download = function(url) {
        rxApp.progress(true);

        ajax(url).then(function(blob) {
			rxApp.progress(false);
            if(blob.size <= 0) return;

			var link;
			var filename = url.split('/');

			if(isIE) {
				window.navigator.msSaveBlob(blob, filename.pop());
			} else {
				link = document.createElement('a');
				link.setAttribute('href', (window.URL || window.webkitURL).createObjectURL(blob));
				link.setAttribute('download', filename.pop());
				link.click();
				link.remove();
			}
			console.log('link');
        }).catch(function(err) {
            rxApp.progress(false);
        });
    };

    svc.upload = function(url, frmSelector, observe) {
        // rxApp.progress(true);

        var form = document.querySelector(frmSelector);
        var files = form.querySelectorAll('input[type=file]');
        var values = {};
        files.forEach(function(vl) {
            values[vl.name] = vl.value;
        });

        if(!observe || !observe(values)) return;

        ajax(url, {
            method: 'POST',
            body: new FormData(form)
        }).then(function(data) {
            rxApp.progress(false);
            log('-s-', data);
        }).catch(function(err) {
            rxApp.progress(false);
            log('-e-', err);
        });
    };
});