-- database: u885560744_bom
-- user: u885560744_bom
-- pwd: bom_u885560744

-- use mysql;
-- grant all privileges on u885560744_bom.* to u885560744_bom@localhost identified by 'bom_u885560744';
-- delete from user where user = 'u885560744_bom';

create database u885560744_bom;

-- bom_site
CREATE TABLE bom_site (
	`uid` int unsigned auto_increment not null,
	`domain` varchar(80) not null,
	`admin` varchar(80) not null,
	`manager` varchar(256),
	`d_end` date,
	`info` text,
	`log` mediumtext,
	PRIMARY KEY (`uid`),
	UNIQUE INDEX `bom_site_unique` (`domain` ASC)
);
-- insert into bom_site(domain,admin,d_end) values('bom.localhost','a12@test.com','20181230');


-- bom_member
CREATE TABLE bom_member (
	`uid` char(16) not null,
	`email` varchar(80) not null,
	`info` text,
	PRIMARY KEY (`email`)
);

-- survey_req
CREATE TABLE survey_req (
	`uid` varchar(20) not null,
	`site_uid` int unsigned not null,
	`open` char(1) not null,
	`d_end` date,
	`data` mediumtext,
	PRIMARY KEY (`uid`, `site_uid`)
);

-- survey_res + site_uid
CREATE TABLE survey_res (
	`uid` int unsigned auto_increment not null,
	`req_uid` varchar(20) not null,
	`member_uid` char(16) not null,
	`d_res` date,
	`data` mediumtext,
	PRIMARY KEY (`uid`)
);

/*

선택항목


도메인, 제목
1. xxxx      2018.12.14
2. xxxx      2018.12.14

{
	label: '',
	type: text, radio, check,
	item: ['1', '2'],
}

[
'123', '222'
]
*/