<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master extends CI_Controller {
	private $VIEW_PATH = './web-app/views/master';

	public function __construct() {
		parent::__construct();

		// $this->load->model('tblBomSite');
		if($_SERVER['SERVER_NAME'] == 'localhost.bombombom.kr');
		else if($_SERVER['SERVER_NAME'] == 'www.bombombom.kr');
		else if($_SERVER['SERVER_NAME'] == 'bombombom.kr');
		else throw new Exception('잘못된 접근 정보 입니다.');
	}
	public function _remap($method) {
		if(!file_exists($this->VIEW_PATH.'/'.$method.'/'.$method.'.js')) {
			show_404();
			return;
		}

		$this->load->view('view_master', array(
			'method' => $method,
		));
	}
}
