<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Master extends CI_Controller {
	private $VIEW_PATH = './web-app/views/master';

	public function __construct() {
		parent::__construct();
	}
	public function _remap($method) {
		if(!file_exists($this->VIEW_PATH.'/'.$method.'/main.js')) {
			show_404();
			return;
		}

		$this->load->view('view_master', array(
			'method' => $method,
		));
	}
}
