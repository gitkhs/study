<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Seoul');

class Data_Controller extends CI_Controller {
	public function __construct() {
		parent::__construct();

		$this->load->helper('date');
		$this->today = mdate('%Y%m%d');

		$this->load->model('mdlLog');
		$this->load->model('mdlUtil');
		$this->load->model('mdlTable');
		$this->load->model('mdlSession');
	}

	// protected
	// -------------------- //
	protected function json($vl = null) {
		if($vl === null) {
			$input = urldecode(file_get_contents('php://input'));
			if(!$input && !isset($input))
				throw new Exception('입력값을 확인 하세요.');
			return (array)json_decode($this->security->xss_clean($input));
		}

		$origin = $this->nvl(apache_request_headers(), 'Origin');
		if($origin) {
			header('Access-Control-Allow-Origin: '.$origin);
			header('Access-Control-Allow-Credentials: true');
		}
		header('Content-Type: application/json; charset=utf-8');

		echo json_encode($vl);
	}

	// ----- utils ----- //
	protected function nvl($vl, $ky, $df = '') {
		return $this->mdlUtil->nvl($vl, $ky, $df);
	}
	protected function log($vl, $data = null) {
		$this->mdlLog->log($vl.($data ? ' '.json_encode($data) : ''));
	}
}
