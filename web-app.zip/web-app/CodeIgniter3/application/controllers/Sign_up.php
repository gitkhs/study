<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sign_up extends CI_Controller {
	private $SS_REFERER = '__page_referer__';

	public function __construct() {
		parent::__construct();
	}
	public function index() {
		$this->session->set_userdata(
			$this->SS_REFERER,
			isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '/'
		);
		header('Location: /sign-up/begin');
	}
	public function begin() {
		$this->load->view('view_sign', array(
			'step' => 'begin',
		));
	}
	public function final() {
		$this->load->view('view_sign', array(
			'step' => 'final',
			'referer' => $this->session->userdata($this->SS_REFERER),
		));
	}
}
