<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'controllers/Data_Controller.php';

class Index extends Data_Controller {
	protected $origin;
	protected $js_file, $html_file;

	public function __construct() {
		parent::__construct();

		$this->load->helper('file');

		// origin 도메인 체크
		$origin = $this->nvl(apache_request_headers(), 'Origin');
		$origin = preg_replace('/^https?:\/\/|:\d*$/', '', $origin);
		$origin = preg_replace('/^www\./', '', $origin);
		if(!$origin) return;

		$this->origin = $this->mdlSession->getOrigin();
		if(!$this->origin) {
			$this->origin = $this->mdlTable->row(array(
				'table' => 'bom_site',
				'where' => array(
					'domain' => $origin
				),
			));
		}

		if(!$this->origin) throw new Exception('승인되지 않은 도메인 입니다.');
		if($this->today > $this->nvl($this->origin, 'd_end'))
			throw new Exception('사용기간이 만료된 도메인 입니다.');

		if($this->origin) {
			$this->mdlSession->setOrigin($this->origin);
		}
	}

	public function js() {
		echo read_file('./web-app/libs/makeapp/make-app.js');
		echo read_file('./web-app/libs/makeapp/make-service-http.js');
		// echo read_file('./web-app/libs/makeapp/make-app-init.js');
		if(file_exists($this->js_file)) {
			echo read_file($this->js_file);
		}
	}
	public function html() {
		if(file_exists($this->html_file)) {
			echo read_file($this->html_file);
		}
	}
}
