<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'controllers/data/open/Index.php';

class Survey extends Index {
	public function __construct() {
		parent::__construct();
		$this->js_file = APPPATH.'views/open/js/survey.js';
	}

	public function form($uid = null) {
		if(!$uid) throw new Exception('폼아이디가 존재 하지 않습니다.');

		$site_uid = $this->nvl($this->origin, 'uid');
		if(!$site_uid) throw new Exception('승인되지 않은 요청 입니다.');

		$form = $this->mdlTable->row(array(
			'table' => 'survey_req',
			'where' => array(
				'site_uid' => $site_uid,
				'uid' => $uid,
			),
		));

		$this->json($form);
	}
	public function write() {
	}

	public function data_read() {
		$site_uid = $this->nvl($this->origin, 'uid');
		if(!$site_uid) throw new Exception('승인되지 않은 도메인 입니다.');

		$form = $this->selectRow(array(
			'table' => $this->defTable->survey_req,
			'where' => array(
				'site_uid' => $site_uid,
				'uid' => 'a1'
			),
		));
		if(!$form) throw new Exception('데이터가 존재 하지 않습니다.');
		if(!$this->nvl($form, 'open')) throw new Exception('게시가 중지된 자료입니다.');
		if($this->today > $this->nvl($form, 'd_end')) throw new Exception('게시 기간이 지났습니다.');

		$this->json($form);
	}
	public function data_write() {
	}
}
