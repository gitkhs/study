<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller {
	// defined
	protected $TBL_SITE = 'bom_site';
	protected $SS_SITE = '__auth_site__';

	public function __construct() {
		parent::__construct();

		// context setting
		$this->load->helper('date');
		$this->today = mdate('%Y%m%d');
		$this->local = $_SERVER['SERVER_NAME'] == 'localhost.bombombom.kr';

		// session site
		$this->ssSite = $this->session->userdata($this->SS_SITE);

		// 세션존재- 만료여부 확인
		if($this->ssSite) {
			if($this->is_end_date()) {
				$this->session->unset_userdata($this->SS_SITE);
				throw new Exception('사용기간이 만료된 도메인 입니다.');
			}
			return;
		}
	}

	// ---------- protected ---------- //
	protected function post_json() {
		$input = urldecode(file_get_contents('php://input'));
		if(!$input && !isset($input)) {
			throw new Exception('입력값을 확인 하세요.');
		}

		return json_decode($this->security->xss_clean($input));
	}
	protected function nvl($vl, $def = '') {
		return $vl ? $vl : $def;
	}

	// ---------- private ---------- //
	private function is_end_date() {
		if(!isset($this->ssSite['d_end'])) return true;
		if($this->today > $this->ssSite['d_end']) return true;
		return false;
	}
}
