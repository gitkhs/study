<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'controllers/data/Site.php';

class Member extends Site {
	protected $TBL_MEMBER = 'bom_member';
	protected $SS_MEMBER = '__auth_member__';

	public function __construct($level = null) {
		parent::__construct();

		$this->ssMember = $this->session->userdata($this->SS_MEMBER);
		if(!$level) return;
	}

	// local
	public function local() {
		if(!$this->local) {
			throw new Exception('잘못된 접근 입니다.');
		}

		$this->session->set_userdata($this->SS_MEMBER, array(
			'uid' => 'xxx1544505454444',
			'email' => 'a12@test.com',
		));

		$this->load->view('data_json');
	}

	public function stat() {
		$this->load->view('data_json', array(
			'sign' => !!$this->ssMember['email'],
		));
	}

	public function find() {
		$input = $this->post_json();
		if(!isset($input->email) || !$input->email)
			throw new Exception('이메일을 입력하세요.');

		$email = urldecode($input->email);
		$query = $this->db->query(
			"select email".
			"  from {$this->TBL_MEMBER}".
			" where email like ?".
			" order by email desc".
			" limit 0, 5",
			array(
				"%{$this->db->escape_like_str($email)}%"
			)
		);

		$this->load->view(
			'data_json',
			$query->num_rows() ? $query->result_array() : array()
		);
	}

	public function sign_up() {
		$input = $this->post_json();
		if(!isset($input->uid) || !$input->uid || strlen($input->uid) < 16) {
			throw new Exception('입력 키값이 정확하지 않습니다.');
		}
		if(!isset($input->email) || !$input->email) {
			throw new Exception('이메일을 입력하세요.');
		}

		$query = $this->db->query(
			"select *".
			"  from {$this->TBL_MEMBER}".
			" where email = ?",
			array($input->email)
		);
		if($query->num_rows() > 0) throw new Exception('이미존재 하는 회원정보 입니다.');

		$this->db->insert($this->TBL_MEMBER, array(
			'email' => $input->email,
			'uid' => $input->uid,
			'info' => '',
		));

		$this->load->view('data_json', $input);
	}

	public function sign_out() {
		$this->session->unset_userdata($this->SS_MEMBER);
		$this->load->view('data_json');
	}

	// ---------- protected ---------- //
	// ---------- private ---------- //
}
