<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'controllers/data/master/Index.php';

class Survey extends Index {
	private $SID_SURVEY = '__survey__';
	public function __construct() {
		parent::__construct();

		$survey = $this->session->userdata($this->SID_SURVEY);
		$this->site_uid = $this->nvl($survey, 'site_uid');
		$this->tocken = $this->nvl($survey, 'tocken');
	}

	public function selected_domain() {
		$json = $this->json();
		$domain = $this->nvl($json, 'domain');

		if(!$this->site_uid && $domain) {
			$site = $this->mdlTable->row(array(
				'table' => 'bom_site',
				'where' => array(
					'domain' => $domain,
				),
			));
			if(!$site) throw new Exception('도메인이 존재하지 않습니다.');
	
			$this->site_uid = $this->nvl($site, 'uid');
			$this->_set_servey();
		} else {
			$site = $this->mdlTable->row(array(
				'table' => 'bom_site',
				'where' => array(
					'uid' => $this->site_uid
				)
			));
			$domain = $this->nvl($site, 'domain');
		}

		$this->json(array(
			'domain' => $domain,
		));
	}

	// ----- 리스트 조회 ----- //
	public function list() {
		if(!$this->site_uid) throw new Exception('잘못된 접근정보 입니다.('.__LINE__.')');

		$json = $this->json();
		$keyword = $this->db->escape_like_str($this->nvl($json, 'keyword'));
		$next = $this->nvl($json, 'next', 0);
		$limit = 10;
		$pos = intval($next) * $limit;

		$sql = array(
			'select' => array('uid', 'open', 'd_end', 'data'),
			'table' => 'survey_req',
			'where' => array(
				'site_uid' => $this->site_uid,
				'uid like' => '%'.$keyword.'%',
			),
			'orderby' => 'd_end',
			'limit' => $limit,
			'offset' => $pos,
		);
		$this->json(array(
			'next' => $next + 1,
			'tot' => ceil($this->mdlTable->count($sql) / $limit),
			'list' => $this->mdlTable->list($sql),
		));
	}
	// ----- 등록 ----- //
	public function regist($tid = null) {
		$json = $this->json();
		if(!$this->site_uid) throw new Exception('잘못된 접근정보 입니다.('.__LINE__.')');
		if(!$json) return $this->json(array(
			'tid' => $this->_set_servey(),
		));

		if($this->tocken != $tid) throw new Exception('잘못된 접근정보 입니다.('.__LINE__.')');
		$uid = $this->nvl($json, 'uid');
		if(!$uid) throw new Exception('폼 아이디를 입력하지 않았습니다.');
		$data = $this->nvl($json, 'data');
		if(!$data) throw new Exception('폼 데이터가 존재 하지 않습니다.');
		$open = $this->nvl($json, 'open');
		$d_end = $this->nvl($json, 'd_end');

		$survey = $this->mdlTable->row(array(
			'table' => 'survey_req',
			'where' => array(
				'site_uid' => $this->site_uid,
				'uid' => $uid,
			),
		));
		if($survey) throw new Exception('등록된 설문 아이디 입니다.');

		$this->mdlTable->insert(array(
			'table' => 'survey_req',
			'data' => array(
				'site_uid' => $this->site_uid,
				'uid' => $uid,
				'open' => $open,
				'd_end' => $d_end,
				'data' => $data,
			),
		));

		// 응답 테이블 생성
		$this->_make_res();

		$this->json(array());
	}

	// ----- 수정 ----- //
	public function modify($tid = null) {
		$json = $this->json();
		if(!$this->site_uid) throw new Exception('잘못된 접근정보 입니다.('.__LINE__.')');
		if(!$json) return $this->json(array(
			'tid' => $this->_set_servey(),
		));

		if($this->tocken != $tid) throw new Exception('잘못된 접근정보 입니다.('.__LINE__.')');
		$uid = $this->nvl($json, 'uid');
		if(!$uid) throw new Exception('폼 아이디를 입력하지 않았습니다.');
		$data = $this->nvl($json, 'data');
		if(!$data) throw new Exception('폼 데이터가 존재 하지 않습니다.');
		$open = $this->nvl($json, 'open');
		$d_end = $this->nvl($json, 'd_end');

		$this->mdlTable->update(array(
			'table' => 'survey_req',
			'set' => array(
				'open' => $open,
				'd_end' => $d_end,
				'data' => $data,
			),
			'where' => array(
				'site_uid' => $this->site_uid,
				'uid' => $uid,
			),
		));
		$this->json(array());
	}
	// ----- 삭제 ----- //
	public function delete($tid = null) {
		$json = $this->json();
		if(!$this->site_uid) throw new Exception('잘못된 접근정보 입니다.('.__LINE__.')');
		if(!$json) return $this->json(array(
			'tid' => $this->_set_servey(),
		));

		if($this->tocken != $tid) throw new Exception('잘못된 접근정보 입니다.('.__LINE__.')');
		$uid = $this->nvl($json, 'uid');
		if(!$uid) throw new Exception('폼 아이디를 입력하지 않았습니다.');

		$this->mdlTable->delete(array(
			'table' => 'survey_req',
			'where' => array(
				'site_uid' => $this->site_uid,
				'uid' => $uid,
			),
		));
		$this->json(array());
	}

	// ---------- private ---------- //
	private function _set_servey() {
		$tocken = now();
		$this->session->set_userdata($this->SID_SURVEY, array(
			'site_uid' => $this->site_uid,
			'tocken' => $tocken,
		));

		return $tocken;
	}
	private function _make_res() {
		$this->dbforge->add_field(array(
			'uid' => array(
				'type' => 'INT',
				'unsigned' => true,
				'auto_increment' => true,
				'null' => false,
			),
			'req_uid' => array(
				'type' => 'VARCHAR',
				'constraint' => 20,
				'null' => false,
			),
			'member_uid' => array(
				'type' => 'CHAR',
				'constraint' => 16,
				'null' => false,
			),
			'd_res' => array(
				'type' => 'DATE',
			),
			'data' => array(
				'type' => 'MEDIUMTEXT',
			),
		));
		$this->dbforge->add_key('uid', true);
		$this->dbforge->create_table('survey_res'.$this->site_uid, true);
	}
}
