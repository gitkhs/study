<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'controllers/data/master/Index.php';

class Domain extends Index {
	public function __construct() {
		parent::__construct();
		$this->log_date = mdate('%Y-%m-%d');
	}

	// ----- 추가 ----- //
	public function regist() {
		$json = $this->json();
		$domain = $this->nvl($json, 'domain');
		if(!$domain) throw new Exception('도메인을 입력하지 않았습니다.');
		$admin = $this->nvl($json, 'admin');
		if(!$admin) throw new Exception('관리자를 입력하지 않았습니다.');
		$d_end = $this->nvl($json, 'd_end');
		if(!$d_end) throw new Exception('만료일을 입력하지 않았습니다.');
		$manager = $this->nvl($json, 'manager');
		$info = $this->nvl($json, 'info');

		$is_domain = $this->mdlTable->row(array(
			'table' => 'bom_site',
			'where' => array(
				'domain' => $domain,
			),
		));
		if($is_domain) throw new Exception('등록된 도메인 입니다.');

		$is_admin = $this->mdlTable->row(array(
			'table' => 'bom_member',
			'where' => array(
				'email' => $admin
			),
		));
		if(!$is_admin) throw new Exception('미등록 회원입니다.(관리자)');
		if($manager) {
			$arr_manager = explode(',', $manager);
			$query = $this->db->query(
				"select *".
				"  from bom_member".
				" where email in ?",
				array($arr_manager)
			);
			if($query->num_rows() < count($arr_manager))
				throw new Exception('미등록 회원이 존재합니다.(매니저)');
		}

		// -- insert --
		$this->mdlTable->insert(array(
			'table' => 'bom_site',
			'data' => array(
				'domain' => $domain,
				'admin' => $admin,
				'manager' => $manager,
				'd_end' => $d_end,
				'info' => $info,
				'log' => json_encode(array($this->log_date.": 신규 등록({$d_end})")),
			),
		));
		$this->json(array());
	}

	// ----- 조회 ----- //
	public function search() {
		$json = $this->json();
		$keyword = $this->db->escape_like_str($this->nvl($json, 'keyword'));
		$is_end = $this->nvl($json, 'is_end', 0);
		$next = $this->nvl($json, 'next', 0);
		$limit = 10;
		$pos = intval($next) * $limit;

		$sql = array(
			'select' => array('uid', 'domain', 'admin', 'manager', 'd_end', 'info'),
			'table' => 'bom_site',
			'where' => array(
				'domain like' => '%'.$keyword.'%',
			),
			'orderby' => 'd_end'.($is_end == 1 ? '' : ' desc'),
			'limit' => $limit,
			'offset' => $pos,
		);
		if($is_end == 1) $sql['where']['d_end >='] = mdate('%Y%m%d');
		else if($is_end == 2) $sql['where']['d_end <'] = mdate('%Y%m%d');

		$this->json(array(
			'next' => $next + 1,
			'tot' => ceil($this->mdlTable->count($sql) / $limit),
			'list' => $this->mdlTable->list($sql),
		));
	}

	// ----- 상세내용 ----- //
	public function detail() {
		$json = $this->json();
		$uid = $this->nvl($json, 'uid');
		if(!$uid) throw new Exception('잘못된 접근 정보입니다.');

		$domain = $this->mdlTable->row(array(
			'table' => 'bom_site',
			'where' => array(
				'uid' => $uid,
			),
		));

		$this->json(array(
			'log' => json_decode($domain['log']),
		));
	}

	// ----- 수정 ----- //
	public function modify() {
		$json = $this->json();
		$uid = $this->nvl($json, 'uid');
		if(!$uid) throw new Exception('잘못된 접근 정보입니다.');
		$key = $this->nvl($json, 'key');
		if(!$key) throw new Exception('수정 항목키 오류입니다.');
		$value = $this->nvl($json, 'value');

		$domain = $this->mdlTable->row(array(
			'table' => 'bom_site',
			'where' => array(
				'uid' => $uid,
			),
		));
		if(!$domain) throw new Exception('존재하지 않는 도메인 입니다.');

		$log = $domain['log'] ? json_decode($domain['log']) : array();
		if(in_array($key, array('admin', 'd_end'))) {
			array_unshift($log, array(
				'admin' => $this->log_date.': 관리자 변경('.$value.')',
				'd_end' => $this->log_date.': 종료일 변경('.$value.')',
			)[$key]);
		}

		$this->mdlTable->update(array(
			'table' => 'bom_site',
			'set' => array(
				$key => $value,
				'log' => json_encode($log),
			),
			'where' => array(
				'uid' => $uid,
			)
		));

		$this->json(array(
			$key => $value,
			'log' => $log,
		));
	}

}
