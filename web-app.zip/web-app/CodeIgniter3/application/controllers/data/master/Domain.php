<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'controllers/data/master/Master.php';

class Domain extends Master {
	public function __construct($level = null) {
		parent::__construct();
	}

	public function regist() {
		$input = $this->post_json();
		if(!isset($input->domain) || !$input->domain)
			throw new Exception('도메인명을 입력 하세요.');
		if(!isset($input->admin) || !$input->admin)
			throw new Exception('관리자를 입력 하세요.');
		if(!isset($input->d_end) || !$input->d_end)
			throw new Exception('만료일을 입력 하세요.');

		$query = $this->db->query(
			"select *".
			"  from {$this->TBL_SITE}".
			" where domain = ?",
			array($input->domain)
		);
		if($query->num_rows())
			throw new Exception('등록된 도메인 입니다.');

		$query = $this->db->query(
			"select *".
			"  from {$this->TBL_MEMBER}".
			" where email = ?",
			array($input->admin)
		);
		if($query->num_rows() < 0)
			throw new Exception('미등록 회원입니다.(관리자)');

		if($input->manager) {
			$manager = explode(',', $input->manager);
			$query = $this->db->query(
				"select *".
				"  from {$this->TBL_MEMBER}".
				" where email in ?",
				array($manager)
			);
			if($query->num_rows() != count($manager))
				throw new Exception('미등록 회원이 존재합니다.(매니저)');
		}

		$log = array($this->today.": 신규 등록({$input->d_end})");
		$this->db->insert($this->TBL_SITE, array(
			'domain' => $input->domain,
			'admin' => $input->admin,
			'manager' => $input->manager,
			'd_end' => $input->d_end,
			'info' => $input->info,
			'log' => json_encode(array($this->today.": 신규 등록({$input->d_end})")),
		));
		$this->load->view('data_json');
	}

	public function search($next = 0) {
		$limit = 10;
		$pos = intval($next) * $limit;

		$input = $this->post_json();
		$keyword = $this->nvl(isset($input->keyword) ? $input->keyword : null);
		$is_end = $this->nvl(isset($input->is_end) ? $input->is_end : null, 0);

		$sql = "  from {$this->TBL_SITE}".
			" where domain like '%{$this->db->escape_like_str($keyword)}%'".
			array(
				"",
				"   and d_end >= date_format(now(), '%Y%m%d')",
				"   and d_end < date_format(now(), '%Y%m%d')",
			)[$is_end];

		$query = $this->db->query("select count(*) cnt".$sql);
		$total = ceil($query->unbuffered_row()->cnt / $limit);
	
		$query = $this->db->query(
			"select uid".
			"     , domain".
			"     , admin".
			"     , manager".
			"     , d_end".
			"     , info".
			$sql.
			" order by d_end ".($is_end == 1 ? "" : "desc").
			" limit {$pos}, {$limit}"
		);

		$result = array();
		if($query->num_rows()) {
			$result['tot'] = $total;
			$result['next'] = $next + 1;
			$result['list'] = $query->result_array();
		}

		$this->load->view('data_json', $result);
	}

	public function detail($uid = 0) {
		if(!$uid) throw new Exception('조회키 오류입니다.');

		$query = $this->db->query(
			"select *".
			"  from {$this->TBL_SITE}".
			" where uid = ?",
			array($uid)
		);
		if($query->num_rows() < 1)
			throw new Exception('조회 데이터가 존재하지 않습니다.');

		$site = $query->first_row('array');
		$this->load->view('data_json', array(
			'log' => json_decode($site['log']),
		));
	}

	public function modify($uid = null) {
		if(!$uid) throw new Exception('도메인 키 오류입니다.');

		$input = $this->post_json();
		if(!isset($input->key) || !$input->key)
			throw new Exception('수정 항목키 오류입니다.');
		if(!isset($input->value) || !$input->value)
			throw new Exception('수정 입력값 오류입니다.');

		$query = $this->db->query(
			"select log".
			"  from {$this->TBL_SITE}".
			" where uid = ?",
			array($uid)
		);
		$row = $query->first_row('array');
		$log = $row['log'] ? json_decode($row['log']) : array();

		if(in_array($input->key, array('admin', 'd_end'))) {
			array_unshift($log, $this->today.array(
				'admin' => ": 관리자 변경({$input->value})",
				'd_end' => ": 만료일 변경({$input->value})",
			)[$input->key]);
		}

		$query = $this->db->query(
			"update {$this->TBL_SITE}".
			"   set {$input->key} = ?".
			"     , log = ?".
			" where uid = ?",
			array($input->value, json_encode($log), $uid)
		);

		$this->load->view('data_json', array(
			$input->key => $input->value,
			'log' => $log
		));
	}
	// ---------- protected ---------- //
	// ---------- private ---------- //
}
