<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'controllers/Data_Controller.php';

class Index extends Data_Controller {
	protected $domain, $member;
	public function __construct($vl = null) {
		parent::__construct();

		// 승인 도메인 체크
		$domain = preg_replace('/^www\./', '', $_SERVER['SERVER_NAME']);

		$this->domain = $this->mdlSession->getDomain();
		if(!$this->domain) {
			$this->domain = $this->mdlTable->row(array(
				'table' => $this->mdlTable->domain,
				'select' => array(
					'uid',
					'domain',
					'admin',
					'manager',
					"date_format(d_end, '%Y%m%d') d_end",
				),
				'where' => array(
					'domain' => $domain
				),
			));
		}

		if(!$this->domain) throw new Exception('승인되지 않은 도메인 입니다.');
		$d_end = str_replace('-', '', $this->nvl($this->domain, 'd_end'));
		if($this->today > $d_end)
			throw new Exception('사용기간이 만료된 도메인 입니다.');

		if($this->domain) {
			$this->mdlSession->setDomain($this->domain);
		}

		// 승인 사용자 체크
		$skip = $this->nvl($vl, 'skip');
		if($skip) return;

		$this->member = $this->mdlSession->getMember();
		if(!$this->member) throw new Exception('로그인 후 이용하세요.');
	}

	// debugging
	// ==============================//
	public function debug($ky = 'session') {
		$data = array(
			'header' => apache_request_headers(),
			'session' => $this->session->userdata(),
		);

		$vl = $this->nvl($data, $ky);
		$this->json($vl);
	}

	public function trace() {
		$json = $this->json();
		$date = $this->nvl($json, 'date');
		$date = $date ? $date : mdate('%Y%m%d%H%i%s', strtotime('-1 hours'));
		$query = $this->db->query(
			"select * ".
			"  from ci_log".
			" where date > '{$date}'".
			" order by date desc".
			" limit 0, 100"
		);
		$this->json($query->result());
	}
}
