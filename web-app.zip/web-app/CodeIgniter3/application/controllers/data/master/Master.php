<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'controllers/data/Member.php';

class Master extends Member {
	protected $SS_MASTER = '__auth_master__';

	public function __construct($admin = null) {
		parent::__construct(true);

		// if($this->isAdmin()) return;
		// if($this->isManager()) return;
		// throw new Exception('승인되지 않은 사용자 입니다.');
	}
	// method: protected
	protected function isAdmin() {
		return $this->ssMember['email'] === $this->ssSite['admin'];
	}
	protected function isManager() {
		if(!$this->ssSite['manager']) return false;

		$manager = explode(',', $this->ssSite['manager']);
		return in_array($this->ssMember['email'], $manager);
	}
}
