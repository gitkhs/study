<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'controllers/data/master/Index.php';

class Finder extends Index {
	public function __construct() {
		parent::__construct();
	}

	public function domain() {
		$json = $this->json();
		$domain = urldecode($this->nvl($json, 'keyword'));
		if(!$domain) throw new Exception('도메인을 입력하세요.');
		$domain = "%{$this->db->escape_like_str($domain)}%";

		$this->json($this->mdlTable->list(array(
			'select' => array(
				'domain value',
			),
			'table' => 'bom_site',
			'where' => array(
				'domain like' => $domain,
			),
			'orderby' => 'domain desc',
			'limit' => 5,
		)));
	}

	public function member() {
		$json = $this->json();
		$email = urldecode($this->nvl($json, 'keyword'));
		if(!$email) throw new Exception('이메일을 입력하세요.');
		$email = "%{$this->db->escape_like_str($email)}%";

		$this->json($this->mdlTable->list(array(
			'select' => array(
				'email value',
			),
			'table' => 'bom_member',
			'where' => array(
				'email like' => $email,
			),
			'orderby' => 'email desc',
			'limit' => 5,
		)));
	}
}
