<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'controllers/data/master/Index.php';

class Member extends Index {
	public function __construct($level = null) {
		parent::__construct(array(
			'skip' => true,
		));
	}

	public function stat() {
		$member = $this->mdlSession->getMember();
		$this->json(array(
			'sign' => !!$this->nvl($member, 'email'),
		));
	}

	public function sign_up() {
		$json = $this->json();

		// $this->mdlLog->log('test');

		// $uid = $this->std->nvl($json, 'uid');
		// if(!$uid) throw new Exception('승인값이 입력되지 않았습니다.');
		// if(strlen($uid) < 16) throw new Exception('잘못된 승인값 입니다.');
		// $email = $this->std->nvl($json, 'email');
		// if(!$email) throw new Exception('이메일이 입력되지 않았습니다.');

		// $member = $this->tblBomMember->selectRow(array('uid' => $uid));
		// if($member) throw new Exception('이미존재 하는 회원정보 입니다.');

		// $this->tblBomMember->insert(array(
		// 	'uid' => $uid,
		// 	'email' => $email,
		// 	'info' => ''
		// ));
		// $this->json(array());
	}

	public function sign_in() {
		$json = $this->json();
		if(preg_match('/^localhost/', $_SERVER['SERVER_NAME'])) {
			$json['uid'] = 'xxx1544505454444';
			$json['email'] = 'a12@test.com';
		}

		$uid = $this->nvl($json, 'uid');
		if(!$uid) throw new Exception('승인값이 입력되지 않았습니다.');

		$member = $this->mdlTable->row(array(
			'table' => $this->mdlTable->member,
			'where' => array(
				'uid' => $uid
			),
		));
		if(!$member)  throw new Exception('회원 정보가 존재 하지 않습니다.');

		$this->log('login email: '.$member['email']);
		$this->mdlSession->setMember($member);
		$this->json(array());
	}

	public function sign_out() {
		$this->mdlSession->clear();
		$this->json(array());
	}
}
