<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$this->load->helper('date');
$date_today = mdate('%Y%m%d');
?><!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>master</title>

	<link href="/web-app/libs/bootstrap4/bootstrap.min.css" rel="stylesheet">
	<script src="/web-app/libs/makeapp/make-app.2.1.js?v=<?=$date_today?>"></script>
	<script src="/web-app/libs/makeapp/make-service-http.js?v=<?=$date_today?>"></script>
	<script src="/web-app/views/master/init-config.js?v=<?=$date_today?>"></script>
	<script src="/web-app/views/master/init-gnb.js?v=<?=$date_today?>"></script>
	<script src="/web-app/views/master/init-popup.js?v=<?=$date_today?>"></script>
	<script src="/web-app/views/master/<?=$method?>/main.js?v=<?=$date_today?>"></script>
</head>
<body class="bg-light">
	<!-- navi-head -->
	<nav data-app-view="navi-head" class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark">
		<a class="navbar-brand mr-auto mr-lg-0" href="#">Offcanvas navbar</a>
		<button data-bind="event:on.menu" class="navbar-toggler p-0 border-0" type="button">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div data-bind="css:vo.menu" class="navbar-collapse offcanvas-collapse">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item text-right mt-1">
					<button data-bind="event:on.signout" class="btn btn-sm btn-outline-secondary">sign out</button>
				</li>
				<li class="nav-item">
					<span>text....</span>
					<a class="nav-link">Dashboard</a>
				</li>
			</ul>
		</div>
		<button data-bind="event:on.signout" class="btn btn-sm btn-outline-secondary d-none d-sm-block">sign out</button>
	</nav>
	<!-- /navi-head -->
	<div class="container-fluid">
		<div class="row">
			<!-- navi-side -->
			<nav data-app-view="navi-side" class="col-md-2 d-none d-md-block bg-dark sidebar">
				<div class="sidebar-sticky navbar-dark">
					<ul class="navbar-nav flex-column">
						<li class="nav-item">
							<span>text....</span>
							<a class="nav-link" href="#">Dashboard</a>
						</li>
					</ul>
				</div>
			</nav>
			<!-- /navi-side -->

			<main data-app-view="main" role="main" class="col-md-9 ml-sm-auto col-lg-10 p-3" style="min-height:70vh;"></main>
		</div>
	</div>

	<!-- page-loader -->
	<div data-app-view="page-loader" class="bg-light fixed-top">
		<!-- ko if:vo.wait -->
		<div class="container mt-3" style="height:100vh;">
			<div class="row">
				<div class="col">please wait...</div>
			</div>
		</div>
		<!-- /ko -->
		<!-- ko ifnot:vo.wait -->
		<div class="d-flex align-items-center" style="height:100vh;">
			<div class="container" style="max-width:350px;">
				<div class="col">
					<h2 class="h3 mb-3 font-weight-normal">sign in</h2>
				</div>
				<div class="col mt-2">
					<button data-bind="event:on.google" class="btn btn-outline-primary btn-block">google</button>
				</div>
				<div class="col mt-2">
						<button data-bind="event:on.facebook" class="btn btn-outline-primary btn-block">facebook</button>
				</div>
				<div class="col mt-4">
					<input data-bind="value:vo.email, validation:on.email" type="email" class="form-control" placeholder="email">
					<div class="invalid-feedback">please provide a valid email</div>
				</div>
				<div class="col mt-2">
					<input data-bind="value:vo.passwd, event:on.passwd, validation:on.passwd" type="password" class="form-control" placeholder="password">
					<div class="invalid-feedback">please provide a valid password</div>
				</div>
				<div class="col mt-2">
					<button data-bind="event:on.signin" class="btn btn-block btn-outline-primary">sign in</button>
				</div>
				<div class="col mt-4 text-right">
					<button data-bind="event:on.reset" class="btn btn-outline-secondary">reset password</button>
					<a href="/sign-up" class="btn btn-outline-info">join</a>
				</div>
			</div>
		</div>
		<!-- /ko -->
	</div>
	<!-- /page-loader -->
</body>
</html>