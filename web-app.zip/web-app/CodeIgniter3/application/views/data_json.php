<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$hd = apache_request_headers();
if(isset($hd['Origin'])) {
	header('Access-Control-Allow-Origin: '.$hd['Origin']);
	header('Access-Control-Allow-Credentials: true');
}
header('Content-Type: application/json; charset=utf-8');

echo json_encode($this->_ci_cached_vars);
?>

