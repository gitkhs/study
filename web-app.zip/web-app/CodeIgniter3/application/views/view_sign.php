<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$this->load->helper('date');
$date_today = mdate('%Y%m%d');
?><!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>회원가입</title>

	<link href="/web-app/libs/bootstrap4/bootstrap.min.css" rel="stylesheet">

	<script src="/web-app/libs/makeapp/make-app.2.1.js?v=<?=$date_today?>"></script>
	<script src="/web-app/libs/makeapp/make-service-http.js?v=<?=$date_today?>"></script>
	<script src="/web-app/libs/makeapp/initialize.js?v=<?=$date_today?>"></script>
	<style>
	html, body { height: 100%; }
	body {
		display: -ms-flexbox;
		display: -webkit-box;
		display: flex;
		-ms-flex-align: center;
		-ms-flex-pack: center;
		-webkit-box-align: center;
		align-items: center;
		-webkit-box-pack: center;
		justify-content: center;
		padding-top: 40px;
		padding-bottom:40px; background-color:#f5f5f5;
	}
	.form-signin {
		width: 100%;
		max-width: 330px;
		padding: 15px;
		margin: 0 auto;
	}
	</style>
</head>

<body class="bg-light">
<div data-app-view="main" class="form-signin">
<?php if($step == 'begin') : ?>
	<div class="col"><h1 class="h3 mb-3 font-weight-normal">통합인증 관리</h1></div>
	<div class="col mt-2">
		<label for="inputEmail" class="sr-only">이메일</label>
		<input data-bind="value:vo.email, event:on.email, validation:on.email" type="email" id="inputEmail" class="form-control" placeholder="이메일" required>
		<div class="invalid-feedback">이메일을 입력하세요.</div>
	</div>
	<div class="col mt-3">
		<label for="inputPassword" class="sr-only">패스워드</label>
		<input data-bind="value:vo.passwd, event:on.passwd, validation:on.passwd" type="password" id="inputPassword" class="form-control" placeholder="패스워드" required>
		<div class="invalid-feedback">패스워드를 입력하세요.</div>
	</div>
	<div class="col mt-3">
		<button data-bind="event:on.create, attr:vo.create" class="btn btn-lg btn-outline-primary btn-block" type="button" disabled>계정 생성</button>
	</div>
	<div class="col mt-3">
		<button data-bind="event:on.google" class="btn btn-lg btn-primary btn-block" type="button">구글 인증</button>
	</div>
	<div class="col mt-3">
		<button data-bind="event:on.facebook" class="btn btn-lg btn-primary btn-block" type="button">페이스북 인증</button>
	</div>
<?php elseif($step == 'final') : ?>
	<div class="jumbotron">
		<div class="container">
			<h2 class="display-4">승인완료</h2>
			<p class="lead">계정생성 및 인증이 완료 되었습니다.</p>

		<?php if($referer) : ?>
			<p class="lead"><a href="<?=$referer?>" class="btn btn-primary btn-lg" role="button">이전 페이지 &raquo;</a></p>
		<?php endif ?>
		</div>
	</div>
<?php endif ?>
</div>

<script>
!function(http) {
mkApp.view('main', function(ctrl) {
	ctrl.oncreate = function() {
		ctrl.bind();
	};
	ctrl.onload = function() {
	};
	ctrl.vo = function(vo) {
		vo.email = ctrl.observer('');
		vo.passwd = ctrl.observer('');
		vo.create = ctrl.observer({});
	};
	ctrl.on = function(on) {
		// email
		on.email = ctrl.event();
		on.email.keyup = function(ob, ev) {
			ctrl.vo.create({
				disabled: !ctrl.vo.passwd() || !ev.target.value
			});
		};
		on.email.feedback = function(vl) {
			if(!vl) return '이메일을 입력하세요.';
			if(!/^[a-zA-Z](\w)*@(\S)+.[a-zA-Z]$/.test(vl))
				return '이메일 형식이 아닙니다.';
		};

		// password
		on.passwd = ctrl.event();
		on.passwd.keyup = function(ob, ev) {
			ctrl.vo.create({
				disabled: !ctrl.vo.email() || !ev.target.value
			});
			ev.keyCode === 13 && on.signin.click(ob, ev);
		};
		on.passwd.feedback = function(vl) {
			if(!vl || vl.length < 12)
				return '패스워드를 12자리 이상 입력하세요.';
		};

		// create
		on.create = ctrl.event();
		on.create.click = function() {
			if(!on.email.validation()) return;
			if(!on.passwd.validation()) return;

			http.post('/data/member/sign-up', {
				uid: 'xxx' + Date.now(),
				email: ctrl.vo.email()
			}).then(function() {
				location.href = '/sign-up/final';
			});
		};

		// google
		on.google = ctrl.event();
		on.google.click = function() {
			// location.href = '/biz/sign-up/final';
		};

		// facebook
		on.facebook = ctrl.event();
		on.facebook.click = function() {
			alert('facebook');
		};

	};
});
}(
	mkApp.service('http')
);
</script>
</body>
</html>