<?php
$is_data = preg_match('/^\/data\//', $_SERVER['REQUEST_URI']);
$is_local = $_SERVER['SERVER_NAME'] == 'localhost.bombombom.kr';

if($is_data) {
	$hd = apache_request_headers();
	if(isset($hd['Origin'])) {
		header('Access-Control-Allow-Origin: '.$hd['Origin']);
		header('Access-Control-Allow-Credentials: true');
	}
	header('Content-Type: application/json; charset=utf-8');
}
?>