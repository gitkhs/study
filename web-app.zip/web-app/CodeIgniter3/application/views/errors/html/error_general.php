<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once 'header.php';

if($is_local) {
	echo json_encode(array(
		'error' => 'general error',
		'heading' => $heading,
		'message' => $message,
	));
} else {
	echo json_encode(array(
		'error' => 'general error',
		'message' => 'general error',
	));
}
?>