<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once 'header.php';

if($is_local) {
	echo json_encode(array(
		'error' => 'exception',
		'code' => $exception->getCode(),
		'message' => $exception->getMessage(),
		'file' => $exception->getFile(),
		'line' => $exception->getLine(),
		// 'trace' => $exception->getTrace(),
	));
} else {
	echo json_encode(array(
		'error' => 'exception',
		'message' => $exception->getMessage(),
	));
}
?>
