<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once 'header.php';

$result = array();
$result['error'] = 'exception';
$result['message'] = $exception->getMessage();

if($is_local) {
	$result['code'] = $exception->getCode();
	$result['file'] = $exception->getFile();
	$result['line'] = $exception->getLine();
	// 'trace' => $exception->getTrace(),
}

if($is_data) {
	echo json_encode($result);
	return;
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>exception error</title>
</head>
<body>
	<div style="padding:20px;">
		<p>처리중...</p>
		<p><?= $result['message']?></p>
	</div>
	<div style="display:none;">Error: Exception</div>
</body>
</html>

