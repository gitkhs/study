<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$is_data = preg_match('/^\/data\//', $_SERVER['REQUEST_URI']);
$is_local = $_SERVER['SERVER_NAME'] == 'localhost.bombombom.kr';

if($is_data && $is_local):
	echo '<strong>database error</strong><div style="margin-top:16px;">'.$message.'</div>';
else:
?>
<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>db error</title>
</head>
<body>
	<div style="padding:20px;">
		<strong>홈페이지 이용에 불편을 드려 죄송합니다.</strong>
		<p>요청하신 페이지는 일시적인 장애로 인해 이용이 어렵습니다.(database)</p>
	</div>
</body>
</html>
<?php endif;?>
