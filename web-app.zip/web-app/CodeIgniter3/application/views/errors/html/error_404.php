<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once 'header.php';

if($is_data) {
	echo json_encode(array(
		'error' => 404,
		'message' => 'Not Found',
	));
	return;
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>db error</title>
</head>
<body>
	<div style="padding:20px;">
		<h1>404 not found</h1>
		<p>페이지를 찾을수 없습니다.</p>
	</div>
</body>
</html>
