<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once 'header.php';

if($is_data) {
	echo json_encode(array(
		'error' => 404,
		'message' => 'Not Found',
	));
} else {
	echo '<h2>404 not found</h1>';
}
?>
