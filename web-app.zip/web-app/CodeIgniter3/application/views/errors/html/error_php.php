<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$is_data = preg_match('/^\/data\//', $_SERVER['REQUEST_URI']);
$is_local = $_SERVER['SERVER_NAME'] == 'localhost.bombombom.kr';

if($is_data && $is_local):
	$result = array('error');
	// echo '<strong>error</strong>';
	if (defined('SHOW_DEBUG_BACKTRACE') && SHOW_DEBUG_BACKTRACE === TRUE):
		foreach (debug_backtrace() as $error):
			if (isset($error['file']) && strpos($error['file'], realpath(BASEPATH)) !== 0):
				array_push($result, array(
					'file' => $error['file'],
					'line' => $error['line'],
					'function' => $error['function'],
				));
				// echo '<div style="margin-top:16px;">'.
				// 'file: '.$error['file'].'</br>'.
				// 'line: '.$error['line'].'</br>'.
				// 'function: '.$error['function'].
				// '</div>';
			endif;
		endforeach;
	endif;
else:
?>
<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>error</title>
</head>
<body>
	<div style="padding:20px;">
		<strong>홈페이지 이용에 불편을 드려 죄송합니다.</strong>
		<p>요청하신 페이지는 일시적인 장애로 인해 이용이 어렵습니다.</p>
	</div>
</body>
</html>
<?php endif;?>
