!function(debug, http) {


var selector = '[data-type-button=test]';
var button = document.querySelector(selector);
var attchButton = function(el) {
	el = (el instanceof Event) ? document.querySelector(selector) : el;
	el.addEventListener('click', function() {
		var writeSurvey = mkApp.popup('writeSurvey');
		if(el.dataset.template) writeSurvey.template = el.dataset.template;
		else writeSurvey.html = [
			'<div data-app-modal-layout>',
				'<div data-app-modal-body>',
					'<!-- ko foreach: {data:vo.list, as:\'item\'} -->',
					'<div style="padding:8px">',
						'<div><span data-bind="text: item.title">설문 제목</span> <small data-bind="if: item.fixed">(필수입력)</small></div>',
						'<!-- ko if: item.kind() == \'1\' -->',
						'<textarea data-bind="value: item.res, attr: {placeholder: \'내용을 \'+item.max()+\'자내로 입력해주세요.\', maxlength: item.max}" style="width:100%;" rows="3"></textarea>',
						'<!-- /ko -->',

						'<!-- ko if: item.kind() == \'2\' -->',
							'<!-- ko foreach: item.option -->',
							'<div data-bind="if: $data">',
							'<label><input data-bind="checked:item.res, attr:{value: $data, name: item.frm_name}" type="radio"> <span data-bind="text: $data">단건선택</span></label>',
							'</div>',
							'<!-- /ko -->',
						'<!-- /ko -->',

						'<!-- ko if: item.kind() == \'3\' -->',
							'<!-- ko foreach: item.option -->',
							'<div data-bind="if: $data">',
							'<label><input data-bind="checked:item.res, attr:{value: $data, name: item.frm_name}" type="checkbox"> <span data-bind="text: $data">다건선택</span></label>',
							'</div>',
							'<!-- /ko -->',
						'<!-- /ko -->',
					'</div>',
					'<!-- /ko -->',
				'</div>',
				'<div data-app-modal-footer style="text-align:right;">',
					'<button data-bind="click: on.submit, focus:\'return\'" style="margin-right:6px;">확인</button>',
					'<button data-bind="click: on.cancel">취소</button>',
				'</div>',
			'</div>'
		];

		writeSurvey.modal();
	});
};

button ? attchButton(button) : document.addEventListener('DOMContentLoaded', attchButton);
mkApp.popup('writeSurvey', function(ctrl) {
	ctrl.create(function() {
	}).onload(function() {
		http.get('http://localhost.bombombom.kr:28080/data/open/survey/form/a1')
		.then(function(rt) {
			JSON.parse(rt.data).forEach(function(vl) {
				ctrl.vo.list.push({
					frm_name: '__survey_name__' + ctrl.vo.list().length,
					title: ctrl.observer(vl.title || ''),
					fixed: ctrl.observer(vl.fixed || false),
					kind: ctrl.observer(vl.kind),
					max: ctrl.observer(vl.max),
					option: ctrl.observer(vl.option.split('\n')),
					res: ctrl.observer(vl.kind == '3' ? [] : '')
				});
			});
		})
	}).entity(function(vo) {
		vo.list = ctrl.observer([]);
	}).event(function(on) {
		on.cancel = function() {
			ctrl.close();
		};
		on.submit = function() {
			var res = ctrl.vo.list().reduce(function(rt, vl) {
				if(!rt) return false;
				if(vl.fixed()) {
					if(!vl.res() || (vl.kind() == '3' && !vl.res().length))
						return mkApp.alert(vl.title() + '(은)는 필수 입력입니다.'), false;
				}

				rt.push({title: vl.title(), respons: vl.res()});
				return rt;
			}, []);
			debug.string(ctrl, res);
		};
	});
});


}(
	mkApp.service('debug'),
	mkApp.service('http')
);

