<?php
class MIoFile extends CI_Model {
	public function __construct() {
		parent::__construct();
	}

	public function upload() {
		$con['upload_path'] = $_SERVER['DOCUMENT_ROOT'];
		$con['allowed_types'] = 'gif|jpg|png';
		$con['max_size'] = 1000;
		$con['max_width'] = 1024;
		$con['max_height'] = 768;

		$this->load->library('upload', $con);
		if(!$this->upload->do_upload()) {
			throw new Exception($this->upload->display_errors(), 1);
		}

		$this->ioJson->output($this->upload->data());
	}

	public function download($vl) {
	}
}