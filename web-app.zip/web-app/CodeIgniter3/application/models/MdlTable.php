<?php
class MdlTable extends CI_Model {
	public $TBL_SITE = 'bom_site';
	public $TBL_SURVEY_REQ = 'survey_req';

	public function __construct() {
		parent::__construct();

		$this->load->model('mdlUtil');

		$this->domain = 'bom_site';
		$this->member = 'bom_member';
		$this->survey_req = 'survey_req';
		$this->survey_res = 'survey_res';
	}

	// 테이블 데이터 추가
	public function insert($prm) {
		$table = $this->nvl($prm, 'table');
		if(!$table) throw new Exception('테이블 미입력');
		$data = $this->nvl($prm, 'data');
		if(!$data) throw new Exception('데이타 미입력');

		$this->db->insert($table, $data);
	}

	// 테이블 데이터 업데이트
	public function update($prm) {
		$table = $this->nvl($prm, 'table');
		if(!$table) throw new Exception('테이블 미입력');
		$where = $this->nvl($prm, 'where');
		if(!$where) throw new Exception('조건부 미입력');
		$set = $this->nvl($prm, 'set');
		if(!$set) throw new Exception('데이타 미입력');

		$this->db->where($where);
		$this->db->update($table, $set);
	}

	// 테이블 데이터 삭제
	public function delete($prm) {
		$table = $this->nvl($prm, 'table');
		if(!$table) throw new Exception('테이블 미입력');
		$where = $this->nvl($prm, 'where');
		if(!$where) throw new Exception('조건부 미입력');

		$this->db->delete($table, $where);
	}

	// 테이블 조회 후 row 반환
	public function row($prm) {
		$table = $this->nvl($prm, 'table');
		if(!$table) throw new Exception('테이블 미입력');
		$join = $this->nvl($prm, 'join');
		$where = $this->nvl($prm, 'where');
		$orderby = $this->nvl($prm, 'orderby');
		
		$select = implode(',', $this->nvl($prm, 'select', '*'));
		if($join) $this->db->join($this->nvl($join, 'table'), $this->nvl($join, 'on'));
		if($where) $this->db->where($where);
		if($orderby) $this->db->order_by($orderby);

		return $this->db->select($select)->get($table)
			->first_row('array');
	}

	// 테이블 조회 후 list 반환
	public function list($prm) {
		$table = $this->nvl($prm, 'table');
		if(!$table) throw new Exception('테이블 미입력');
		$join = $this->nvl($prm, 'join');
		$where = $this->nvl($prm, 'where');
		$orderby = $this->nvl($prm, 'orderby');
		$limit = $this->nvl($prm, 'limit', 10);
		$offset = $this->nvl($prm, 'offset', 0);

		$select = $this->nvl($prm, 'select', '*');
		if($join) $this->db->join($this->nvl($join, 'table'), $this->nvl($join, 'on'));
		if($where) $this->db->where($where);
		if($orderby) $this->db->order_by($orderby);

		return $this->db->select($select)->get($table, $limit, $offset)
			->result_array();
	}

	public function count($prm) {
		$table = $this->nvl($prm, 'table');
		if(!$table) throw new Exception('테이블 미입력');
		$join = $this->nvl($prm, 'join');
		$where = $this->nvl($prm, 'where');

		if($join) $this->db->join($this->nvl($join, 'table'), $this->nvl($join, 'on'));
		if($where) $this->db->where($where);
		return $this->db->select('count(*) count')->get($table)
			->first_row()->count;
	}

	// ------------------
	private function nvl($vl, $ky, $df = '') {
		return $this->mdlUtil->nvl($vl, $ky, $df);
	}
}