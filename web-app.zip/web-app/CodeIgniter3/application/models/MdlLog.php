<?php
date_default_timezone_set('Asia/Seoul');

class MdlLog extends CI_Model {
	private $TABLE = 'ci_log';
	public function __construct() {
		parent::__construct();

		$this->load->helper('date');
		$this->load->dbforge();
	}

	public function create() {
		$this->dbforge->add_field(array(
			'date' => array(
				'type' => 'DATETIME',
				'null' => false,
			),
			'log' => array(
				'type' => 'MEDIUMTEXT',
			),
		));
		$this->dbforge->add_key('date', true);
		$this->dbforge->create_table($this->TABLE, true);
	}
	public function log($msg) {
		$query = $this->db->query("show tables like '{$this->TABLE}'");
		if(!$query->num_rows()) return;

		$this->db->delete($this->TABLE, array(
			'date <' => mdate('%Y%m%d%H%i%s', strtotime('-7 days')),
		));
		$this->db->insert($this->TABLE, array(
			'date' => mdate('%Y%m%d%H%i%s'),
			'log' => $msg,
		));
	}
}