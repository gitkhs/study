<?php
class MIoJson extends CI_Model {
	public function __construct() {
		parent::__construct();
		$this->load->model('mAuthManager', 'authManager');
	}

	public function input() {
		return json_decode(urldecode(file_get_contents('php://input')));
	}
	public function output($vl) {
		$this->authManager->checkOrigin();
		echo json_encode($vl);
	}
}

/*
insert into use_domain(
domain_id, domain_name, admin_id, date_start, date_end, date_update
) values (
'http://localhost:28080', '28080', 'localhost', now(), now(), now()
);
*/