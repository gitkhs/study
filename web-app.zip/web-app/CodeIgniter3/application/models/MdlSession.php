<?php
class MdlSession extends CI_Model {
	private $AUTH_DOMAIN = '__auth_domain__';
	private $AUTH_ORIGIN = '__auth_origin__';
	private $AUTH_MEMBER = '__auth_member__';

	public function __construct() {
		parent::__construct();
	}

	public function get($ky) {
		return $this->session->userdata($ky);
	}
	public function set($ky, $vl) {
		$this->session->set_userdata($ky, $vl);
	}
	public function clear() {
		$this->session->sess_destroy();
	}

	// 도메인
	public function getDomain() {
		return $this->session->userdata($this->AUTH_DOMAIN);
	}
	public function setDomain($vl) {
		$this->setDomainSession($this->AUTH_DOMAIN, $vl);
	}
	// 외부 도메인
	public function getOrigin() {
		return $this->session->userdata($this->AUTH_ORIGIN);
	}
	public function setOrigin($vl) {
		$this->setDomainSession($this->AUTH_ORIGIN, $vl);
	}
	// 로그인 사용자
	public function getMember() {
		return $this->session->userdata($this->AUTH_MEMBER);
	}
	public function setMember($vl) {
		$this->session->set_userdata($this->AUTH_MEMBER, array(
			'uid' => $this->nvl($vl, 'uid'),
			'email' => $this->nvl($vl, 'email'),
		));
	}

	private function setDomainSession($ky, $vl) {
		$this->session->set_userdata($ky, array(
			'uid' => $this->nvl($vl, 'uid'),
			'domain' => $this->nvl($vl, 'domain'),
			'admin' => $this->nvl($vl, 'admin'),
			'manager' => $this->nvl($vl, 'manager'),
			'd_end' => str_replace('-', '', $this->nvl($vl, 'd_end')),
		));
	}
	private function nvl($vl, $ky, $df = '') {
		if(!isset($vl[$ky])) return $df;
		if(!$vl[$ky]) return $df;
		return $vl[$ky];
	}

}