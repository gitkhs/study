<?php
class MdlUtil extends CI_Model {
	public function __construct() {
		parent::__construct();
	}

	public function nvl($vl, $ky, $df = '') {
		if(!isset($vl[$ky])) return $df;
		if(!$vl[$ky]) return $df;
		return $vl[$ky];
	}
}