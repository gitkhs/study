<?php
class MAuthManager extends CI_Model {
	public function __construct() {
		parent::__construct();
	}

	public function isLogin() {
		$manager = $this->session->userdata('manager');
		return $manager['login'] ? true : false;
	}
	public function checkLogin() {
		if(!$this->isLogin()) {
			throw new Exception('승인되지 않은 접근경로 입니다. 로그인 후 이용하세요.', 1);
		}
	}
	public function setLogin($isLogin) {
		$this->session->set_userdata('manager', array(
			'login' => $isLogin,
		));
	}
	public function checkOrigin() {
		header('Content-Type: application/json; charset=utf-8');
		$hd = apache_request_headers();
		$origin = $this->useOrigin();

		if($origin) {
			header('Access-Control-Allow-Origin: '.$origin);
			header('Access-Control-Allow-Credentials: true');
		}
	}
	public function useOrigin() {
		$hd = apache_request_headers();
		if(!isset($hd['Origin'])) return;

		$origin = str_replace('www.', '', $hd['Origin']);
		$query = $this->db->query(
			"select domain_id as id from use_domain where domain_id = ? and date_end >= ? limit 0,1",
			array($origin, date('Ymd'))
		);
		if($query->num_rows() > 0) return $hd['Origin'];
	}
}