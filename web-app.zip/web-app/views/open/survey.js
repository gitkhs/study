!function(debug, http) {


mkApp.popup('surveyWrite', function(ctrl) {
	ctrl.create(function() {
		ctrl.template = 'http://localhost.bombombom.kr:28080/open/view/survey/html';
	}).onload(function() {
		http.get('http://localhost.bombombom.kr:28080/open/view/survey/data-read')
		.then(function() {
		});
	}).event(function(on) {
		on.cancel = {
			click: function() {
				ctrl.close();
			}
		};
	});
});
window.surveyWrite = function(el) {
	// console.log(location.hostname, el);
	http.get('http://localhost.bombombom.kr:28080/open/view/survey/data-read');

	// mkApp.popup('surveyWrite')
	// .modal().then(function() {
	// 	el.focus()
	// });
};


}(
	mkApp.service('debug'),
	mkApp.service('http')
);
