!function(debug, http) {


mkApp.view('main', function(ctrl) {
	ctrl.create(function() {
		ctrl.bind();
	}).entity(function(vo) {
		vo.test = ctrl.observer('test');
	})
});
mkApp.popup('surveyWrite', function(ctrl) {
	ctrl.create(function() {
		ctrl.template = 'http://localhost.bombombom.kr:28080/open/view/survey/html';
	}).onload(function() {
		http.get('http://localhost.bombombom.kr:28080/open/view/survey/data-read')
		.then(function() {
		});
	}).event(function(on) {
		on.cancel = {
			click: function() {
				ctrl.close();
			}
		};
	});
});


}(
	mkApp.service('debug'),
	mkApp.service('http')
);
