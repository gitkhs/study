!function(debug, http, util) {


var _tpl = '/web-app/views/master/';
// ===== defPopMemberJoin =====
mkApp.popup('defPopMemberJoin', function(ctrl) {
});

// ===== initPopupMemberSearch =====
mkApp.popup('initPopupMemberSearch', function(ctrl) {
	ctrl.oncreate = function() {
		ctrl.template = _tpl + 'init-popup-member-search.html';
	};

	ctrl.onload = function(prm) {
		if(!prm) return;

		ctrl.vo.email(prm);
		http.loading(http.NONE).post('/data/member/find', {
			email: ctrl.vo.email()
		}).then(function(rs) {
			http.loading(http.HIDE);
			ctrl.vo.list.data(rs);
		});
	};

	ctrl.vo = function(vo) {
		vo.email = ctrl.observer('');
		vo.list = ctrl.observer([], 'list');
	};

	ctrl.on = function(on) {
		var interval = null, keyword = '';

		on.email = ctrl.event();
		on.email.feedback = function(vl) {
			if(!vl) return '이메일을 입력하세요.';
			if(vl.length < 2) return '이메일을 2자이상 입력하세요.';
		};
		on.email.keyup = function(ob, ev) {
			keyword = ev.target.value;
			if(!on.email.validation(keyword)) return;
			if(interval) return;
	
			interval = setInterval(function() {
				if(keyword == ev.target.value) {
					clearInterval(interval);
					interval = null;
				}
	
				http.loading(http.NONE).post('/data/member/find', {
					email: keyword
				}).then(function(rs) {
					ctrl.vo.list.data(rs);
					http.loading(http.HIDE);
				});
			}, 400);
		};
	
		on.close = ctrl.event();
		on.close.click = function(ob, ev) {
			ctrl.close();
		};
	
		on.selected = ctrl.event();
		on.selected.click = function(ob, ev) {
			ctrl.close(ob);
		};
	};
});

// ===== initPopupDatepicker =====
mkApp.popup('initPopupDatepicker', function(ctrl) {
	ctrl.oncreate = function() {
		ctrl.template = _tpl + 'init-popup-datepicker.html';
	};
	ctrl.onload = function(prm) {
		if(typeof prm != 'string') return ctrl.on.today.click();

		prm = prm.replace(/-|\./g, '');
		if(prm.length != 8) return ctrl.on.today.click();

		ctrl.vo.nowYear(parseInt(prm.substr(0,4), 10));
		ctrl.vo.nowMonth(parseInt(prm.substr(4,2), 10));
		ctrl.vo.nowDay(parseInt(prm.substr(6,2), 10));
		makeDate();
	};

	ctrl.vo = function(vo) {
		vo.cssYear = ctrl.observer({});
		vo.cssMonth = ctrl.observer({});
		vo.cssDay = ctrl.observer({});
	
		vo.nowYear = ctrl.observer(0);
		vo.nowMonth = ctrl.observer(0);
		vo.nowDay = ctrl.observer(0);
	
		vo.lstYear = ctrl.observer([], 'year');
		vo.lstMonth = ctrl.observer([], 'month');
		vo.lstDay = ctrl.observer([], 'day');
	};

	ctrl.on = function(on) {
		on.close = ctrl.event();
		on.close.click = function() {
			ctrl.close();
		};
	
		on.year = ctrl.event();
		on.year.click = function(ob, ev) {
			util.isSmall() && showDate(true, false, false);
			document.querySelector('[data-datepicker-now-year=true]').focus();
		};
	
		on.month = ctrl.event();
		on.month.click = function(ob, ev) {
			util.isSmall() && showDate(false, true, false);
			document.querySelector('[data-datepicker-now-month=true]').focus();
		};
	
		on.day = ctrl.event();
		on.day.click = function() {
			util.isSmall() && showDate(false, false, true);
			document.querySelector('[data-datepicker-now-day=true]').focus();
		};
	
		on.today = ctrl.event();
		on.today.click = function(obs, evt) {
			var today = new Date();
			ctrl.vo.nowYear(today.getFullYear());
			ctrl.vo.nowMonth(today.getMonth() + 1);
			ctrl.vo.nowDay(today.getDate());
	
			makeDate();
			evt && document.querySelector('[data-datepicker-today=true]').focus();
		};
	
		on.nextMon = ctrl.event();
		on.nextMon.click = function() {
			var date = new Date(ctrl.vo.nowYear(), ctrl.vo.nowMonth() - 1, 1);
			date.setMonth(date.getMonth() + 1);
	
			ctrl.vo.nowYear(date.getFullYear());
			ctrl.vo.nowMonth(date.getMonth() + 1);
			makeDate();
		};
	
		on.prevMon = ctrl.event();
		on.prevMon.click = function() {
			var date = new Date(ctrl.vo.nowYear(), ctrl.vo.nowMonth() - 1, 1);
			date.setMonth(date.getMonth() - 1);
	
			ctrl.vo.nowYear(date.getFullYear());
			ctrl.vo.nowMonth(date.getMonth() + 1);
			makeDate();
		};
	
		on.colYear = ctrl.event();
		on.colYear.click = function(ob, ev) {
			ctrl.vo.nowYear(ob.y);
			ctrl.vo.lstYear.data().forEach(function(vl) {
				ctrl.vo.lstYear.data.replace(vl, {
					y: vl.y,
					css: {'badge-primary': vl.y == ob.y}
				});
			});
	
			makeDate();
			util.isSmall() && showDate(false, false, true);
			document.querySelector('[data-datepicker-date=year]').focus();
		};
	
		on.colMonth = ctrl.event();
		on.colMonth.click = function(ob, ev) {
			ctrl.vo.nowMonth(ob.m);
			ctrl.vo.lstMonth.data().forEach(function(vl) {
				ctrl.vo.lstMonth.data.replace(vl, {
					m: vl.m,
					css: {'badge-primary': vl.m == ob.m}
				});
			});
	
			makeDate();
			util.isSmall() && showDate(false, false, true);
			document.querySelector('[data-datepicker-date=month]').focus();
		};
	
		on.colDay = ctrl.event();
		on.colDay.click = function(ob, ev) {
			var str = util.string();
			ctrl.close(str.format(
				'####-##-##', ob.y + str.lpad(ob.m+1, 2, '0') + str.lpad(ob.d, 2, '0')
			));
		};
	};

	// ----- local function -----
	var makeDate = function() {
		var today = new Date();
		var _today = {
			y: today.getFullYear(),
			m: today.getMonth(),
			d: today.getDate()
		};
		var _now = {
			y: ctrl.vo.nowYear(),
			m: ctrl.vo.nowMonth() - 1,
			d: ctrl.vo.nowDay()
		};
		var date = new Date(ctrl.vo.nowYear(), ctrl.vo.nowMonth()-1, 1);
		date.setDate(date.getDate() - date.getDay() - 1);

		// set year
		var year = _now.y - 10;
		ctrl.vo.lstYear.data([]);
		do {
			ctrl.vo.lstYear.data.push({
				y: year,
				css: { 'badge-info': year == _now.y },
				attr: { 'data-datepicker-now-year': year == _now.y },
				style: { width: 'calc(100% / 5.1)', padding: '.5rem 0 .5rem 0', cursor: 'pointer' }
			});
		} while(year++ < _now.y + 9);

		// set month
		ctrl.vo.lstMonth.data([]);
		while(ctrl.vo.lstMonth.data().length < 12) {
			var month = ctrl.vo.lstMonth.data().length;
			ctrl.vo.lstMonth.data.push({
				m: month + 1,
				css: { 'badge-info': month == _now.m },
				attr: { 'data-datepicker-now-month': month == _now.m },
				style: { width: 'calc(100% / 6.1)', padding: '.5rem 0 .5rem 0', cursor: 'pointer' }
			});
		}

		// set day
		ctrl.vo.lstDay.data([]);
		'일,월,화,수,목,금,토'.split(',').forEach(function(vl) {
			ctrl.vo.lstDay.data.push({
				d: vl,
				css: {
					'text-primary': true
				},
				style: {
					width: 'calc(100% / 7.1)',
					padding: '.5rem 0 .5rem 0'
				}
			});
		});
		while(date.setDate(date.getDate() + 1)) {
			var day = {
				css: {},
				y: date.getFullYear(),
				m: date.getMonth(),
				d: date.getDate()
			};
			if(date.getDay() == 0 && _now.y*100+_now.m < day.y*100+day.m) break;

			var istoday = _today.y == day.y && _today.m == day.m && _today.d == day.d;
			var isinfo = _now.m == day.m && _now.d == day.d;
			ctrl.vo.lstDay.data.push({
				y: date.getFullYear(),
				m: date.getMonth(),
				d: date.getDate(),
				css: {
					'text-danger': !date.getDay() && !istoday && !isinfo,
					'text-muted': _now.m != day.m && !istoday && !isinfo,
					'badge-info': isinfo,
					'badge-primary': istoday
				},
				attr: {
					tabindex: '0',
					'data-datepicker-now-day': isinfo,
					'data-datepicker-today': istoday
				},
				style: {
					width: 'calc(100% / 7.1)',
					padding: '.5rem 0 .5rem 0',
					cursor: 'pointer'
				}
			});
		}

		util.isSmall() ? showDate(false, false, true) : showDate(true, true, true);
	};
	var showDate = function(y, m, d) {
		ctrl.vo.cssYear({ 'd-flex': y, 'd-none': !y });
		ctrl.vo.cssMonth({ 'd-flex': m, 'd-none': !m });
		ctrl.vo.cssDay({ 'd-flex': d, 'd-none': !d });
	};
});


}(
	mkApp.service('debug'),
	mkApp.service('http'),
	mkApp.service('util')
);
