!function(loader, debug, http, util) {


loader.onBind(function(vl) {
	vl || mkApp.view('main').bind();
});

var PATH = '/web-app/views' + location.pathname;

// ========== main ========== //
mkApp.view('main', function(ctrl) {
	var _getDomainList = function(isMore) {
		if(!isMore) {
			ctrl.vo.more(0).list([]);
			mkApp.clearPopup();
		}

		http.post('/data/master/domain/search', {
			keyword: ctrl.vo.keyword(),
			is_end: ctrl.vo.is_end(),
			next: ctrl.vo.more()
		}).then(function(rs) {
			debug.log(ctrl, rs.tot, rs.next, rs.tot > rs.next);
			ctrl.vo.more(rs.tot > rs.next ? rs.next : 0);

			var today = util.date().today();
			rs.list && rs.list.forEach(function(vl, idx) {
				var end = today > vl.d_end.replace(/-/g, '');

				ctrl.vo.list.push({
					uid: vl.uid,
					domain: vl.domain,
					admin: ctrl.observer(vl.admin),
					d_end: ctrl.observer(vl.d_end),
					info: ctrl.observer(vl.info),
					manager: ctrl.observer(vl.manager),
					active: ctrl.observer(false),
					isEnd: ctrl.observer(end),
					event: {
						click: function(ob, ev) {
							ctrl.vo.list().forEach(function(vl) {
								vl.active(ob == vl);
							});

							mkApp.popup('domainDetail')
							.modaless(ob).then(function() {
								ob.active(false);
							});
						}
					}
				});
			});
		});
	};

	ctrl.create(function() {
		ctrl.template = PATH + '/domain.html';
	}).onload(function() {
		_getDomainList();
	}).entity(function(vo) {
		vo.more = ctrl.observer(0);
		vo.keyword = ctrl.observer('');
		vo.is_end = ctrl.observer();
		vo.list = ctrl.observer([]);
		vo.site = { as: 'site', data: ctrl.observer([]) };
	}).event(function(on) {
		on.is_end = {
			selected: function(vl) {
				_getDomainList();
			}
		};

		on.search = {
			click: function(ob, ev) {
				if(ev && ev.target.type === 'text') return;
				_getDomainList();
			},
			keyup: function(ob, ev) {
				ev.keyCode === 13 && on.search.click();
			}
		};

		on.more = {
			click: function(ob, ev) {
				_getDomainList(true);
			}
		};

		on.regist = {
			click: function() {
				mkApp.popup('domainRegist').modal().then(function(vl) {
					if(!vl) return;

					ctrl.vo.keyword('');
					_getDomainList();
				});
			}
		};

		on.detail = {
			click: function(obs, evt) {
				ctrl.vo.site.data().forEach(function(vl) {
					vl.css.active(obs == vl);
				});

				mkApp.popup('domainDetail')
				.modaless(obs).then(function() {
					obs.css.active(false);
				});
			}
		};
	});
});

// ========== 등록 ========== //
mkApp.popup('domainRegist', function(ctrl) {
	ctrl.create(function() {
		ctrl.template = PATH + '/domain-regist.html';
	}).event(function(on) {
		on.cancel = { click: function() { ctrl.close(); } };
		on.ok = {
			click: function() {
				var data = mkApp.component('comDomainForm').getData();
				if(!data) return;

				http.post('/data/master/domain/regist', data)
				.then(function() {
					ctrl.close(true);
				});
			}
		};
	});
});

// ========== 수정 ========== //
mkApp.popup('domainDetail', function(ctrl) {
	ctrl.create(function() {
		ctrl.template = PATH + '/domain-detail.html';
		ctrl.css = { color: true };
		ctrl.attr = { for: 'color' };
	}).onload(function(prm) {
		http.loading(http.NONE).post('/data/master/domain/detail', {
			uid: prm.uid
		}).then(function(rs) {
			http.loading(http.HIDE);
	
			ctrl.vo.logs(rs.log);
			mkApp.component('comDomainForm').setData(prm, function(vl) {
				if(!vl || !vl.key) return;
	
				http.loading(http.NONE).post('/data/master/domain/modify', {
					uid: prm.uid,					
					key: vl.key,
					value: vl.value
				}).then(function(rs) {
					http.loading(http.HIDE);

					prm[vl.key](vl.value);
					ctrl.vo.logs(rs.log);
				});
			});
		});
	}).entity(function(vo) {
		vo.logs = ctrl.observer([]);
	});
});

// ========== 도메인 폼 ========== //
mkApp.component('comDomainForm', function(ctrl) {
	var _frmChange;

	ctrl.create(function() {
		ctrl.template = PATH + '/domain-form.html';
	}).onload(function(prm) {
		ctrl.vo.mode(prm.mode || 1);
	}).entity(function(vo) {
		vo.mode = ctrl.observer(1);
		vo.admin = ctrl.observer('');
		vo.domain = ctrl.observer('');
		vo.d_end = ctrl.observer('');
		vo.manager = ctrl.observer([]);
		vo.info = ctrl.observer('');
	}).event(function(on, vo) {
		on.domain = {};
		on.domain.feedback = function(vl) { if(!vl) return '도메인을 입력하세요.'; };

		on.admin = {
			selected: function(vl) {
				_frmChange && _frmChange({ key: 'admin', value: vl });
			},
			feedback: function(vl) {
				if(!vl) return '관리자 이메일을 입력하세요.';
			}
		};
		on.d_end = {
			selected: function(vl) {
				_frmChange && _frmChange({ key: 'd_end', value: vl });
			},
			feedback: function(vl) {
				if(!vl) return '도메인 만료일을 입력하세요.';
			}
		};
		on.manager = {
			click: function(ob, ev) {
				var target = (ev.currentTarget || ev.target);
				var action = target.dataset.action;
				var changeManager = function(vl) {
					_frmChange && _frmChange({ key: 'manager', value: vl.join(',') });
				};

				if(action == 'remove') {
					ctrl.vo.manager.remove(ob);
					return changeManager(ctrl.vo.manager());
				}

				mkApp.popup('popupFind').modal({
					type: 'member',
					keyword: action == 'modify' && ob,
					feedback: function(val) {
						var isMember = ctrl.vo.manager().reduce(function(is, vl) {
							if(is) return true;
							if(vl === val) return true;
						}, false);
						return isMember && '이미 선택된 관리자 입니다.';
					}
				}).then(function(rs) {
					if(!rs) return;

					if(action === 'modify') ctrl.vo.manager.replace(ob, rs);
					else ctrl.vo.manager.push(rs);

					changeManager(ctrl.vo.manager());
				});
			}
		};
		on.info = {
			change: function(vl) {
				_frmChange && _frmChange({ key: 'info', value: vl });
			}
		};
	}).method(function(mt) {
		mt.getData = function() {
			if(ctrl.on.domain.isInvalid()) return;
			if(ctrl.on.admin.isInvalid()) return;
			if(ctrl.on.d_end.isInvalid()) return;
		
			return {
				domain: ctrl.vo.domain().replace(/^http:\/\/|^https:\/\//g, ''),
				admin: ctrl.vo.admin(),
				d_end: ctrl.vo.d_end(),
				info: ctrl.vo.info(),
				manager: ctrl.vo.manager().map(function(vl) {
					return vl;
				}).join(',')
			};
		};
		mt.setData = function(vl, listener) {
			_frmChange = listener;
			ctrl.vo.domain(vl.domain);
			ctrl.vo.admin(vl.admin());
			ctrl.vo.d_end(vl.d_end());
			ctrl.vo.info(vl.info());
			vl.manager().split(',').forEach(function(vl) {
				vl && ctrl.vo.manager.push(vl);
			});
		};
	});
});


}(
	mkApp.view('pageLoader'),
	mkApp.service('debug'),
	mkApp.service('http'),
	mkApp.service('util')
);
