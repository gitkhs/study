!function(loader, debug, http, util) {


var _tpl = '/web-app/views/master/domain/';
loader.onBind(function(vl) {
	vl || mkApp.view('main').bind();
});
mkApp.view('main', function(ctrl) {
	ctrl.oncreate = function() {
		ctrl.template = _tpl + 'main.html';
	};

	ctrl.onload = function() {
		_getDomainList();
	};

	ctrl.vo = function(vo) {
		vo.more = ctrl.observer(0);
		vo.search = ctrl.observer('');
		vo.is_end = ctrl.observer('1');
		vo.site = ctrl.observer([], 'site');
	};

	ctrl.on = function(on) {
		on.d_end = ctrl.event();
		on.d_end.dropdown = function() {
			return [
				{value: '', text: '전체'},
				{value: '1', text: '사용중', selected: true},
				{value: '2', text: '만료'},
			];
		};
		on.d_end.change = function(vl) {
			ctrl.vo.more(0);
			ctrl.vo.site.data([]);
			_getDomainList();
		};

		on.search = ctrl.event();
		on.search.click = function(obs, evt) {
			if(evt && evt.target.type === 'text') return;

			ctrl.vo.more(0);
			ctrl.vo.site.data([]);
			_getDomainList(evt);
		};
		on.search.keyup = function(obs, evt) {
			evt.keyCode === 13 && on.search.click();
		};

		on.is_end = ctrl.event();
		on.is_end.change = function(obs, evt) {
			on.search.click(obs, evt);
		};

		on.more = ctrl.event();
		on.more.click = function(obs, evt) {
			_getDomainList(evt);
		};

		on.regist = ctrl.event();
		on.regist.click = function(obs, evt) {
			mkApp.popup('domainRegist').modal()
			.then(function(vl) {
				ctrl.focus = evt;
				if(!vl) return;

				ctrl.vo.more(0);
				ctrl.vo.search('');
				ctrl.vo.site.data([]);
				_getDomainList(evt);
			});
		};

		on.detail = ctrl.event();
		on.detail.click = function(obs, evt) {
			ctrl.vo.site.data().forEach(function(vl) {
				vl.css.active(vl == obs);
			});

			var target = evt.currentTarget;
			mkApp.popup('domainDetail').modaless(obs).then(function() {
				ctrl.focus = target;
				obs.css.active(false);
			});
		};
	};

	var _getDomainList = function(evt) {
		mkApp.clearPopup();

		return http.focus(evt)
		.post('/data/master/domain/search/' + ctrl.vo.more(), {
			keyword: ctrl.vo.search(),
			is_end: ctrl.on.d_end.value ? ctrl.on.d_end.value() : '1'
		}).then(function(rs) {
			ctrl.vo.more(rs.tot > rs.next ? rs.next : 0);

			var today = util.date().today();
			rs.list && rs.list.forEach(function(vl) {
				var end = today > vl.d_end.replace(/-/g, '');

				vl.admin = ctrl.observer(vl.admin);
				vl.d_end = ctrl.observer(vl.d_end);
				vl.info = ctrl.observer(vl.info);
				vl.manager = ctrl.observer(vl.manager ? vl.manager.split(',') : []);
				vl.css = {
					active: ctrl.observer(false),
					'list-group-item-light': ctrl.observer(end)
				}
				ctrl.vo.site.data.push(vl);
			});
		});
	};
});

// ===== domainRegist =====
mkApp.popup('domainRegist', function(ctrl) {
	ctrl.oncreate = function() {
		ctrl.template = _tpl + 'domain-regist.html';
	};

	ctrl.onload = function() {
	};

	ctrl.vo = function(vo) {
		vo.domain = ctrl.observer('');
		vo.admin = ctrl.observer('');
		vo.manager = ctrl.observer([], 'manager');
		vo.d_end = ctrl.observer('');
		vo.info = ctrl.observer('');
	};

	ctrl.on = function(on) {
		on.domain = ctrl.event();
		on.domain.feedback = function(vl) {
			if(!vl) return '도메인명을 입력하세요.';
		};

		on.d_end = ctrl.event();
		on.d_end.feedback = function(vl) {
			if(!vl) return '만료일을 입력하세요.';
		};
		on.d_end.click = function(obs, evt) {
			var date = util.date();
			var dEnd = ctrl.vo.d_end() || date.calc(date.YEAR, 1, date.today());

			debug.log(ctrl, evt.target);
			mkApp.popup('initPopupDatepicker').modal(dEnd)
			.then(function(rs) {
				ctrl.focus = evt;
				if(!rs) return;

				ctrl.vo.d_end(rs);
				on.d_end.validation(rs);
			});
		};

		on.admin = ctrl.event();
		on.admin.feedback = function(vl) {
			if(!vl) return '관리자 이메일을 입력하세요.';
		};
		on.admin.click = function(ob, evt) {
			mkApp.popup('initPopupMemberSearch').modal(ctrl.vo.admin())
			.then(function(rs) {
				ctrl.focus = evt;
				if(!rs) return;

				ctrl.vo.admin(rs.email);
				on.admin.validation(ctrl.vo.admin());
			});
		};

		on.manager = ctrl.event();
		on.manager.click = function(obs, evt) {
			var target = evt;
			var isAdd = evt.target.type === 'button';

			mkApp.popup('initPopupMemberSearch').modal(!isAdd && obs.email)
			.then(function(rs) {
				ctrl.focus = target;
				if(!rs) return;
				if(ctrl.vo.manager.data().reduce(function(find, vl) {
					if(find) return true;
					if(vl.email === rs.email) return true;
				}, false))
					return mkApp.alert('이미 선택된 관리자 입니다.').then(function() {
						ctrl.focus = target;
					});

				if(isAdd) ctrl.vo.manager.data.push(rs);
				else ctrl.vo.manager.data.replace(obs, rs);
			});
		};

		on.removeManager = ctrl.event();
		on.removeManager.click = function(obs, evt) {
			mkApp.confirm(obs.email + '을(를) 삭제 합니다.').then(function(rs) {
				ctrl.focus = evt;
				rs && ctrl.vo.manager.data.remove(obs);
			});
		};

		on.dateEnd = ctrl.event();
		on.dateEnd.click = function(obs, evt) {
			mkApp.popup('initPopupDatepicker').modal(ctrl.vo.d_end())
			.then(function(rs) {
				ctrl.focus = evt;
				if(!rs) return;
				ctrl.vo.d_end(rs);
			});
		};

		on.cancel = ctrl.event();
		on.cancel.click = function(obs, evt) {
			ctrl.close();
		};

		// confirm
		on.ok = ctrl.event();
		on.ok.click = function(obs, evt) {
			if(!on.domain.validation(ctrl.vo.domain())) return;
			if(!on.d_end.validation(ctrl.vo.d_end())) return;
			if(!on.admin.validation(ctrl.vo.admin())) return;

			http.post('/data/master/domain/regist', {
				domain: ctrl.vo.domain(),
				d_end: ctrl.vo.d_end(),
				admin: ctrl.vo.admin(),
				manager: ctrl.vo.manager.data().map(function(vl) {
					return vl.email;
				}).join(','),
				info: ctrl.vo.info()
			}).then(function() {
				ctrl.close(true);
			}).catch(function() {
				ctrl.focus = evt;
			});
		};
	};
});

// ===== domainDetail =====
mkApp.popup('domainDetail', function(ctrl) {
	var _prm;

	ctrl.oncreate = function() {
		ctrl.template = _tpl + 'domain-detail.html';
	};
	ctrl.onload = function(prm) {
		_prm = prm;
		ctrl.vo.domain(prm.domain);
		ctrl.vo.admin(prm.admin());
		ctrl.vo.d_end(prm.d_end());
		ctrl.vo.info(prm.info());
		prm.manager().forEach(function(vl) {
			ctrl.vo.manager.data.push({ email: vl});
		});

		http.get('/data/master/domain/detail/' + _prm.uid).then(function(rs) {
			ctrl.vo.log.data(rs.log);
		});
	};

	ctrl.vo = function(vo) {
		vo.domain = ctrl.observer('');
		vo.admin = ctrl.observer('');
		vo.d_end = ctrl.observer('');
		vo.info = ctrl.observer('');

		vo.manager = ctrl.observer([], 'manager');
		vo.log = ctrl.observer([], 'log');
	};

	ctrl.on = function(on) {
		var sendModify = function(ky, vl, data) {
			http.loading(http.NONE)
			.post('/data/master/domain/modify/' + _prm.uid, {
				key: ky,
				value: vl
			}).then(function(rs) {
				http.loading(http.HIDE);

				ctrl.vo.log.data(rs.log);
				_prm[ky] && _prm[ky](data || vl);
			}).catch(function(err) {
				debug.err(ctrl, err);
			});
		};

		on.cancel = ctrl.event();
		on.cancel.click = function() {
			ctrl.close();
		};

		on.admin = ctrl.event();
		on.admin.click = function(obs, evt) {
			mkApp.popup('initPopupMemberSearch').modal(ctrl.vo.admin())
			.then(function(rs) {
				ctrl.focus = evt;
				if(!rs) return;
				if(ctrl.vo.admin() == rs.email) return;

				ctrl.vo.admin(rs.email);
				sendModify('admin', rs.email);
			}).catch(function(err) {
				debug.err(ctrl, err);
			});
		};

		on.dEnd = ctrl.event();
		on.dEnd.click = function(obs, evt) {
			mkApp.popup('initPopupDatepicker').modal(ctrl.vo.d_end())
			.then(function(rs) {
				ctrl.focus = evt;
				if(!rs) return;
				if(ctrl.vo.d_end() == rs) return;

				var today = util.date().today();
				var end = today > rs.replace(/-/g, '');

				ctrl.vo.d_end(rs);
				_prm.css['list-group-item-light'](end);
				sendModify('d_end', rs);
			}).catch(function(err) {
				debug.log(ctrl, err);
			});
		};

		on.info = ctrl.event();
		on.info.change = function(obs, evt) {
			sendModify('info', evt.target.value);
		};

		on.manager = ctrl.event();
		on.manager.click = function(obs, evt) {
			var target = evt;
			var isAdd = evt.target.type === 'button';

			mkApp.popup('initPopupMemberSearch').modal(!isAdd && obs.email )
			.then(function(rs) {
				ctrl.focus = target;
				if(!rs) return;
				if(ctrl.vo.manager.data().reduce(function(find, vl) {
					if(find) return true;
					if(vl.email === rs.email) return true;
				}, false))
					return mkApp.alert('이미 선택된 관리자 입니다.').then(function() {
						ctrl.focus = target;
					});

				if(isAdd) ctrl.vo.manager.data.push(rs);
				else ctrl.vo.manager.data.replace(obs, rs);

				var manager = ctrl.vo.manager.data().map(function(vl) {
					return vl.email;
				});
				sendModify('manager', manager.join(), manager);
			}).catch(function(err) {
				debug.err(ctrl, err);
			});
		};

		on.removeManager = {};
		on.removeManager.click = function(obs, evt) {
			ctrl.vo.manager.data.remove(obs);
			var manager = ctrl.vo.manager.data().map(function(vl) {
				return vl.email;
			});
			sendModify('manager', manager.join(), manager);
		};
	};
});


}(
	mkApp.view('pageLoader'),
	mkApp.service('debug'),
	mkApp.service('http'),
	mkApp.service('util')
);
