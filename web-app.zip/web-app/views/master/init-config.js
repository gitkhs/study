!function(debug, http) {


http.error = true;
// config
// ====================
mkApp.init(function(config) {
	config.style = [
		'[data-app-modal-layout] {width:90%; margin-left:5%; margin-top:10%; background:#fff;}',
		'[data-app-modal-body],',
		'[data-app-modaless-body] {max-height:60vh; overflow-y:auto;}',
		'[data-app-modaless-layout] {width:100%; border-radius:0;}',
		'[data-app-modaless-layout].card,',
		'[data-app-modaless-layout].alert {margin-bottom:0; border-radius:0;}',
		'@keyframes modalopen {0%{margin-top:-20%; opacity:0;}}',
		'@keyframes modalclose {100%{margin-top:-20%; opacity:0;}}',
		'@keyframes modalessopen {0%{max-height:0;}}',
		'@keyframes modalessclose {100%{margin-top:-20%; opacity:0;}}',
		'@media (min-width: 780px) {',
			'[data-app-modal-layout] {margin-left: 15%; width: 70%;}',
			'[data-app-modaless-layout] {margin-top:-30px; margin-left:calc(30% - 1rem); width:70%;}',
			'[data-app-modaless-layout].card,',
			'[data-app-modaless-layout].alert {margin-bottom:1rem; border-radius:0.25rem;}',
		'}',
		// Prevent scroll on narrow devices
		'html, body { overflow-x: hidden; }',
		'body { padding-top: 56px; }',
		'@media (min-width: 991.98px) { .offcanvas-collapse { height:0; visibility:hidden; } }',
		'@media (max-width: 991.98px) {',
			'.offcanvas-collapse { position:fixed; top:56px; bottom:0; left:100%; width:100%; padding-right:1rem; padding-left:1rem; overflow-y:auto; visibility:hidden; background-color:#343a40; transition-timing-function:ease-in-out; transition-duration:.3s; transition-property:left, visibility; }',
			'.offcanvas-collapse.open { left:0; visibility:visible; }',
		'}',

		'.sidebar-sticky { position:relative; top:0; height:calc(100vh - 56px); padding-top:.5rem; overflow-x:hidden; overflow-y:auto; }',
		'@supports ((position: -webkit-sticky) or (position: sticky)) {',
			'.sidebar-sticky { position: -webkit-sticky; position: sticky; }',
		'}',
		// Content
		'main { padding-top:8px; min-height:60vh; }',
		// style modify
		'[data-app-modal-body] .input-group-append .btn,',
		'[data-app-modal-body] .input-group-prepend .btn {',
			'position:relative; z-index:0;',
		'}'
	];
	config.popup = {
		modal: {
			parent: 'position:fixed; top:0; left:0; width:100%; z-index:2010;',
			open: 'position:absolute; width:100%; animation:modalopen 1s 1;',
			close: 'animation:modalclose 1s 1;',
			background: {
				style: 'position:absolute; width:100%; height:100vh; background:#000; opacity:.5;',
				html: ''
			},
			trigger: function() {
			}
		},
		modaless: {
			parent: 'position:fixed; top:0; left:0; width:100%; z-index:2010;',
			open: 'position:fixed; bottom:0; width:100%; max-height:80vh; animation:modalessopen 1s 1;',
			close: 'animation:modalessclose 1s 1;',
			trigger: function(vl) {
				if(vl == 'open')
					mkApp.view('main').style = {'margin-bottom' : '70vh'};
				else 
					mkApp.view('main').style = {'margin-bottom' : ''};
			}
		}
	};
	config.alert = {
		html: [
'<div data-bind="focus" data-app-modal-layout class="card">',
	'<div class="card-body">',
		'<p data-bind="html:vo.msg" class="card-text">message</p>',
	'</div>',
	'<div class="card-footer text-right">',
		'<button data-bind="text:vo.ok, event:on.ok" class="btn btn-sm btn-primary">ok</button>',
	'</div>',
'</div>'
		],
		btnOk: '확인'
	};
	config.confirm = {
		html: [
'<div data-bind="focus" data-app-modal-layout class="card">',
	'<div class="card-body">',
		'<p data-bind="html:vo.msg" class="card-text">message</p>',
	'</div>',
	'<div class="card-footer text-right">',
		'<button data-bind="text:vo.yes, event:on.yes" class="btn btn-sm btn-primary">yes</button> ',
		'<button data-bind="text:vo.no, event:on.no" class="btn btn-sm btn-secondary">no</button>',
	'</div>',
'</div>'
		],
		btnYes: '예',
		btnNo: '아니오'
	};
	config.toast = {
		html: [
'<div data-app-modaless-layout class="alert alert-info">',
	'<div data-bind="html:vo.msg" class="font-weight-bold">message</div>',
'</div>'
		],
		time: 3000
	};
});

// directive
// ====================
mkApp.directive('validation', function(handle) {
	handle.init = function(el, ob) {
		ob.validation = function(vl) {
			var focus = true;
			if(vl instanceof Event) {
				focus = false;
				vl = vl.target.value;
			}

			var feedback = ob.feedback(el.value);
			if(feedback) {
				var text = el.parentElement.querySelector('.invalid-feedback');
				if(text) text.innerText = feedback;

				el.classList.remove('is-valid');
				el.classList.add('is-invalid');
				focus && el.focus();
				return false;
			}

			el.classList.add('is-valid');
			el.classList.remove('is-invalid');
			return true;
		};
		el.addEventListener('change', ob.validation);
		el.addEventListener('keyup', ob.validation);
	};
	return handle;
});
mkApp.directive('dropdown', function(handle) {
	handle.init = function(el, ob) {
		var dropdown = el.parentElement.querySelector('.dropdown-menu');
		if(!ob.dropdown || !dropdown) return;

		var menus = ob.dropdown(), selected;
		var append = function(vl) {
			var aTag = dropdown.appendChild(document.createElement('a'));
			aTag.href = '#';
			aTag.innerHTML = vl.text;
			aTag.classList.add('dropdown-item');
			if(vl.selected) {
				el.innerHTML = vl.text;
				aTag.classList.add('active');
				selected = { value: vl.value, text: vl.text };
			}
			aTag.addEventListener('click', function(evt) {
				menus.forEach(function(vl) {
					vl.selected = false;
					vl.el.classList.remove('active');
					if(vl.el == evt.target) {
						vl.selected = true;
						el.innerHTML = vl.text;
						vl.el.classList.add('active');
					}
				});

				selected = { value: vl.value, text: vl.text };
				ob.change && ob.change(selected);
			});
			return aTag;
		};

		dropdown.innerHTML = '';
		menus.forEach(function(vl) {
			vl.el = append(vl);
		});

		ob.value = function(val) {
			if(!val) return selected.value;

			menus.forEach(function(vl) {
				vl.selected = false;
				if(vl.value == val) {
					vl.selected = true;
					el.innerHTML = vl.text;
					selected = { value: vl.value, text: vl.text };
				}
			});
		};
		ob.text = function(val) {
			if(!val) return selected.text;

			menus.forEach(function(vl) {
				vl.selected = false;
				if(vl.text == val) {
					vl.selected = true;
					el.innerHTML = vl.text;
					selected = { value: vl.value, text: vl.text };
				}
			});
		};
		ob.append = function(vl) {
			vl.el = append(vl);
			menus.push(vl);
		};


		el.addEventListener('click', function(evt) {
			dropdown.classList.add('show');

			// dropdown menu close
			var bindBtn = evt.target.dataset.bind;
			var remove = function(evt) {
				var bind = evt.target.dataset.bind;
				if(bind && bind == bindBtn) return;
				document.removeEventListener('click', remove);
				dropdown.classList.remove('show');
			};
			document.addEventListener('click', remove);
		});
	};
	return handle;
});

// service
// ====================
mkApp.service('util', function(svc) {
	// string
	var _string = {};
	_string.left = function(vl, sz) {
		return vl.substr(0, sz);
	};
	_string.right = function(vl, sz) {
		return vl.substr(vl.length - sz);
	};
	_string.lpad = function(vl, sz, ch) {
		if(vl.length >= sz) return vl;

		var pd = [vl];
		while(pd.length < sz) pd.unshift(ch || ' ');
		return _string.right(pd.join(''), sz);
	};
	_string.rpad = function(vl, sz, ch) {
		if(vl.length >= sz) return vl;

		var pd = [vl];
		while(pd.length < sz) pd.push(ch || ' ');
		return _string.left(pd.join(''), sz);
	};
	_string.format = function(fm, vl) {
		if(typeof fm !== 'string' || typeof vl !== 'string') return;

		vl = vl.split('');
		return fm.replace(/#/g, function() {
			return vl.length ? vl.shift() : '';
		});
	};

	// date
	var _date = {};
	_date.YEAR = {symbol:'YEAR'}, _date.MONTH = {symbol:'MONTH'}, _date.DATE = {symbol:'DATE'};
	_date.calc = function(ymd, vl, date) {
		var dt = new Date();
		if(typeof date == 'string') {
			date = date.replace(/-|\./g,'');
			if(/\d{8}/.test(date)) {
				dt.setFullYear(parseInt(date.substr(0, 4)));
				dt.setMonth(parseInt(date.substr(4, 2)) - 1);
				dt.setDate(parseInt(date.substr(6, 2)));
			}
		}
		ymd == _date.YEAR && dt.setFullYear(dt.getFullYear() + vl);
		ymd == _date.MONTH && dt.setMonth(dt.getMonth() + vl);
		ymd == _date.DATE && dt.setDate(dt.getDate() + vl);

		return dt.getFullYear() +
			_string.lpad(dt.getMonth()+1, 2, '0') +
			_string.lpad(dt.getDate(), 2, '0');
	};
	_date.today = function(vl) {
		var dt = new Date();
		var date = dt.getFullYear() +
			_string.lpad(dt.getMonth()+1, 2, '0') +
			_string.lpad(dt.getDate(), 2, '0');
		return vl ? _date.format('yyyy-mm-dd', date) : date;
	};
	_date.format = function(fm, vl) {
		if(!fm || !vl) return;
		var dt = (vl instanceof Date) ? vl : new Date();
		if(typeof vl == 'string') {
			if(!/\d{8}/.test(vl)) return;
			dt.setFullYear(parseInt(vl.substr(0, 4)));
			dt.setMonth(parseInt(vl.substr(4, 2)) - 1);
			dt.setDate(parseInt(vl.substr(6, 2)));
		}

		return fm.replace(/(yyyy|yy|mm|dd|hh|mi|ss|ms\/p)/g, function(p) {
			if('yyyy' == p) return dt.getFullYear();
			else if('yy' == p) return _string.lpad(dt.getFullYear(), 2, '0');
			else if('mm' == p) return _string.lpad(dt.getMonth()+1, 2, '0');
			else if('dd' == p) return _string.lpad(dt.getDate(), 2, '0');
			else if('hh' == p) return _string.lpad(dt.getHours(), 2, '0');
			else if('mi' == p) return _string.lpad(dt.getMinutes(), 2, '0');
			else if('ss' == p) return _string.lpad(dt.getSeconds(), 2, '0');
			else if('ms' == p) return _string.lpad(dt.getMilliseconds(), 3, '0');
		});
	};

	svc.string = function() { return _string; };
	svc.date = function() { return _date; };
	svc.loadLibs = function(vl) {
		return Promise.all(Array.isArray(vl) ? vl : [vl].map(function(vl) {
			return new Promise(function(resolve, reject) {
				var js = document.head.appendChild(document.createElement('script'))
				js.src = /\?/.test(vl) ? vl : (vl + '?v=' + _date.today());
				js.onload = function() {
					resolve({ load: true, src: vl });
				};
				js.onerror = function() {
					resolve({ load: false, src: vl });
				};
			});
		}));
	};
	svc.isSmall = function() {
		return window.innerWidth < 576;
	};

	return svc;
});


}(
	mkApp.service('debug'),
	mkApp.service('http')
);
