!function(debug, http) {


var _tpl = '/web-app/views/';
// ===== naviHead =====
mkApp.view('naviHead', function(ctrl) {
	ctrl.create(function() {
		ctrl.bind();
	}).onload(function(prm) {
		var menus = [
			[
				{type: 'text', text: '컨텐츠관리'},
				{type: 'link', text: '도메인 관리', link: '/master/domain'},
				{type: 'link', text: '설문폼 관리', link: '/master/survey'},
			], [
				{type: 'text', text: '개발'},
				{type: 'link', text: '디버깅', link: '/master/debug'}
			]
		];
		
		ctrl.vo.menus(menus);
		mkApp.view('naviSide').vo.menus(menus);
	}).entity(function(vo) {
		vo.menus = ctrl.observer([]);
		vo.open = ctrl.observer();
	}).event(function(on) {
		on.menu = {
			click: function() {
				mkApp.clearPopup();
				ctrl.vo.open(!ctrl.vo.open());
			}		
		};

		on.signout = {
			click: function() {
				http.get('/data/master/member/sign-out').then(function() {
					location.reload();
				}).catch(function(err) {
					debug.err(ctrl, err);
				});
			}
		};

	});
});

// ===== naviSide =====
mkApp.view('naviSide', function(ctrl) {
	ctrl.create(function() {
		ctrl.bind();
	}).entity(function(vo) {
		vo.menus = ctrl.observer([]);
	});
});

// ===== pageLoader =====
mkApp.view('pageLoader', function(ctrl) {
	ctrl.create(function() {
		ctrl.bind();
	}).onload(function(prm) {
		http.get('/data/master/member/stat').then(function(rs) {
			rs.sign ? ctrl.unbind() : ctrl.vo.wait(false);
		});
	}).entity(function(vo) {
		vo.wait = ctrl.observer(true);
		vo.email = ctrl.observer('');
		vo.passwd = ctrl.observer('');
		// on.email.feedback = function(vl) {
		// 	if(!vl) return '이메일을 입력하세요.';
		// 	if(!/^[a-zA-Z](\w)*@(\S)+.[a-zA-Z]$/.test(vl))
		// 		return '형식에 맞지않는 이메일입니다.';
		// };
		// on.passwd.feedback = function(vl) {
		// 	if(!vl) return '비밀번호를 입력하세요.';
		// 	if(vl.length < 5) return '비밀번호를 5자리 이상 입력하세요.';
		// };
	}).event(function(on) {
		on.google = {
			click: function() {
				http.post('/data/master/member/sign-in').then(function() {
					location.reload();
				});
			}
		};

		on.facebook = {
			click: function() {
				alert('facebook');
			}
		};

		on.passwd = {
			keyup: function(ob, ev) {
				// ev.keyCode === 13 && on.signin.click(ob, ev);
			}
		};

		on.signin = {
			click: function() {
				if(!on.email.validation()) return;
				if(!on.passwd.validation()) return;
				alert('signin');
			}
		};

		on.reset = {
			click: function() {
				mkApp.popup('gnbResetPassword').modaless();
			}
		};
	});
});

// ===== gnbResetPassword =====
mkApp.popup('gnbResetPassword', function(ctrl) {
	ctrl.create(function() {
		ctrl.html = '\
		<div data-bind="focus" data-app-modaless-layout class="card">\
			<div data-bind="header: \'비밀번호변경 메일발송\'" class="card-header"></div>\
			<div data-app-modaless-body class="card-body ">\
				<div class="form-row d-flex justify-content-end">\
					<div class="mr-3 w-50">\
						<input type="email" class="form-control form-control-sm form-block" placeholder="이메일">\
					</div>\
					<div>\
						<button class="btn btn-sm btn-outline-info" type="button">보내기</button>\
					</div>\
				</div>\
			</div>\
		</div>\
		';
	}).onload(function(prm) {
	}).entity(function(vo) {
		vo.email = ctrl.observer('');
		// on.email.feedback = function(vl) {
		// 	if(!vl) return '이메일을 입력하세요.';
		// 	if(!/^[a-zA-Z](\w)*@(\S)+.[a-zA-Z]$/.test(vl)) return '형식에 맞지않는 이메일입니다.';
		// };
	}).event(function(on) {
		on.email = {
			keyup: function(ob, ev) {
				ev.keyCode === 13 && on.send.click();
			}
		};

		on.send = {
			click: function() {
				if(!on.email.validation()) return;
				mkApp.alert('비밀번호 변경메일을 발송했습니다.').then(function() {
					ctrl.close(true);
				});
			}
		};

		on.close = {
			click: function() {
				ctrl.close();
			}
		};
	});
});


}(
	mkApp.service('debug'),
	mkApp.service('http')
);