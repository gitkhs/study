!function(debug, http, util) {


var PATH = '/web-app/views/master/';
// ===== popupFind =====
mkApp.popup('popupFind', function(ctrl) {
	var _prm, _intid, _kw = '';
	var _type = {
		domain: { title: '도메인검색', path: 'domain' },
		member: { title: '회원검색', path: 'member' }
	};

	// ---------- controller ---------- //
	ctrl.create(function() {
		ctrl.template = PATH +'master-popup-find.html';
	}).onload(function(prm) {
		_prm = prm || {};
		ctrl.vo.title(_type[_prm.type].title);
		if(!_prm.keyword) return;

		ctrl.vo.keyword(_prm.keyword);
	}).entity(function(vo) {
		vo.title = ctrl.observer('');
		vo.keyword = ctrl.observer('');
		vo.list = ctrl.observer([]);
	}).event(function(on) {
		on.keyword = {
			keyup: function(ob, ev) {
				_kw = ev.target.value;
				if(on.keyword.isInvalid()) return;
				if(_intid) return;

				_intid = setInterval(function() {
					if(_kw == ev.target.value) _intid = clearInterval(_intid);
		
					var type = _type[_prm.type];
					http.loading(http.NONE).post('/data/master/finder/' + _prm.type, {
						keyword: _kw
					}).then(function(rs) {
						http.loading(http.HIDE);
						ctrl.vo.list(rs);
					});
				}, 400);
			},
			feedback: function(vl) {
				if(!vl) return '이메일을 입력하세요.';
				if(vl.length < 2) return '이메일을 2자이상 입력하세요.';
			}
		};

		on.close = {
			click: function(ob, ev) { ctrl.close(); }
		};

		on.selected = {
			click: function(ob, ev) {
				var feedback = _prm.feedback && _prm.feedback(ob.value);
				if(feedback) return mkApp.alert(feedback);

				ctrl.close(ob.value);
			}
		};
	})
});

// ===== popupDatepicker =====
mkApp.popup('popupDatepicker', function(ctrl) {
	var _showDate = function(y, m, d) {
		ctrl.vo.cssYear({ 'd-flex': y, 'd-none': !y });
		ctrl.vo.cssMonth({ 'd-flex': m, 'd-none': !m });
		ctrl.vo.cssDay({ 'd-flex': d, 'd-none': !d });
	};
	var _makeDate = function() {
		var today = new Date();
		var _today = {
			y: today.getFullYear(),
			m: today.getMonth(),
			d: today.getDate()
		};
		var _now = {
			y: ctrl.vo.nowYear(),
			m: ctrl.vo.nowMonth() - 1,
			d: ctrl.vo.nowDay()
		};
		var date = new Date(ctrl.vo.nowYear(), ctrl.vo.nowMonth()-1, 1);
		date.setDate(date.getDate() - date.getDay() - 1);

		// set year
		var year = _now.y - 10;
		ctrl.vo.lstYear.data([]);
		do {
			ctrl.vo.lstYear.data.push({
				y: year,
				css: { 'badge-info': year == _now.y },
				attr: { 'data-datepicker-now-year': year == _now.y },
				style: { width: 'calc(100% / 5.1)', padding: '.5rem 0 .5rem 0', cursor: 'pointer' }
			});
		} while(year++ < _now.y + 9);

		// set month
		ctrl.vo.lstMonth.data([]);
		while(ctrl.vo.lstMonth.data().length < 12) {
			var month = ctrl.vo.lstMonth.data().length;
			ctrl.vo.lstMonth.data.push({
				m: month + 1,
				css: { 'badge-info': month == _now.m },
				attr: { 'data-datepicker-now-month': month == _now.m },
				style: { width: 'calc(100% / 6.1)', padding: '.5rem 0 .5rem 0', cursor: 'pointer' }
			});
		}

		// set day
		ctrl.vo.lstDay.data([]);
		'일,월,화,수,목,금,토'.split(',').forEach(function(vl) {
			ctrl.vo.lstDay.data.push({
				d: vl,
				css: {
					'text-primary': true
				},
				style: {
					width: 'calc(100% / 7.1)',
					padding: '.5rem 0 .5rem 0'
				}
			});
		});
		while(date.setDate(date.getDate() + 1)) {
			var day = {
				css: {},
				y: date.getFullYear(),
				m: date.getMonth(),
				d: date.getDate()
			};
			if(date.getDay() == 0 && _now.y*100+_now.m < day.y*100+day.m) break;

			var istoday = _today.y == day.y && _today.m == day.m && _today.d == day.d;
			var isinfo = _now.m == day.m && _now.d == day.d;
			ctrl.vo.lstDay.data.push({
				y: date.getFullYear(),
				m: date.getMonth(),
				d: date.getDate(),
				css: {
					'text-danger': !date.getDay() && !istoday && !isinfo,
					'text-muted': _now.m != day.m && !istoday && !isinfo,
					'badge-info': isinfo,
					'badge-primary': istoday
				},
				attr: {
					tabindex: '0',
					'data-datepicker-now-day': isinfo,
					'data-datepicker-today': istoday
				},
				style: {
					width: 'calc(100% / 7.1)',
					padding: '.5rem 0 .5rem 0',
					cursor: 'pointer'
				}
			});
		}

		util.isSmall() ? _showDate(false, false, true) : _showDate(true, true, true);
	};

	// ---------- controller ---------- //
	ctrl.create(function() {
		ctrl.template = PATH + 'master-popup-datepicker.html';
	}).onload(function(prm) {
		if(typeof prm != 'string') return ctrl.on.today.click();

		prm = prm.replace(/-|\.|\//g, '');
		if(prm.length != 8) return ctrl.on.today.click();

		ctrl.vo.nowYear(parseInt(prm.substr(0,4), 10));
		ctrl.vo.nowMonth(parseInt(prm.substr(4,2), 10));
		ctrl.vo.nowDay(parseInt(prm.substr(6,2), 10));
		_makeDate();
	}).entity(function(vo) {
		vo.cssYear = ctrl.observer({});
		vo.cssMonth = ctrl.observer({});
		vo.cssDay = ctrl.observer({});

		vo.nowYear = ctrl.observer(0);
		vo.nowMonth = ctrl.observer(0);
		vo.nowDay = ctrl.observer(0);

		vo.lstYear = { as: 'year', data: ctrl.observer([]) };
		vo.lstMonth = { as: 'month', data: ctrl.observer([]) };
		vo.lstDay = { as: 'day', data: ctrl.observer([]) };
	}).event(function(on) {
		on.close = {
			click: function() { ctrl.close(); }
		};

		on.year = {
			click: function() {
				util.isSmall() && _showDate(true, false, false);
				document.querySelector('[data-datepicker-now-year=true]').focus();
			}
		};

		on.month = {
			click: function() {
				util.isSmall() && _showDate(false, true, false);
				document.querySelector('[data-datepicker-now-month=true]').focus();
			}
		};

		on.day = {
			click: function() {
				util.isSmall() && _showDate(false, false, true);
				document.querySelector('[data-datepicker-now-day=true]').focus();
			}
		};

		on.today = {
			click: function(ob, ev) {
				var today = new Date();
				ctrl.vo.nowYear(today.getFullYear());
				ctrl.vo.nowMonth(today.getMonth() + 1);
				ctrl.vo.nowDay(today.getDate());

				_makeDate();
				ev && document.querySelector('[data-datepicker-today=true]').focus();
			}
		};

		on.prev = {
			click: function(ob, ev) {
				var target = (ev.currentTarget || ev.target);
				var date = new Date(ctrl.vo.nowYear(), ctrl.vo.nowMonth() - 1, 1);
				if(target.dataset.datepickerPrev == 'year')
					date.setFullYear(date.getFullYear() - 1);
				else if(target.dataset.datepickerPrev == 'month')
					date.setMonth(date.getMonth() - 1);

				ctrl.vo.nowYear(date.getFullYear());
				ctrl.vo.nowMonth(date.getMonth() + 1);
				_makeDate();
			}
		};

		on.next = {
			click: function(ob, ev) {
				var target = (ev.currentTarget || ev.target);
				var date = new Date(ctrl.vo.nowYear(), ctrl.vo.nowMonth() - 1, 1);
				if(target.dataset.datepickerNext == 'year')
					date.setFullYear(date.getFullYear() + 1);
				else if(target.dataset.datepickerNext == 'month')
					date.setMonth(date.getMonth() + 1);

				ctrl.vo.nowYear(date.getFullYear());
				ctrl.vo.nowMonth(date.getMonth() + 1);
				_makeDate();
			}
		};

		on.colYear = {
			click: function(ob, ev) {
				ctrl.vo.nowYear(ob.y);
				ctrl.vo.lstYear.data().forEach(function(vl) {
					ctrl.vo.lstYear.data.replace(vl, {
						y: vl.y,
						css: {'badge-primary': vl.y == ob.y}
					});
				});

				_makeDate();
				util.isSmall() && _showDate(false, false, true);
				document.querySelector('[data-datepicker-date=year]').focus();
			}
		};

		on.colMonth = {
			click: function(ob, ev) {
				ctrl.vo.nowMonth(ob.m);
				ctrl.vo.lstMonth.data().forEach(function(vl) {
					ctrl.vo.lstMonth.data.replace(vl, {
						m: vl.m,
						css: {'badge-primary': vl.m == ob.m}
					});
				});

				_makeDate();
				util.isSmall() && _showDate(false, false, true);
				document.querySelector('[data-datepicker-date=month]').focus();
			}
		};

		on.colDay = {
			click: function(ob, ev) {
				var str = util.string();
				ctrl.close(ob.y + str.lpad(ob.m+1, 2, '0') + str.lpad(ob.d, 2, '0'));
			}
		};
	});
});


}(
	mkApp.service('debug'),
	mkApp.service('http'),
	mkApp.service('util')
);
