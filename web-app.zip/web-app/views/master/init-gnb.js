!function(debug, http) {


var _tpl = '/web-app/views/master/';
// ===== naviHead =====
mkApp.view('naviHead', function(ctrl) {
	ctrl.oncreate = function() {
		ctrl.bind();
	};

	ctrl.vo = function(vo) {
		vo.menu = { open: ctrl.observer() };
	};

	ctrl.on = function(on) {
		on.menu = ctrl.event('click', function() {
			mkApp.clearPopup();
			ctrl.vo.menu.open(!ctrl.vo.menu.open());
		});

		on.signout = ctrl.event('click', function() {
			http.get('/data/member/sign-out').then(function() {
				location.reload();
			}).catch(function(err) {
				debug.err(ctrl, err);
			});
		});
	};
});

// ===== naviSide =====
mkApp.view('naviSide', function(ctrl) {
	ctrl.oncreate = function() {
		ctrl.bind();
	};
});

// ===== pageLoader =====
mkApp.view('pageLoader', function(ctrl) {
	ctrl.oncreate = function() {
		ctrl.bind();
	};

	ctrl.onload = function() {
		http.get('/data/member/stat').then(function(rs) {
			rs.sign ? ctrl.unbind() : ctrl.vo.wait(false);
		}).catch(function(err) {
			debug.err('auth|stat', err);
		});
	};

	ctrl.vo = function(vo) {
		vo.wait = ctrl.observer(true);
		vo.email = ctrl.observer('');
		vo.passwd = ctrl.observer('');
	};

	ctrl.on = function(on) {
		on.google = ctrl.event();
		on.google.click = function(ob, ev) {
			http.get('/data/member/local').then(function() {
				location.reload();
			}).catch(function(err) {
				debug.err(ctrl, err);
			});
		};

		on.facebook = ctrl.event();
		on.facebook.click = function(ob, ev) {
			alert('facebook');
		};

		on.email = ctrl.event();
		on.email.feedback = function(vl) {
			if(!vl) return '이메일을 입력하세요.';
			if(!/^[a-zA-Z](\w)*@(\S)+.[a-zA-Z]$/.test(vl))
				return '형식에 맞지않는 이메일입니다.';
		};

		on.passwd = ctrl.event();
		on.passwd.feedback = function(vl) {
			if(!vl) return '비밀번호를 입력하세요.';
			if(vl.length < 5) return '비밀번호를 5자리 이상 입력하세요.';
		};
		on.passwd.keyup = function(ob, ev) {
			ev.keyCode === 13 && on.signin.click(ob, ev);
		};

		on.signin = ctrl.event();
		on.signin.click = function(ob, ev) {
			if(!on.email.validation()) return;
			if(!on.passwd.validation()) return;
			alert('signin');
		};

		on.reset = ctrl.event();
		on.reset.click = function(ob, ev) {
			mkApp.popup('initGnbResetPassword').modaless().then(function(rs) {
				ctrl.focus = ev;
			});
		};
	};
});

// ===== initGnbResetPassword =====
mkApp.popup('initGnbResetPassword', function(ctrl) {
	ctrl.oncreate = function() {
		ctrl.template = _tpl + 'init-gnb-reset-password.html';
	};

	ctrl.vo = function(vo) {
		vo.email = ctrl.observer('');
	};

	ctrl.on = function(on) {
		on.email = ctrl.event();
		on.email.feedback = function(vl) {
			if(!vl) return '이메일을 입력하세요.';
			if(!/^[a-zA-Z](\w)*@(\S)+.[a-zA-Z]$/.test(vl)) return '형식에 맞지않는 이메일입니다.';
		};
		on.email.keyup = function(ob, ev) {
			ev.keyCode === 13 && on.send.click();
		};

		on.send = ctrl.event();
		on.send.click = function() {
			if(!on.email.validation()) return;
	
			mkApp.alert('비밀번호 변경메일을 발송했습니다.').then(function() {
				ctrl.close(true);
			});
		};

		on.close = ctrl.event();
		on.close.click = function() {
			ctrl.close();
		};
	};
});


}(
	mkApp.service('debug'),
	mkApp.service('http')
);