!function(debug, http) {


http && (http.error = true);
// config
// ====================
mkApp.init(function(config) {
	config.style = [
		'[data-app-modal-layout] {width:90%; margin-left:5%; margin-top:5vh; background:#fff;}',
		'[data-app-modal-body] {max-height:75vh; overflow-y:auto;}',
		'[data-app-modaless-body] {max-height:40vh; overflow-y:auto;}',
		'[data-app-modaless-layout] {width:100%; border-radius:0; box-shadow:0 -5px 10px 0 rgba(0,0,0,0.3);}',
		'[data-app-modaless-layout].card,',
		'[data-app-modaless-layout].alert {margin-bottom:0; border-radius:0;}',
		'@keyframes modalopen {0%{margin-top:-20%; opacity:0;}}',
		'@keyframes modalclose {100%{margin-top:-20%; opacity:0;}}',
		'@keyframes modalessopen {0%{bottom:-100px; opacity:0;} 100%{bottom:0;}}',
		'@keyframes modalessclose {100%{bottom:-100px; opacity:0;}}',
		'@keyframes modaless-full {0%{min-height:40vh;}}',
		'@keyframes modaless-unfull {0%{min-height:90vh;}}',
		'@media (min-width: 991.98px) {',
			'[data-app-modal-layout] {margin-left: 15%; width: 70%;}',
			'[data-app-modaless-layout] {margin-left:calc(20% - 1rem); width:80%; box-shadow:0 0 10px 0 rgba(0,0,0,0.8);}',
			'[data-app-modaless-layout].card,',
			'[data-app-modaless-layout].alert {margin-bottom:1rem; border-radius:0.25rem;}',
		'}',
		// Prevent scroll on narrow devices
		'html, body { overflow-x: hidden; }',
		'body { padding-top: 56px; }',
		'@media (min-width: 991.98px) { .offcanvas-collapse { height:0; visibility:hidden; } }',
		'@media (max-width: 991.98px) {',
			'.offcanvas-collapse { position:fixed; top:56px; bottom:0; left:100%; width:100%; padding-right:1rem; padding-left:1rem; overflow-y:auto; visibility:hidden; background-color:#343a40; transition-timing-function:ease-in-out; transition-duration:.3s; transition-property:left, visibility; }',
			'.offcanvas-collapse.open { left:0; visibility:visible; }',
		'}',

		'.sidebar-sticky { position:relative; top:0; height:calc(100vh - 56px); padding-top:.5rem; overflow-x:hidden; overflow-y:auto; }',
		'@supports ((position: -webkit-sticky) or (position: sticky)) {',
			'.sidebar-sticky { position: -webkit-sticky; position: sticky; }',
		'}',
		// Content
		'main { padding-top:8px; min-height:60vh; }',
		''
	];
	config.popup = {
		modal: {
			parent: 'position:fixed; top:0; left:0; width:100%; z-index:2010;',
			open: 'position:absolute; width:100%; animation:modalopen 1s 1; z-index:2011;',
			close: 'animation:modalclose 1s 1;',
			background: {
				style: 'position:absolute; width:100%; height:100vh; background:#000; opacity:.5; z-index:2011;',
				html: ''
			},
			trigger: function(open) {
				var html = document.querySelector('html');
				if(open) {
					html.style.overflowY = 'hidden';
				} else {
					if(document.querySelectorAll('[data-popup-type=modal]').length <= 1) {
						var scrLock = document.querySelector('[data-popup-scroll-lock]');
						if(!scrLock || scrLock.dataset.popupScrollLock == 0)
							html.style.overflowY = 'auto';
					}
				}
			}
		},
		modaless: {
			parent: 'position:fixed; top:0; left:0; width:100%; z-index:2010;',
			open: 'position:fixed; bottom:0; width:100%; animation:modalessopen 1s 1; z-index:2011;',
			close: 'animation:modalessclose 1s 1;',
			trigger: function(open) {
				var html = document.querySelector('html');
				if(open) {
					html.style.overflowY = 'hidden';
					mkApp.view('main').style = { 'margin-bottom': '60vh' };
				} else {
					html.style.overflowY = 'auto';
					mkApp.view('main').style = { 'margin-bottom': '' };
				}
			}
		}
	};
	config.alert = {
		html: [
'<div data-bind="focus:0" data-app-modal-layout class="card">',
	'<div data-app-modal-body class="card-body">',
		'<p data-bind="html:vo.msg" class="card-text">message</p>',
	'</div>',
	'<div class="card-footer text-right">',
		'<button data-bind="text:vo.ok, event:on.ok" class="btn btn-sm btn-primary">ok</button>',
	'</div>',
'</div>'
		],
		btnOk: '확인'
	};
	config.confirm = {
		html: [
'<div data-bind="focus:0" data-app-modal-layout class="card">',
	'<div data-app-modal-body class="card-body">',
		'<p data-bind="html:vo.msg" class="card-text">message</p>',
	'</div>',
	'<div class="card-footer text-right">',
		'<button data-bind="text:vo.yes, event:on.yes" class="btn btn-sm btn-primary">yes</button> ',
		'<button data-bind="text:vo.no, event:on.no" class="btn btn-sm btn-secondary">no</button>',
	'</div>',
'</div>'
		],
		btnYes: '예',
		btnNo: '아니오'
	};
	config.toast = {
		html: [
'<div data-bind="focus:0" data-app-modaless-layout class="alert alert-info">',
	'<div data-bind="html:vo.msg" class="font-weight-bold">message</div>',
'</div>'
		],
		time: 3000
	};
});

// service
// ====================
mkApp.service('util', function(svc) {
	// string
	var _string = {};
	_string.left = function(vl, sz) {
		return vl.substr(0, sz);
	};
	_string.right = function(vl, sz) {
		return vl.substr(vl.length - sz);
	};
	_string.lpad = function(vl, sz, ch) {
		if(vl.length >= sz) return vl;

		var pd = [vl];
		while(pd.length < sz) pd.unshift(ch || ' ');
		return _string.right(pd.join(''), sz);
	};
	_string.rpad = function(vl, sz, ch) {
		if(vl.length >= sz) return vl;

		var pd = [vl];
		while(pd.length < sz) pd.push(ch || ' ');
		return _string.left(pd.join(''), sz);
	};
	_string.format = function(fm, vl) {
		if(typeof fm !== 'string' || typeof vl !== 'string') return;

		vl = vl.split('');
		return fm.replace(/#/g, function() {
			return vl.length ? vl.shift() : '';
		});
	};
	_string.commas = function(vl) {
		return parseInt(vl).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	};

	// date
	var _date = {};
	_date.YEAR = {symbol:'YEAR'}, _date.MONTH = {symbol:'MONTH'}, _date.DATE = {symbol:'DATE'};
	_date.calc = function(ymd, vl, date) {
		var dt = new Date();
		if(typeof date == 'string') {
			date = date.replace(/-|\./g,'');
			if(/\d{8}/.test(date)) {
				dt.setFullYear(parseInt(date.substr(0, 4)));
				dt.setMonth(parseInt(date.substr(4, 2)) - 1);
				dt.setDate(parseInt(date.substr(6, 2)));
			}
		}
		ymd == _date.YEAR && dt.setFullYear(dt.getFullYear() + vl);
		ymd == _date.MONTH && dt.setMonth(dt.getMonth() + vl);
		ymd == _date.DATE && dt.setDate(dt.getDate() + vl);

		return dt.getFullYear() +
			_string.lpad(dt.getMonth()+1, 2, '0') +
			_string.lpad(dt.getDate(), 2, '0');
	};
	_date.today = function(vl) {
		var dt = new Date();
		var date = dt.getFullYear() +
			_string.lpad(dt.getMonth()+1, 2, '0') +
			_string.lpad(dt.getDate(), 2, '0');
		return vl ? _date.format(vl, date) : date;
	};
	_date.format = function(fm, vl) {
		if(!fm || !vl) return;
		var dt = (vl instanceof Date) ? vl : new Date();
		if(typeof vl == 'string') {
			if(!/\d{8}/.test(vl)) return;
			dt.setFullYear(parseInt(vl.substr(0, 4)));
			dt.setMonth(parseInt(vl.substr(4, 2)) - 1);
			dt.setDate(parseInt(vl.substr(6, 2)));
		}

		return fm.replace(/(yyyy|yy|mm|dd|hh|mi|ss|ms\/p)/g, function(p) {
			if('yyyy' == p) return dt.getFullYear();
			else if('yy' == p) return _string.lpad(dt.getFullYear(), 2, '0');
			else if('mm' == p) return _string.lpad(dt.getMonth()+1, 2, '0');
			else if('dd' == p) return _string.lpad(dt.getDate(), 2, '0');
			else if('hh' == p) return _string.lpad(dt.getHours(), 2, '0');
			else if('mi' == p) return _string.lpad(dt.getMinutes(), 2, '0');
			else if('ss' == p) return _string.lpad(dt.getSeconds(), 2, '0');
			else if('ms' == p) return _string.lpad(dt.getMilliseconds(), 3, '0');
		});
	};

	// observer list
	var _list = {}, _listData;
	_list.replace = function(obs, src, proc) {
		obs.replace(src, proc(Object.assign({}, src)));
	};
	_list.selected = function(obs, src, proc) {
		obs().forEach(function(vl) {
			var data = proc(src == vl, Object.assign({}, vl));
			obs.replace(vl, data);
			if(src == vl) src = data;
		});
	};

	svc.string = function() { return _string; };
	svc.date = function() { return _date; };
	svc.list = function() { return _list; };
	svc.loadLibs = function(vl) {
		return Promise.all((Array.isArray(vl) ? vl : [vl]).map(function(vl) {
			return new Promise(function(resolve, reject) {
				var target;
				var exe = vl.split('.').reduce(function(rs, vl) { return vl; });
				if(exe == 'js') {
					target = document.head.appendChild(document.createElement('script'));
					target.src = /\?/.test(vl) ? vl : (vl + '?v=' + _date.today());
				} else if(exe == 'css') {
					target = document.head.appendChild(document.createElement('link'));
					target.href = /\?/.test(vl) ? vl : (vl + '?v=' + _date.today());
					target.rel="stylesheet";
				}
				if(!target) reject('load fail: ' + vl);

				target.onload = function() {
					resolve({ load: true, src: vl });
				};
				target.onerror = function() {
					resolve({ load: false, src: vl });
				};
			});
		}));
	};
	svc.isSmall = function() {
		return window.innerWidth < 576;
	};
	svc.target = function(ev) { return ev.curretnTarget || ev.target; }

	mkApp.help('service', 'util', [
		'유틸리티 string, date ...',
		'loadLibs(vl:array[,string]): 스크립트를 추가 결과를 Promise로 반환',
		'isSmall: 모바일 브라우저 여부반환',
		'target(ev:Event): 이벤트 타겟을 반환',
		'string',
		'\tleft(vl:string, sz:number): 문자열을 왼쪽에서 사이즈까지 반환',
		'\tright(vl:string, sz:number): 문자열을 오른쪽에서 사이즈까지 반환',
		'\tlpad(vl:string, sz:number, ch:char): 문자열의 사이즈 까지의 왼쪽 공간을 채움(기본값: \' \')',
		'\trpad(vl:string, sz:number, ch:char): 문자열의 사이즈 까지의 오른쪽 공간을 채움(기본값: \' \')',
		'\tformat(fm:string, vl:string): 포멧(치환값:#)의 형태로 문자열을 치환',
		'\tcommas(vl:string[,number]): 숫자값에 콤마 추가',
		'date',
		'\t속성값: YEAR, MONTH, DATE',
		'\tclac(target:TYPE, vl:number, date:string[,date(default)]): 날짜계산 (target-날짜 속성값)',
		'\ttoday(vl:string): 오늘 날짜를 포멧형태로 반환(기본값-yyyymmdd)',
		'\tformat(fm:string, vl:string[,date]): 포멧 형태(yyyy.mm.dd hh.mi.ss.ms)로 날짜를 반환'
	]);
	return svc;
});

var util = mkApp.service('util');
// directive

// 드롭다운 메뉴
// ==============================
mkApp.directive('frmDropdown', function(dir, observer) {
	dir.init = function(el, prm) {
		var appendItem = function(vl) {
			var item = menu.appendChild(document.createElement('a'));
			item.href = '#';
			item.innerHTML = vl.text;
			item.classList.add('dropdown-item');
			item.addEventListener('click', function() {
				prm.value(vl.value);
				prm.handle.selected && prm.handle.selected(vl.value);
			});

			if(vl.selected) {
				prm.value(vl.value);
				button.innerHTML = vl.text;
				item.classList.add('active');
			}
			return item;
		};
		el.classList.add('btn-group');

		var button = el.appendChild(document.createElement('button'));
		prm.button = prm.button || {};
		prm.button.type = 'button';
		prm.button['aria-haspopup'] = true;
		prm.button['aria-expanded'] = false;

		Object.entries(prm.button).forEach(function(vl) {
			button.setAttribute(vl[0], vl[1]);
		});
		button.classList.add('dropdown-toggle');
		button.addEventListener('click', function() {
			var removeMenu = function(ev) {
				if(button === ev.target) return;
				if(button === ev.curretnTarget) return;

				menu.classList.remove('show');
				button.setAttribute('aria-expanded', false);
				document.removeEventListener('click', removeMenu);
				button.focus();
			};

			menu.classList.add('show');
			button.setAttribute('aria-expanded', true);
			document.addEventListener('click', removeMenu);
		});

		var menu = el.appendChild(document.createElement('div'));
		menu.classList.add('dropdown-menu');

		// ---------- //
		prm.data = prm.data || [];
		prm.value = prm.value || observer('');
		prm.handle = prm.handle || {};

		// prm.data
		prm.data.forEach(function(vl) {
			vl.el = appendItem(vl);
		});

		// prm.value observerble
		prm.value.subscribe(function(val) {
			prm.data.forEach(function(vl) {
				if(vl.value === val) {
					button.innerHTML = vl.text;
					vl.selected = true;
					vl.el.classList.add('active');
				} else {
					vl.selected = false;
					vl.el.classList.remove('active');
				}
			});
		});

		// prm.handle binding
		prm.handle.data = function() {
			return prm.data;
		};
		prm.handle.append = function(vl) {
			vl.el = appendItem(vl);
			prm.data.push(vl);
		};
		prm.handle.remove = function(val) {
			prm.data = prm.data.reduce(function(rs, vl) {
				return (vl.value == val ? menu.removeChild(vl.el) : rs.push(vl)), rs;
			}, []);
			prm.value(prm.data[0].value);
		};
	};

	return mkApp.help('directive', 'frmDropdown', [
		'드롭다운 메뉴생성',
		'button: 버튼 attribute',
		'data: array({value:string, text:string, selected:boolean})',
		'value: observer',
		'handle: event object',
		'\tselected: function(vl:string) 메뉴 선택 이벤트',
		'\tappend({value:string, text:string}): 메뉴항목 추가',
		'\tremove(vl:string): 메뉴항목 삭제',
		'------------------------------',
		'<button data-bind="frmDropdown: {',
		'\tvalue: vo.demo,',
		'\thandle: on.demo,',
		'\tdata: [',
		'\t\t{value: \'1\', text: \'-1-\'},',
		'\t\t{value: \'2\', text: \'-2-\', selected: true}',
		'\t],',
		'\tbutton: {',
		'\t\tclass: \'btn btn-sm btn-outline-info\'',
		'\t}',
		'}">dropdown</button>',
		'vo.demo = observer();',
		'on.demo = {',
		'\tselected: function(vl) { console.log(vl); }',
		'};'
	]), dir;
});

// 체크박스 / 라디오버튼
// ==============================
var fmrChois = function(type, dir) {
	dir.init = function(el, prm) {
		prm = prm || {};
		el.classList.add('custom-control');
		el.classList.add('custom-' + type);

		var input = el.children[0];
		if(prm.value) input.value = prm.value;
		var stamp = type + '_' + new Date().getTime() + '_' + input.value;
		input.setAttribute('id', stamp);
		input.type = type;
		input.classList.add('custom-control-input');
		
		var label = el.children[1];
		label.setAttribute('for', stamp);
		label.classList.add('custom-control-label');
	};

	var name = 'frm' + type.substr(0, 1).toUpperCase() + type.substr(1);
	return mkApp.help('directive', name, [
		{checkbox:'체크박스', radio:'라디오버튼'}[type],
		'------------------------------',
		'<div data-bind="'+name+': {value: \'1\'}">',
		'\t<input data-bind="checked: vo.chk" type="'+type+'" value="1">',
		'\t<label>1</label>',
		'</div>'
	]), dir
};

// 체크박스 
mkApp.directive('frmCheckbox', function(dir) {
	return fmrChois('checkbox', dir);
});

// 라디오버튼
mkApp.directive('frmRadio', function(dir) {
	return fmrChois('radio', dir);
});

// ===== 검색창 ===== //
mkApp.directive('frmFinder', function(dir) {
	dir.init = function(el, prm, ctrl) {
		el.classList.add('input-group');

		var input = el.appendChild(document.createElement('input'));
		prm.input = prm.input || {};
		prm.input.type = 'text';
		prm.input.readonly = true;
		Object.entries(prm.input).forEach(function(vl) {
			input.setAttribute(vl[0], vl[1]);
		});

		var handle = prm.handle || {};
		prm.value = prm.value || ctrl.observer('');
		prm.value.subscribe(function(vl) {
			input.value = vl || '';
		});

		var wrap = el.appendChild(document.createElement('div'));
		wrap.setAttribute('class', 'input-group-append');

		var button = wrap.appendChild(document.createElement('button'));
		prm.button = prm.button || {};
		prm.button['data-bind'] = 'focus:\'return\'';
		Object.entries(prm.button).forEach(function(vl) {
			button.setAttribute(vl[0], vl[1]);
		});
		button.innerHTML = prm.button.title || '검색';
		if(prm.button.icon)
			button.innerHTML = '<i class="oi '+ prm.button.icon +'" aria-hidden="true"></i> ' + prm.button.title;
		button.addEventListener('click', function(evt) {
			mkApp.popup('popupFind').modal({
				type: prm.type,
				keyword: input.value
			}).then(function(rs) {
				if(!rs) return;

				prm.value(rs);
				handle.selected && handle.selected(rs);
			});
		});
	};

	return mkApp.help('directive', 'frmFinder', [
		'검색팝업 입력필드',
		'type: 팝업종류 "domain", "member"',
		'input: {class, placeholder [,...]} 출력 필드 속성',
		'button: {title, class, icon }  버튼 속성',
		'value: observer',
		'handle: event & method',
		'\tselected: function(vl:string) 값 선택시 발생되는 이벤트',
		'------------------------------',
		'<div data-bind="',
		'frmFinder: {',
		'\tvalue: vo.demo,',
		'\thandle: on.demo,',
		'\ttype: \'domain\',',
		'\tinput: {',
		'\t\tclass: \'form-control form-control-sm border-secondary\',',
		'\t\tplaceholder: \'입력하세요.\',',
		'\t\t\'aria-label\': \'접근성 선택 필드\'',
		'\t},',
		'\tbutton: {',
		'\t\ttitle: \'버튼 타이틀\',',
		'\t\ticon: \'oi-globe\',',
		'\t\tclass: \'btn btn-sm btn-outline-secondary\'',
		'\t}',
		'}',
		'"></div>',
		'vo.demo = observer();',
		'on.demo = function(vl) { console.log(vl); }'
	]), dir;
});

// ===== 날짜선택 ===== //
mkApp.directive('frmDatepicker', function(handle) {
	handle.init = function(el, prm) {
		el.classList.add('input-group');

		var input = el.appendChild(document.createElement('input'));
		prm.input = prm.input || {};
		prm.input.type = 'text';
		prm.input.readonly = true;
		prm.input['aria-label'] = '달력팝업 열기';
		Object.entries(prm.input).forEach(function(vl) {
			input.setAttribute(vl[0], vl[1]);
		});

		var value = prm.value || observer('');
		var handle = prm.handle || {};
		// value
		value.subscribe(function(vl) {
			var val = vl.replace(/-|\.|\//g, '');
			input.value = /^\d{8}$/.test(val) ? util.string().format('####-##-##', val) : '';
		});
		// value(value().replace(/-|\.|\//g, ''));

		var wrap = el.appendChild(document.createElement('div'));
		wrap.setAttribute('class', 'input-group-append');

		var button = wrap.appendChild(document.createElement('button'));
		prm.button = prm.button || {};
		prm.button.title = '달력조회';
		prm.button['data-bind'] = 'focus:\'return\'';
		Object.entries(prm.button).forEach(function(vl) {
			button.setAttribute(vl[0], vl[1]);
		});
		button.innerHTML = '<i class="oi oi-calendar" aria-hidden="true"></i> 달력';
		button.addEventListener('click', function(ev) {
			var defDate = prm.default
				&& util.date().calc(util.date()[prm.default[0]], prm.default[1]);

			mkApp.popup('popupDatepicker')
			.modal(input.value || defDate).then(function(rs) {
				if(!rs) return;

				value(rs);
				handle.selected && handle.selected(rs);
			});
		});
	};

	return mkApp.help('directive', 'frmDatepicker', [
		'날짜선택',
		'input: {class, placeholder [,...]} 출력 필드 속성',
		'button: {title, class, icon }  버튼 속성',
		'default: ["YEAR"|"MONTH"|"DATE", number] 오픈시 기본 날짜 - 기준으로 부터의 계산',
		'value: observer',
		'handle: event & method',
		'\tselected: function(vl:string) 값 선택시 발생되는 이벤트',
		'------------------------------',
		'<div data-bind="frmDatepicker:{',
		'\tvalue: vo.demo,',
		'\thandle: on.demo,',
		'\tdefault: [\'YEAR\', 1],',
		'\tinput: {',
		'\t\tclass: \'form-control form-control-sm border-secondary text-center\',',
		'\t\tplaceholder: \'도메인 만료일을 입력하세요.\',',
		'\t},',
		'\tbutton: {',
		'\t\tclass: \'btn btn-sm btn-outline-secondary\'',
		'\t}',
		'}"></div>',
		'vo.demo = observer();',
		'on.demo = {',
		'\tselected: function(vl) { console.log(vl) }',
		'};'
	]), handle;
});

// ===== 입력값 정합성 체크 ===== //
mkApp.directive('frmValidation', function(dir) {
	dir.init = function(el, prm, ctrl) {
		var feedback = el.parentNode.insertBefore(document.createElement('div'), el.nextSibling);
		feedback.classList.add('invalid-tooltip');

		var input = el;
		if(!/INPUT|TEXTAREA/.test(el.nodeName.toUpperCase())) {
			input = el.parentNode.insertBefore(document.createElement('input'), feedback);
			input.type = 'hidden';
			input.classList.add('form-control');
			el.setAttribute('tabindex', '0');
		}

		var toggleFeedback = function(vl) {
			var txt = prm.handle.feedback && prm.handle.feedback(vl);
			if(txt) {
				feedback.innerText = txt;
				input.classList.add('is-invalid');
			} else {
				input.classList.remove('is-invalid');
			}
			return !!txt;
		};

		prm.value = prm.value || ctrl.observer();
		prm.value.subscribe(function(vl) {
			input.value = vl;
			toggleFeedback(vl)
			prm.handle.feedback && prm.handle.feedback(vl);
		});

		prm.handle.isInvalid = function() {
			var invalid = toggleFeedback(input.value);
			invalid && el.focus();
			return invalid;
		};
	};

	return mkApp.help('directive', 'frmValidation', [
		'입력값 정합성 체크',
		'value: 옵저버 객체',
		'handler',
		'\tfeedback: function(vl:string) - 정합성 체크 후 출력된 문구를 리턴',
		'\isInvalid(): 피드백 조건 체크, 리턴값이 true이면 유효하지 않은값',
		'------------------------------',
		'<input data-bind="value: on.demo, frmValidation: {value: on.demo, handle: on.demo}" type="text">',
		'on.demo = {',
		'\tfeedback: function(vl) {',
		'\t\tif(!vl) return \'invalid input\';',
		'\t}',
		'};',
		'// 피드백 체크',
		'if(ctrl.on.demo.isInvalid()) return;'
	]), dir;
});

// ===== 업데이터 ===== //
mkApp.directive('frmUpdater', function(handle) {
	handle.init = function(el, prm) {
		var div = document.createElement('div');
		div.setAttribute('style', 'position:absolute; top:0; width:100%; height:100vh; background:#000; opacity:.5; z-index:2000;');
		el.addEventListener('focus', function() {
			mkApp.appendLayer(div);
		});
		el.addEventListener('blur', function(evt) {
			mkApp.removeLayer(div);
		});
		el.addEventListener('change', function(evt) {
			prm.change && prm.change(el.value);
		});
	};

	// popmodify
	return mkApp.help('directive', 'frmUpdater', [
		'모달 형식의 수정필드',
		'handler',
		'\tchange: function(vl:string) 입력 체인지 이벤트',
		'------------------------------',
		'<div data-bind="frmUpdater: on.demo"></div>',
		'on.demo = {',
		'\tchange: function(vl) {',
		'\t\tdebug.log(ctrl, vl);',
		'\t}',
		'};'
	]), handle;
});

// ===== 팝업 타이틀 ===== //
mkApp.directive('header', function(handle) {
	handle.init = function(el, prm, ctrl) {
		el.classList.add('d-flex');
		el.classList.add('justify-content-between');

		var title = el.appendChild(document.createElement('div'));
		title.setAttribute('class', 'font-weight-bold');
		if(typeof prm == 'function') {
			title.innerText = prm();
			prm.subscribe(function(vl) {
				title.innerText = vl;
			});
		} else {
			title.innerText = prm;
		}

		var conts = el.nextElementSibling;
		var bar = el.appendChild(document.createElement('div'));
		if(ctrl.type == 'modaless') {
			var isLock = true;
			var html = document.querySelector('html');
			var lock = bar.appendChild(document.createElement('a'));
			var lockIcon = lock.appendChild(document.createElement('i'));
			lock.href = '#';
			lock.title = '스크롤 풀림';
			lockIcon.dataset.popupScrollLock = 1;
			lockIcon.setAttribute('class', 'mr-3 oi oi-lock-locked');
			lockIcon.setAttribute('aria-hidden', true);
			lock.addEventListener('click', function(ev) {
				ev && ev.preventDefault();
				isLock = !isLock;

				if(isLock) {
					lock.title = '스크롤 풀림';
					lockIcon.dataset.popupScrollLock = 1;
					lockIcon.setAttribute('class', 'mr-3 oi oi-lock-locked');
					html.style.overflowY = 'hidden';
				} else {
					lock.title = '스크롤 잠김';
					lockIcon.dataset.popupScrollLock = 0;
					lockIcon.setAttribute('class', 'mr-3 oi oi-lock-unlocked');
					html.style.overflowY = 'auto';
				}
			});

			var isFull = false;
			var screen = bar.appendChild(document.createElement('a'));
			var screenIcon = screen.appendChild(document.createElement('i'));
			screen.href = '#';
			screen.title = '전체화면';
			screenIcon.setAttribute('class', 'mr-3 oi oi-chevron-top');
			screenIcon.setAttribute('aria-hidden', true);
			screen.addEventListener('click', function(ev) {
				ev && ev.preventDefault();
				isFull = !isFull;

				if(isFull) {
					screen.title = '화면복구';
					screenIcon.setAttribute('class', 'mr-3 oi oi-chevron-bottom');
					conts.style.minHeight = 'calc(100vh - ' + el.clientHeight + 'px' + (ctrl.isSmall ? ')' : ' - 2rem)');
					conts.style.animation = 'modaless-full 1s 1';
				} else {
					screen.title = '전체화면';
					screenIcon.setAttribute('class', 'mr-3 oi oi-chevron-top');
					conts.style.minHeight = '0';
					conts.style.animation = 'modaless-unfull 2s 1';
				}
			});
		}

		var close = bar.appendChild(document.createElement('a'));
		close.href = '#';
		close.title = '닫기';
		close.innerHTML = '<i class="oi oi-x" aria-hidden="true"></i>';
		close.addEventListener('click', function(ev) {
			ev && ev.preventDefault();
			ctrl.close();
		});
	};

	return mkApp.help('directive', 'header', [
		'팝업 타이틀바',
		'[observer|string] 타이틀바 타이틀',
		'------------------------------',
		'<div data-bind="header: vo.title"></div>',
		'vo.title = observer("title");'
	]), handle;
});

// ============================== //

// 붙여넣기
// ====================
// frmPaste
mkApp.directive('paste', function(dir) {
	dir.init = function(el, prm) {
		el.setAttribute('contenteditable', true);
		el.innerText = '선택 후 붙여넣기(Ctrl+V) 하세요.';
		el.addEventListener('paste', function(ev) {
			ev.preventDefault();
			var cb = ev.clipboardData || window.clipboardData;
			prm.change && prm.change(cb.getData('text'));
		});
	};
	return mkApp.help('directive', 'paste', [
		'붙여넣기 가능한 필드 생성',
		'프로퍼티',
		'\tchange: function(vl) 클립보드의 내용을 텍스트 형태로 반환한다.',
		'------------------------------',
		'<div data-bind="paste:vo.paste.sample"></div>',
		'vo.valid = {',
		'\tsample: {',
		'\t\tchange: function(vl) {',
		'\t\t\tdebug.log(ctrl, vl);',
		'\t\t}',
		'\t}',
		'};'
	]), dir;
});

// ============================== //
mkApp.directive('formatDate', function(dir) {
	dir.init = function(el, prm, ctrl) {
		var convert = function(vl) {
			var string = util.string();
			vl = vl.replace(/-|\./g, '');

			if(/INPUT/.test(el.nodeName.toUpperCase())) {
				el.value = vl ? string.format('####-##-##', vl) : '';
				el.addEventListener('focus', function(ev) {
					el.value = el.value.replace(/-|\./g, '');
				});
				el.addEventListener('blur', function(ev) {
					if(!el.value) return;
					el.value = string.format('####-##-##', el.value.replace(/-|\./g, ''));
				});
			} else {
				el.innerText = vl ? string.format('####-##-##', vl) : '';
			}
		}

		convert(prm());
		prm = prm || ctrl.observer();
		prm.subscribe(convert);
	};
	return dir;
});
mkApp.directive('formatNumber', function(dir) {
	dir.init = function(el, prm, ctrl) {
		var convert = function(vl) {
			var string = util.string();
			vl = vl.replace(/,/g, '');

			if(/INPUT/.test(el.nodeName.toUpperCase())) {
				el.value = vl ? string.commas(vl) : '';
				el.addEventListener('focus', function(ev) {
					el.value = el.value.replace(/,/g, '');
				});
				el.addEventListener('blur', function(ev) {
					if(!el.value) return;
					el.value = string.commas(el.value.replace(/,/g, ''));
				});
			} else {
				el.innerText = vl ? string.commas(vl) : '';
			}
		}

		convert(prm());
		prm = prm || ctrl.observer();
		prm.subscribe(convert);
	};
	return dir;
});


}(
	mkApp.service('debug'),
	mkApp.service('http')
);
