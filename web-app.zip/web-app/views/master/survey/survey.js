!function(loader, debug, http, util) {


loader.onBind(function(vl) {
	vl || mkApp.view('main').bind();
});

var PATH = '/web-app/views' + location.pathname;
// util.loadLibs([
// 	PATH + '/regist.js'
// ]);

// ----- main ----- //
mkApp.view('main', function(ctrl) {
	var _getFormList = function(isMore) {
		if(!isMore) {
			ctrl.vo.list([]);
		}

		http.post('/data/master/survey/list/' + ctrl.vo.more(), {
		}).then(function(rs) {
			rs.list && rs.list.forEach(function(vl) {
				ctrl.vo.list.push({
					active: ctrl.observer(false),
					uid: vl.uid,
					open: ctrl.observer(vl.open),
					d_end: ctrl.observer(vl.d_end.replace(/-|0/g, '') ? vl.d_end : ''),
					data: ctrl.observer(vl.data),
					event: {
						click: function(ob, ev) {
							ctrl.vo.list().forEach(function(vl) {
								vl.active(ob == vl);
							});

							mkApp.popup('surveyDetail').modaless(ob)
							.then(function(rt) {
								ob.active(false);
								rt.delete && ctrl.vo.list.remove(ob);
							});
						}
					}
				});
			});
		});
	};
	var _selectedDomain = function(domain) {
		http.post('/data/master/survey/selected-domain', {
			domain: domain
		}).then(function(rs) {
			ctrl.vo.domain(rs.domain);
			if(rs.domain) {
				ctrl.vo.selected(true);
				_getFormList();
			}
		});
	}

	// ---------- controller ---------- //
	ctrl.create(function() {
		ctrl.template = PATH + '/survey.html';
	}).onload(function(prm) {
		_selectedDomain();
	}).entity(function(vo) {
		vo.domain = ctrl.observer();
		vo.selected = ctrl.observer();
		vo.more = ctrl.observer(0);
		vo.list = ctrl.observer([]);
	}).event(function(on) {
		on.regist = {};
		on.regist.click = function() {
			mkApp.popup('surveyRegist').modal()
			.then(function() {
				_getFormList();
			});
		};
		on.domain = {
			selected: function(vl) {
				_selectedDomain(vl);
			}
		};
	});
});

// ========== 등록 ========== //
mkApp.popup('surveyRegist', function(ctrl) {
	ctrl.create(function() {
		ctrl.template = PATH + '/survey-regist.html';
	}).event(function(on) {
		on.cancel = { click: function() { ctrl.close(); } };
		on.ok = {
			click: function() {
				var data = mkApp.component('comSurveyForm').getData();
				if(!data) return;

				http.post('/data/master/survey/regist')
				.then(function(rs) {
					return http.post('/data/master/survey/regist/' + rs.tid, data);
				}).then(function() {
					ctrl.close();
				});
			}
		};
	});
});

// ========== 수정 ========== //
mkApp.popup('surveyDetail', function(ctrl) {
	var _prm;
	ctrl.create(function() {
		ctrl.template = PATH + '/survey-detail.html';
	}).onload(function(prm) {
		_prm = prm;
		mkApp.component('comSurveyForm').setData(prm);
	}).event(function(on) {
		on.cancel = { click: function() { ctrl.close(); } };
		on.modify = {
			click: function() {
				var data = mkApp.component('comSurveyForm').getData();
				if(!data) return;

				http.post('/data/master/survey/modify')
				.then(function(rs) {
					return http.post('/data/master/survey/modify/' + rs.tid, data);
				}).then(function() {
					_prm.open(data.open);
					_prm.d_end(data.d_end);
					_prm.data(data.data);
				});
			}
		};
		on.delete = {
			click: function() {
				mkApp.confirm('삭제 하시겠습니까?').then(function(rt) {
					if(rt) return http.post('/data/master/survey/delete');
					// rt && ctrl.close({delete:true});
				}).then(function(rt) {
					if(!rt) return;
					return http.post('/data/master/survey/delete/' + rt.tid, {
						uid: _prm.uid
					});
				}).then(function(rt) {
					if(!rt) return;
					ctrl.close({delete:true});
				});
			}
		};
	});
});

// ========== 설문 폼 ========== //
mkApp.component('comSurveyForm', function(ctrl) {
	var _makeItem = function(vl) {
		vl = vl || {};
		return {
			title: ctrl.observer(vl.title || ''),
			fixed: ctrl.observer(vl.fixed || false),
			kind: ctrl.observer(vl.kind || '1'),
			max: ctrl.observer(vl.max || '0'),
			option: ctrl.observer(vl.option || ''),
			name: 'option_' + (ctrl.vo.list ? ctrl.vo.list().length : '0'),
			remove: {
				click: function(ob) {
					ctrl.vo.list.remove(ob);
				}
			},
			append: {
				click: function() {
					ctrl.vo.list.push(_makeItem());
				}
			},
			valid: {
				title: {
					feedback: function(vl) {
						if(!vl) return '폼제목을 입력하세요.';
					}
				}
			}
		};
	};

	ctrl.create(function() {
		ctrl.template = PATH + '/survey-form.html';
	}).onload(function(prm) {
		ctrl.vo.mode(prm.mode || 1);
	}).entity(function(vo) {
		vo.mode = ctrl.observer();
		vo.uid = ctrl.observer();
		vo.d_end = ctrl.observer();
		vo.open = ctrl.observer();
		vo.list = ctrl.observer([_makeItem()]);
	}).event(function(on) {
		on.uid = {
			feedback: function(vl) {
				if(!vl) return '폼아이디를 입력하세요.';
				if(!/^\w*$|^\d*$/.test(vl)) return '폼아이디를 영문 또는 숫자로 입력하세요.';
			}
		};
	}).method(function(mt) {
		mt.getData = function() {
			if(ctrl.vo.mode() == 1 && ctrl.on.uid.isInvalid()) return;

			var data = ctrl.vo.list().reduce(function(rs, vl) {
				if(vl.valid.title.isInvalid()) return rs;

				rs.push({
					fixed: vl.fixed(),
					title: vl.title(),
					kind: vl.kind(),
					max: vl.max(),
					option: vl.option()
				});
				return rs;
			}, []);

			if(data.length != ctrl.vo.list().length) return;
			return {
				uid: ctrl.vo.uid(),
				open: ctrl.vo.open() ? '1' : '',
				d_end: ctrl.vo.d_end(),
				data: JSON.stringify(data)				
			};
		};

		mt.setData = function(vl, listener) {
			ctrl.vo.uid(vl.uid);
			ctrl.vo.open(vl.open());
			ctrl.vo.d_end(vl.d_end());

			ctrl.vo.list([]);
			JSON.parse(vl.data()).forEach(function(vl) {
				ctrl.vo.list.push(_makeItem(vl));
			});
		};
	})
});


}(
	mkApp.view('pageLoader'),
	mkApp.service('debug'),
	mkApp.service('http'),
	mkApp.service('util')
);
