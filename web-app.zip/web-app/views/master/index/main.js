!function(loader, debug, http, util) {


var _tpl = '/web-app/views/master/index/';
loader.onBind(function(vl) {
	vl || mkApp.view('main').bind();
});
mkApp.view('main', function(ctrl) {
	ctrl.oncreate = function() {
		ctrl.template = _tpl + 'main.html';
	};

	ctrl.onload = function() {
	};

	ctrl.vo = function(vo) {
	};

	ctrl.on = function(on) {
	};
});


}(
	mkApp.view('pageLoader'),
	mkApp.service('debug'),
	mkApp.service('http'),
	mkApp.service('util')
);
