!function(loader, debug, http, util) {


var _path = '/web-app/views' + location.pathname + '/index';
loader.onBind(function(vl) {
	vl || mkApp.view('main').bind();
});

mkApp.view('main', function(ctrl) {
	ctrl.create(function() {
		ctrl.template = _path + '/main.html';
	}).onload(function() {
		// var testPaste = document.getElementById('testPaste');
		// testPaste.addEventListener('paste', function(ev) {
		// 	ev.preventDefault();
		// 	var cb = ev.clipboardData || window.clipboardData;
		// 	console.log(cb.getData('text').split('\n'));
		// });
	}).entity(function(vo) {
		vo.paste = {
			test: {
				change: function(vl) {
					// debug.log(ctrl, vl);
					console.log(vl);
				}
			}
		};
	}).event(function(on) {
		on.trace = {
			click: function() {
				http.loading(http.NONE).get('/data/master/index/trace').then(function(rs) {
					debug.string(ctrl, rs);
				});
			}
		};
		on.tracem = {
			click: function() {}
		};
		on.debug = {
			click: function() {
				http.get('/data/master/index/debug').then(function(rs) {
					debug.string(ctrl, rs);
				});
			}
		};
	});
});


}(
	mkApp.view('pageLoader'),
	mkApp.service('debug'),
	mkApp.service('http'),
	mkApp.service('util')
);
