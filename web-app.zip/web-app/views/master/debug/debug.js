!function(loader, debug, http, util) {


loader.onBind(function(vl) {
	vl || mkApp.view('main').bind();
});

var PATH = '/web-app/views' + location.pathname;

// ----- main ----- //
mkApp.view('main', function(ctrl) {
	ctrl.create(function() {
		ctrl.template = PATH + '/debug.html';
		http.loading(http.NONE);
	}).onload(function() {
	}).entity(function(vo) {
		vo.list = ctrl.observer([]);
		vo.date = ctrl.observer('');
	}).event(function(on) {
		var traceid;

		on.trace = {
			click: function(ob, ev) {
				var tar = (ev.currentTarget || ev.target);
				var send = function() {
					http.post('/data/master/index/trace', {
						date: ctrl.vo.date()
					}).then(function(rs) {
						rs.reverse();
						rs.forEach(function(vl) {
							ctrl.vo.list.unshift(vl);
							ctrl.vo.date(vl.date);
						});
					});
				};

				send();
				return;
				if(tar.classList.contains('btn-outline-info')) {
					tar.innerText = '조회중지';
					tar.classList.remove('btn-outline-info');
					tar.classList.add('btn-info');

					traceid = setInterval(send, 1000);
					send();
				} else {
					tar.innerText = '로그조회';
					tar.classList.remove('btn-info');
					tar.classList.add('btn-outline-info');
					traceid = clearInterval(traceid);
				}
			}
		};

		on.session = {
			click: function() {
				http.post('/data/master/index/debug/session')
				.then(function(rs) {
					debug.string(ctrl, rs);
				});
			}
		};
	});
});


}(
	mkApp.view('pageLoader'),
	mkApp.service('debug'),
	mkApp.service('http'),
	mkApp.service('util')
);
