const log = {
  debug(...vl) { process.env.NODE_ENV || console.log(...vl); return log; },
  div(v='') { process.env.NODE_ENV || console.log(v.repeat(30)); return log; },
  info(...vl) { console.log(...vl); return log; },
  error(...vl) { console.error(...vl); return log; }
};

module.exports = {log};