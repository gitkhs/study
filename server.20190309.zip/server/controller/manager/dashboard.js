const pm2 = require('pm2');
const pmList = () => new Promise((res, rej) => {
  pm2.connect(err => {
    if(err) return rej(err);

    pm2.list((err, list) => {
      if(err) return rej(err);

      res(list.map(({
        pid,
        monit:{memory, cpu},
        pm2_env: {username, restart_time, status, name, pm_id}
      }) => ({
        name, pm_id, status, pid, username, memory, cpu, restart_time
      })));

      pm2.disconnect();
    });
  });
});

exports.getDashboard = (req, res) => {
  Promise.all([pmList()]).then(([pmList]) => {
    res.render('manager/dashboard', {
      title: 'Dashboard',
      path: 'dashboard',
      menus: require('./menus.json'),
      pmList: pmList,
    });
  });
};