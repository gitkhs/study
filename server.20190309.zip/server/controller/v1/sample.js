/**
 * @swagger
 * /:
 *   get:
 *     tags:
 *     - "v1"
 *     summary: "get 샘플"
 *     description: "파라메터값을 쿼리스트링(?xxx=xxx) 형식으로 전달
 *       abcd"
 *     operationId: "get"
 *     parameters:
 *     - name: "number"
 *       in: "query"
 *       description: "숫자입력(필수입력)"
 *       type: "integer"
 *       required: true
 *     - name: "string"
 *       in: "query"
 *       description: "문자입력"
 *       type: "string"
 *     responses:
 *       200:
 *         description: "정상"
 *         schema:
 *           type: "object"
 *           properties:
 *             method:
 *               type: "string"
 *             query:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 */
exports.get = (req, res) => {
  res.json({
    aaa: 1,
    mthod: 'get',
    query: req.query,
  });
};

/**
 * @swagger
 * /{number}/{string}:
 *   get:
 *     tags:
 *     - "v1"
 *     summary: "get 샘플(path)"
 *     description: "파라메터값을 URL(/:xxx/:xxx) 형식으로 전달
 *       abcd"
 *     operationId: "get-path"
 *     parameters:
 *     - name: "number"
 *       in: "path"
 *       description: "숫자입력(필수입력)"
 *       type: "string"
 *       required: true
 *     - name: "string"
 *       in: "path"
 *       description: "문자입력"
 *       type: "string"
 *     responses:
 *       200:
 *         description: "정상"
 *         schema:
 *           type: "object"
 *           properties:
 *             method:
 *               type: "string"
 *             params:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 */
exports.getNumberString = (req, res) => {
  res.json({
    method: 'get',
    params: req.params,
  });
};

/**
 * @swagger
 * /:
 *   post:
 *     tags:
 *     - "v1"
 *     summary: "post 샘플"
 *     description: "파라메터값을 body로 전달."
 *     operationId: "post"
 *     parameters:
 *     - in: "body"
 *       name: "body"
 *       description: "body 샘플"
 *       required: true
 *       schema:
 *         type: "object"
 *         properties:
 *           number:
 *             type: "integer"
 *           string:
 *             type: "string"
 *             example: "string value"
 *     responses:
 *       200:
 *         description: "정상"
 *         schema:
 *           type: "object"
 *           properties:
 *             method:
 *               type: "string"
 *             body:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 */
exports.post = (req, res) => {
  res.json({
    method: 'post',
    body: req.body,
  });
};

/**
 * @swagger
 * /{number}/{string}:
 *   post:
 *     tags:
 *     - "v1"
 *     summary: "post 샘플"
 *     description: "파라메터값을 URL혁식과 body로 전달."
 *     operationId: "post-path"
 *     parameters:
 *     - name: "number"
 *       in: "path"
 *       description: "숫자입력(필수입력)"
 *       type: "integer"
 *       required: true
 *     - name: "string"
 *       in: "path"
 *       description: "문자입력"
 *       type: "string"
 *     - in: "body"
 *       name: "body"
 *       description: "body 샘플"
 *       required: true
 *       schema:
 *         type: "object"
 *         properties:
 *           number:
 *             type: "integer"
 *           string:
 *             type: "string"
 *             example: "string value"
 *     responses:
 *       200:
 *         description: "정상"
 *         schema:
 *           type: "object"
 *           properties:
 *             method:
 *               type: "string"
 *             body:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 *             params:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 */
exports.postNumberString = (req, res) => {
  res.json({
    method: 'post',
    params: req.params,
    body: req.body,
  });
};


/**
 * @swagger
 * /:
 *   put:
 *     tags:
 *     - "v1"
 *     summary: "put 샘플"
 *     description: "파라메터값을 body로 전달."
 *     operationId: "put"
 *     parameters:
 *     - in: "body"
 *       name: "body"
 *       description: "body 샘플"
 *       required: true
 *       schema:
 *         type: "object"
 *         properties:
 *           number:
 *             type: "integer"
 *           string:
 *             type: "string"
 *             example: "string value"
 *     responses:
 *       200:
 *         description: "정상"
 *         schema:
 *           type: "object"
 *           properties:
 *             method:
 *               type: "string"
 *             body:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 */
exports.put = (req, res) => {
  res.json({
    method: 'put',
    body: req.body,
  });
};

/**
 * @swagger
 * /{number}/{string}:
 *   put:
 *     tags:
 *     - "v1"
 *     summary: "put 샘플"
 *     description: "파라메터값을 URL혁식과 body로 전달."
 *     operationId: "put-path"
 *     parameters:
 *     - name: "number"
 *       in: "path"
 *       description: "숫자입력(필수입력)"
 *       type: "integer"
 *       required: true
 *     - name: "string"
 *       in: "path"
 *       description: "문자입력"
 *       type: "string"
 *     - in: "body"
 *       name: "body"
 *       description: "body 샘플"
 *       required: true
 *       schema:
 *         type: "object"
 *         properties:
 *           number:
 *             type: "integer"
 *           string:
 *             type: "string"
 *             example: "string value"
 *     responses:
 *       200:
 *         description: "정상"
 *         schema:
 *           type: "object"
 *           properties:
 *             method:
 *               type: "string"
 *             body:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 *             params:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 */
exports.putNumberString = (req, res) => {
  res.json({
    method: 'put',
    params: req.params,
    body: req.body,
  });
};

/**
 * @swagger
 * /:
 *   patch:
 *     tags:
 *     - "v1"
 *     summary: "patch 샘플"
 *     description: "파라메터값을 body로 전달."
 *     operationId: "patch"
 *     parameters:
 *     - in: "body"
 *       name: "body"
 *       description: "body 샘플"
 *       required: true
 *       schema:
 *         type: "object"
 *         properties:
 *           number:
 *             type: "integer"
 *           string:
 *             type: "string"
 *             example: "string value"
 *     responses:
 *       200:
 *         description: "정상"
 *         schema:
 *           type: "object"
 *           properties:
 *             method:
 *               type: "string"
 *             body:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 */
exports.patch = (req, res) => {
  res.json({
    method: 'patch',
    body: req.body,
  });
};

/**
 * @swagger
 * /{number}/{string}:
 *   patch:
 *     tags:
 *     - "v1"
 *     summary: "patch 샘플"
 *     description: "파라메터값을 URL혁식과 body로 전달."
 *     operationId: "patch-path"
 *     parameters:
 *     - name: "number"
 *       in: "path"
 *       description: "숫자입력(필수입력)"
 *       type: "integer"
 *       required: true
 *     - name: "string"
 *       in: "path"
 *       description: "문자입력"
 *       type: "string"
 *     - in: "body"
 *       name: "body"
 *       description: "body 샘플"
 *       required: true
 *       schema:
 *         type: "object"
 *         properties:
 *           number:
 *             type: "integer"
 *           string:
 *             type: "string"
 *             example: "string value"
 *     responses:
 *       200:
 *         description: "정상"
 *         schema:
 *           type: "object"
 *           properties:
 *             method:
 *               type: "string"
 *             body:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 *             params:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 */
exports.patchNumberString = (req, res) => {
  res.json({
    method: 'patch',
    params: req.params,
    body: req.body,
  });
};

/**
 * @swagger
 * /:
 *   delete:
 *     tags:
 *     - "v1"
 *     summary: "delete 샘플"
 *     description: "파라메터값을 body로 전달."
 *     operationId: "delete"
 *     parameters:
 *     - in: "body"
 *       name: "body"
 *       description: "body 샘플"
 *       required: true
 *       schema:
 *         type: "object"
 *         properties:
 *           number:
 *             type: "integer"
 *           string:
 *             type: "string"
 *             example: "string value"
 *     responses:
 *       200:
 *         description: "정상"
 *         schema:
 *           type: "object"
 *           properties:
 *             method:
 *               type: "string"
 *             body:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 */
exports.delete = (req, res) => {
  res.json({
    method: 'delete',
    body: req.body,
  });
};

/**
 * @swagger
 * /{number}/{string}:
 *   delete:
 *     tags:
 *     - "v1"
 *     summary: "delete 샘플"
 *     description: "파라메터값을 URL혁식과 body로 전달."
 *     operationId: "delete-path"
 *     parameters:
 *     - name: "number"
 *       in: "path"
 *       description: "숫자입력(필수입력)"
 *       type: "integer"
 *       required: true
 *     - name: "string"
 *       in: "path"
 *       description: "문자입력"
 *       type: "string"
 *     - in: "body"
 *       name: "body"
 *       description: "body 샘플"
 *       required: true
 *       schema:
 *         type: "object"
 *         properties:
 *           number:
 *             type: "integer"
 *           string:
 *             type: "string"
 *             example: "string value"
 *     responses:
 *       200:
 *         description: "정상"
 *         schema:
 *           type: "object"
 *           properties:
 *             method:
 *               type: "string"
 *             body:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 *             params:
 *               type: "object"
 *               properties:
 *                 number:
 *                   type: "integer"
 *                 string:
 *                   type: "string"
 */
exports.deleteNumberString = (req, res) => {
  res.json({
    method: 'delete',
    params: req.params,
    body: req.body,
  });
};
