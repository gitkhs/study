const router = require('express').Router();
const fs = require('fs');
const {log} = require('../util');

const root = 'controller';
const Controller = class {
  static GET(path) { return new Controller(path); }
  constructor(_path = '') {
    Object.assign(this, {
      _path,
      _child: null,
    });
    if(fs.statSync(`${root}/${_path}`).isFile()) return;

    this._child = fs.readdirSync(`${root}/${_path}`)
      .map(vl => Controller.GET(`${_path}${_path ? '/' : ''}${vl}`));
  }

  load() {
    const {_child, _path} = this;
    if(!_child) return;
    if(!fs.existsSync(`./${root}/${_path}/index.js`)) return

    log.info(`/${_path}`);
    _path && router.use(`/${_path}`, require(`./${_path}`));
    _child.forEach(ctrl => ctrl.load());
  }
};

// controller loading
// ------------------------------ //
log.info('controller loading').div('=');

const ctrl = Controller.GET();
ctrl.load();

// index
router.get('/', (req, res) => {
  res.redirect('/manager/sign-in');
});
// page not found
router.use((req, res, next) => {
  res.status(404);
  res.render('error-404');
});

module.exports = router;
