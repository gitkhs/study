const express = require('express');
const morgan = require('morgan');
const path = require('path');
const cookie = require('cookie-parser');
const session = require('express-session');
const fileStore = require('session-file-store')(session);
const app = express();
require('dotenv').config();

const {
  env: {
    APP_PORT, NODE_ENV, COOKIE_SECRET,
    SESSION_DIR='../sessions'
  },
} = process;

app.set('port', APP_PORT);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(morgan(NODE_ENV == 'production' ? 'combined' : 'dev'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookie(COOKIE_SECRET));
app.use(session({
  secret: COOKIE_SECRET,
  store: new fileStore({ path: SESSION_DIR }),
  resave: false,  // 요청이 왔을때 수정사항이 존재시 저장 여부 (true:강제저장)
  saveUninitialized: false, // 세션 내용이 존재시 저장 여부 (true:강제저장)
  cookie: {
    httpOnly: true,   // 클라이언트에서 쿠키값 확인 가능여부 (true: 조회불가능)
    secure: false,    // https 필수 사용여부
  },
}));
app.use('/', require('./controller'));

app.listen(app.get('port'), () => {
  const {log} = require('./util');
  log.info(`\nserver start:`, {APP_PORT});
});
