require('dotenv').config();
const express = require('express');
const morgan = require('morgan');
const path = require('path');
const cookie = require('cookie-parser');
const session = require('express-session');
const pm2 = require('pm2');
const app = express();
const {
  env: {
    APP_PORT, NODE_ENV, COOKIE_SECRET,
    SESSION_DIR='../sessions'
  },
} = process;

// express setting
// ------------------------------ //
app.set('port', APP_PORT);
app.set('views', path.join(__dirname, 'views/app-manager'));
app.set('view engine', 'pug');

app.use(morgan('dev'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookie(COOKIE_SECRET));
app.use(session({
  secret: COOKIE_SECRET,
  resave: true,  // 요청이 왔을때 수정사항이 존재시 저장 여부 (true:강제저장)
  saveUninitialized: true, // 세션 내용이 존재시 저장 여부 (true:강제저장)
  cookie: {
    httpOnly: true,   // 클라이언트에서 쿠키값 확인 가능여부 (true: 조회불가능)
    secure: false,    // https 필수 사용여부
  },
}));


// express router controller
// ------------------------------ //

// ----- utils ----- //
const {log} = require('./util');
const calcByte = (v, c=0, k=1024) => (v<k ? `${v.toFixed(2)} ${' KMGT'.split('')[c]}B` : calcByte(v/k,++c));
const error = (req, {out, view, status, message}) => { req.error = {out, view, status, message}; };

// ----- pm2 ----- //
const pm2Connect = x => new Promise((s, j) => pm2.connect(e => e ? j(e) : s()));
const pm2List = x => new Promise((s, j) => pm2.list((e, l) => e ? j(e) : s(l.map(({
  pid,
  monit:{memory, cpu},
  pm2_env: {username, restart_time, status, name, pm_id}
}) =>({
  name, pm_id, status, pid, cpu, restart_time,
  memory: calcByte(memory),
})))));

// ----- jwt ----- //
const JWT_SECURE = 'jwt-key';
const jwt = require('jsonwebtoken');
const jwtT0 = vl => jwt.sign(vl, JWT_SECURE);
const jwtT1 = vl => jwt.sign(vl, JWT_SECURE, {expiresIn: '30s'});
const jwtT2 = vl => jwt.sign(vl, JWT_SECURE, {expiresIn: '10s'});
// 인증토근 체크
const verifyToken = req => {
  try {
    const {cookies:{t0, t1}={}} = req;

    req.v0 = jwt.verify(t0, JWT_SECURE);
    req.v1 = jwt.verify(t1, JWT_SECURE);
    if(req.v0.sequence != req.v1.sequence) throw 'not matched';

    return true;
  } catch(err) {
    const {name} = err;
    if(name == 'TokenExpiredError') error(req, {status: 419, message: 'expired tocken'});
    else error(req, {status: 401, message: 'invalid token'});
  }
};
// 화면접근권한 체크
const verifyRender = (req, res, next) => {
  if(verifyToken(req)) {
    const {sequence} = req.v0;

    res.cookie('t1', jwtT1({
      sequence,
    }));
    next();
  } else {
    const {original} = req.v0 || {};

    res.cookie('t0', jwtT0({
      sequence: new Date().getTime(),
      original: req.originalUrl,
      referer: original,
    }));
    res.redirect('/');
  }
};
// 통신권한 체크
const verifyJson = (req, res, next) => {
  if(verifyToken(req)) {
    const {sequence} = req.v0;

    req.accessTicket = new Date().getTime();
    res.cookie('t1', jwtT1({
      sequence,
      ticket: req.accessTicket,
    }));
    next();
  } else {
    const {status=500, message='Server Error'} = req.error || {};
    res.status(status || 500);
    res.json({status, message});
  }
};
// T2: 접근권한 토큰 체크
const verifyAccess = (req, res, next) => {
  try {
    const url = req.originalUrl.substr(1).replace(/\//g, '-');
    const {t2} = req.cookies || {};
    req.v2 = jwt.verify(t2, JWT_SECURE);

    const {v1:{ticket:v1Ticket}, v2:{ticket:v2Ticket, url:v2Url}} = req;
    if(url != v2Url) throw '잘못된 요청입니다.';
    if(v1Ticket != v2Ticket) throw '잘못된 승인 정보 입니다.';

    return next();
  } catch(err) {
    res.status(401);
    res.json({
      status: 401,
      message: typeof err === 'string' ? err : '승인 정보가 바르지 않습니다.'
    });
  }
};

// 로그인 화면
app.get('/', (req, res, next) => {
  const isLogin = verifyToken(req);
  const {referer, original} = req.v0 || {};

  if(isLogin) res.redirect(referer ? referer.replace(/^\/$/, '/dashboard') : '/dashboard');
  else {
    res.cookie('t0', jwtT0({
      sequence: new Date().getTime(),
      original: req.originalUrl,
      referer: original,
    }));
    res.render('sign');
  }
});
// 로그인 승인요청(토근발급)
app.post('/sign-in', (req, res, next) => {
  const isLogin = verifyToken(req);
  if(isLogin) return next(error(req, {status:208, message: 'is logined'}));

  const {email, password} = req.body || {};
  if(!/^2109@2109.com$/.test(email))
    return next(error(req, {status:403, message: 'checked email'}));
  if(!/^1234$/.test(password))
    return next(error(req, {status:403, message: 'checked password'}));

  const {sequence} = req.v0 || {};
  res.cookie('t1', jwtT1({ sequence: sequence }));
  res.json({});
});

// 토큰 갱신
app.get('/renew');
// 접근권한 요청 토큰발급
app.get('/access/:url', verifyJson, (req, res) => {
  const {url} = req.params;
  res.cookie('t2', jwtT2({
    url,
    ticket: req.accessTicket,
  }));
  res.json({});
});

// 대쉬보드...
app.get('/dashboard', verifyRender, (req, res) => {
  res.render('dashboard', {
    title: 'Dashboard',
    path: 'dashboard',
    menus: require('./public/manager.json'),
  });
});
app.get('/dashboard/process', verifyJson, async (req, res, next) => {
  const data = await pm2List();
  res.json(data);
});

// manager -process
app.get('/process', verifyRender, (req, res) => {
  res.render('process', {
    title: 'process',
    path: 'process',
    menus: require('./public/manager.json'),
  });
});

// 서버 시작
app.post('/process/start', verifyJson, verifyAccess, (req, res, next) => {
  const {id} = req.body;
  if(id === undefined || id === '')
    return next(error(req, {status:403, message: 'invalid id'}));

  pm2.restart(id, (e, [{name, pm_id, status, restart_time}]) => {
    console.log('server start', {name, pm_id, status, restart_time});
    res.json({name, status});
  });
});
// 서버 정지
app.post('/process/stop', verifyJson, verifyAccess, (req, res, next) => {
  const {id} = req.body;
  if(id === undefined || id === '')
    return next(error(req, {status:403, message: 'invalid id'}));

  pm2.stop(id, (e, [{name, pm_id, status, restart_time}]) => {
    console.log('server stop', {name, pm_id, status, restart_time});
    res.json({name, status});
  });
});
// 서버 리스타드
app.post('/process/restart', verifyJson, verifyAccess, (req, res, next) => {
  const {id} = req.body;
  if(id === undefined || id === '')
    return next(error(req, {status:403, message: 'invalid id'}));

  pm2.restart(id, (e, [{name, pm_id, status, restart_time}]) => {
    console.log('server restart', {name, pm_id, status, restart_time});
    res.json({name, status});
  });
});

// manager -deploy

app.use((req, res) => {
  const {out, status=404, message='Not Found', view='error'} = req.error || {};
  res.status(status);
  out == 'render' ? res.render(view, {message}) : res.json({status, message});
});

// start server
// ------------------------------ //
pm2Connect().then(x => {
  return app.listen(app.get('port'), x => log.info(`\nserver start:`, {APP_PORT}));
}).then(server => {
  // web socket
  const socketIO = require('socket.io');
  const sio = socketIO(server, {path: '/socket.io'});

  sio.on('connection', socket => {
    const req = socket.request;
    const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    console.log('socket connection', {ip, id:socket.id});

    // disconnect
    socket.on('disconnect', x => {
      console.log('socket disconnect', {ip, id:socket.id});
      clearInterval(socket.interval);
      const {intProcess} = socket;
      intProcess && clearInterval(intProcess);
    });

    // process status
    socket.on('process', err => {
      const process = async x => {
        const data = await pm2List();
        socket.emit('process', data);
        process();
      };
      process();
    });

    // logtrace
    socket.on('logtrace', err => {
    });

  });
}).catch(e => {
  console.log('-pm2 connect-', e);
});
