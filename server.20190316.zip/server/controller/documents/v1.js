const router = require('express').Router();
const ui = require('swagger-ui-express');
const doc = require('swagger-jsdoc');
const { env: {APP_PORT} } = process;

router.use('/', ui.serve, ui.setup(doc({
  swaggerDefinition: {
    info: {
      title: 'test API',
      version: '1.0.0',
      description: 'api Specitication',
    },
    host: `localhost:${APP_PORT}`,
    basePath: '/v1'
  },
  apis: [
    'controller/v1/*.js',
    'controller/v1/*/*.js',
  ],
})));

module.exports = router;