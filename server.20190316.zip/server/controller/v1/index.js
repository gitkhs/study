const router = require('express').Router();

const sample = require('./sample');
router.get('/', sample.get);
router.get('/:number/:string', sample.getNumberString);
router.post('/', sample.post);
router.post('/:number/:string', sample.postNumberString);
router.put('/', sample.put);
router.put('/:number/:string', sample.putNumberString);
router.patch('/', sample.patch);
router.patch('/:number/:string', sample.patchNumberString);
router.delete('/', sample.delete);
router.delete('/:number/:string', sample.deleteNumberString);

router.use((req, res, next) => {
  res.status(404);
  res.json({
    code: 404,
    message: 'service not found'
  });
});

module.exports = router;
