const {log} = require('../../util');

exports.getSignIn = (req, res) => {
  log.debug('cookie', req.cookies);
  log.debug('session', req.sessionID, req.session);
  res.render('sign-in');
};
