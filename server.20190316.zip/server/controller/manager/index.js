const router = require('express').Router();

const dashboard = require('./dashboard');
router.get('/dashboard', dashboard.getDashboard);

const sign = require('./sign');
router.get('/sign-in', sign.getSignIn);

module.exports = router;