const router = require('express').Router();

const process = require('./process');
router.get('/process', dashboard.getMain);


module.exports = router;