(app => {


app.require('/socket.io/socket.io.js');
app.view('signIn', ctrl => {
  ctrl.onload(prm => {
    ctrl.vo.deactive(false);
    const name = location.pathname.substr(1);
    name && app.controller()[name].open();
  });

  ctrl.vo.deactive = ctrl.observer(true);

  ctrl.vo.email = ctrl.observer('');
  ctrl.on.email = ctrl.event(handle => {
    handle.check = (vl) => {
      if(!vl) return 'invalid email';
      if(/^\d|^@|@$/.test(vl) || !/\w+@\w+\.\w+$/.test(vl)) return 'check email input value';
    };
  });

  ctrl.vo.password = ctrl.observer('');
  ctrl.on.password = ctrl.event(handle => {
    handle.check = (vl) => {
      if(!vl) return 'invalid password';
      if(vl.length < 4) return 'check password input value';
    };
    handle.keyup = (vo, evt) => {
      const {deactive} = ctrl.vo;
      const {email: onEmail, password: onPassword} = ctrl.on;
      deactive(onEmail.invalidate() || onPassword.invalidate());
    };
  });

  ctrl.on.login = ctrl.event(listener => {
    listener.click = (obs, evt) => {
      // const {email: voEmail, password: voPassword} = ctrl.vo;
      // const {email: onEmail, password: onPassword} = ctrl.on;

      // if(onEmail.invalidate()) return;
      // if(onPassword.invalidate()) return;

      // ctrl.log(`email: ${voEmail()}\npassword: ${voPassword()}`);
      const http = app.http({ctrl, focus: evt});
      http.post('/sign-in', {email:'2109@2109.com', password: '1234'})
        .then(x => location.reload());
    };
  });
});

// ----- dashboard ----- //
app.view('dashboard', ctrl => {
  const {processMonit} = app.controller();
  processMonit.initialize({type: 'list'});

  ctrl.onload(prm => {
  });

  ctrl.vo.socket = ctrl.observer();
});
// ----- process ----- //
app.view('process', ctrl => {
  const {processMonit} = app.controller();
  processMonit.initialize({type: 'card'});

  ctrl.onload(prm => {
  });

  ctrl.vo.processes = ctrl.observer([]);
  ctrl.on.log = ctrl.event(hndl => {
    hndl.click = (obs, evt) => {
      console.log('--', obs);
      // const {processLog} = app.controller({focus:evt});
      // processLog.open({msg:'log'});
    };
  });
});

// ----- processMonit ----- //
app.component('processMonit', ctrl => {
  ctrl.onload(({type}) => {
    const {isList, process} = ctrl.vo;
    isList(type == 'list');
    // return;

    const http = app.http({ctrl});
    http.get('/dashboard/process').then(data => {
      if(!data || !data.length) return;

      const f = () => {
        const r = data.shift();
        if(r) {
          process.push(r);
          setTimeout(f, 200);
        }
      };
      process.removeAll(), f();
    });

    // realtime data
    const socket = io.connect(location.origin, {path: '/socket.io'});
    socket.emit('process');
    socket.on('process', data => {
      const {process} = ctrl.vo;
      data.forEach(dt => {
        const row = process()
          .filter(vl => vl.name == dt.name && vl.pm_id == dt.pm_id)
          .pop();
        process.replace(row, dt);
      });
    });
  });

  ctrl.vo.process = ctrl.observer([]);
  ctrl.vo.isList = ctrl.observer(true);
  ctrl.on.log = ctrl.event(hnd => {
    hnd.click = (vl, evt) => {
      // ctrl.log({vl});
      const {processLog} = app.controller({focus: evt});
      processLog.open();
    };
  });
  ctrl.on.restart = ctrl.event(hnd => {
    hnd.click = (vl, evt) => {
      const {pm_id:id} = vl;
      const http = app.http({ctrl, focus: evt});
      http.submit('/process/restart', {id});
    };
  });
  ctrl.on.stopStart = ctrl.event(hnd => {
    hnd.click = (vl, evt) => {
      const {status, pm_id:id} = vl;
      const stopStart = status == 'online' ? 'stop' : 'start';
      const http = app.http({ctrl, focus: evt});

      http.submit(`/process/${stopStart}`, {id});

      // process.replace(vl, Object.assign({}, vl, {
      //   status: vl.status == 'online' ? 'stop' : 'online'
      // }));
    };
  });

  ctrl.html(`
<!-- ko if: vo.isList --><!-- ko foreach: vo.process -->
  <li class="list-group-item d-flex flex-row justify-content-start flex-wrap">
    <div class="mt-1 mr-3 mb-1">
      <span class="badge mr-1">name</span>
      <span data-bind="text: $data.name" class="badge badge-secondary mr-1">name</span>
    </div>
    <div class="mt-1 mr-3 mb-1">
      <span class="badge mr-1">restart</span>
      <span data-bind="text: $data.restart_time" class="badge badge-warning mr-1">0</span>
    </div>
    <div class="mt-1 mr-3 mb-1">
      <span class="badge mr-1">status</span>
      <span data-bind="text: $data.status, css:{
        'badge-success': /^online$/.test($data.status),
        'badge-danger': !/^online$/.test($data.status)
      }" class="badge mr-1">online</span>
    </div>
    <div class="mt-1 mr-3 mb-1">
      <span class="badge mr-1">memory</span>
      <span data-bind="text: $data.memory" class="badge badge-info mr-1">0</span>
    </div>
    <div class="mt-1 mr-3 mb-1">
      <span class="badge mr-1">cpu</span>
      <span data-bind="text: $data.cpu" class="badge badge-info mr-1">0</span>
    </div>
  </li>
<!-- /ko --><!-- /ko -->

<!-- ko ifnot: vo.isList --><!-- ko foreach: vo.process -->
  <div class="col-12 col-sm-4 mb-3">
    <div class="card">
      <div class="card-header d-flex flex-row justify-content-between flex-wrap">
        <div data-bind="text: $data.name" class="font-weight-bold">app name</div>
        <div data-bind="text: $data.status, css: {
          'text-success': /^online$/.test($data.status),
          'text-danger': !/^online$/.test($data.status)
        }" class="font-weight-bold">online</div>
      </div>
      <div class="card-body d-flex flex-row justify-content-start flex-wrap">
        <div class="mt-1 mr-3 mb-1">
          <span class="badge mr-1">restart</span>
          <span data-bind="text: $data.restart_time" class="badge badge-warning mr-1">restart</span>
        </div>
        <div class="mt-1 mr-3 mb-1">
          <span class="badge mr-1">memory</span>
          <span data-bind="text: $data.memory" class="badge badge-info mr-1">1</span>
        </div>
        <div class="mt-1 mr-3 mb-1">
          <span class="badge mr-1">cpu</span>
          <span data-bind="text: $data.cpu" class="badge badge-info mr-1">1</span>
        </div>
      </div>
      <div class="card-footer text-right">
        <button data-bind="event: $parent.on.log" class="btn btn-sm btn-secondary mr-2">log</button>
        <button data-bind="event: $parent.on.restart, attr:{
          disabled: !/^online$/.test($data.status)
        }" class="btn btn-sm btn-success mr-2">restart</button>
        <button data-bind="
          text: $data.status == 'online' ? 'stop' : 'start',
          event: $parent.on.stopStart,
          css: {
            'btn-primary': !/^online$/.test($data.status),
            'btn-danger': /^online$/.test($data.status)
        }" class="btn btn-sm mr-2">stop</button>
      </div>
    </div>
  </div>
<!-- /ko --><!-- /ko -->
  `);
});

// ----- log popup ----- //
app.popup('processLog', ctrl => {
  let cnt = 0;
  ctrl.onload(x => {
    const {logs} = ctrl.vo;
    while(cnt < 20) {
      logs.unshift(`Error: bind EADDRINUSE null:${cnt++}`);
    }
  });

  ctrl.vo.logs = ctrl.observer([]);
  ctrl.on.flush = ctrl.event(hndl => {
    hndl.click = (obs, evt) => {
      const {logs} = ctrl.vo;
      logs.unshift(`Error: bind EADDRINUSE null:${cnt++}`);
    };
  });
  ctrl.on.close = ctrl.event(hndl => {
    hndl.click = (obs, evt) => {
      ctrl.close();
    };
  });

  ctrl.clss({ 'bottom-sheet': true });
  ctrl.html([
    '<div class="card" data-app-motion>',
      '<div class="card-header d-flex flex-row justify-content-between flex-wrap">',
        '<div>',
          '<button data-bind="event: on.flush" class="btn btn-sm btn-secondary mr-2">flush</button>',
          '<button class="btn btn-sm btn-secondary mr-2">log</button>',
          '<button class="btn btn-sm btn-secondary">error</button>',
        '</div>',
        '<div>',
          '<button data-bind="event: on.close" class="btn btn-sm btn-primary">close</button>',
        '</div>',
      '</div>',
      '<div data-bind="foreach: vo.logs" class="card-body">',
        '<p data-bind="text: $data">message</p>',
      '</div>',
    '</div>',
  ]);
});

// ----- alert ----- //
app.popup('alert', ctrl => {
  ctrl.onload(({msg='', ok='ok'}) => {
    const {message, btnok} = ctrl.vo;
    message(msg);
    btnok(ok);
  });

  ctrl.vo.message = ctrl.observer('');
  ctrl.vo.btnok = ctrl.observer('ok');
  ctrl.on.btnok = ctrl.event(handle => {
    handle.click = obs => ctrl.close();
  });

  ctrl.clss({ 'modal-layer': true });
  ctrl.html([
    '<div class="card" data-app-motion>',
      '<div class="card-body">',
        '<div data-bind="html: vo.message" class="card-text">message</div>',
      '</div>',
      '<div class="card-footer text-right">',
        '<button data-bind="text: vo.btnok, event: on.btnok" class="btn btn-sm btn-primary">ok</button>',
      '</div>',
    '</div>',
  ]);
});

// ========== common library ========== //
// invalid check
app.directive('invalidate', handle => {
  handle.init = (el, prm, ctrl) => {
		const fb = el.parentNode.insertBefore(document.createElement('div'), el.nextSibling);
    fb.classList.add('invalid-tooltip');

    prm.invalidate = () => {
      const msg = prm.check(el.value);
      if(msg) {
        fb.innerText = msg;
        el.classList.add('is-invalid');
        el.focus();
      } else el.classList.remove('is-invalid');

      return !!msg;
    };

    el.addEventListener('keyup', evt => prm.invalidate());
  };
});

// http
app.append('http', ({focus, progress, ctrl}={}) => {
  let _finish=null;
  const loading = bar => {
    if(bar === undefined) {
      let httpProgress = document.querySelector('[data-app-resource] .http-progress');
      if(httpProgress) return httpProgress;

      httpProgress = app.appendResource(document.createElement('div'));
      httpProgress.style.cssText = 'left:0; top:0; width:100vw; height:100vh;';
      httpProgress.innerHTML = '<div class="http-progress"></div>';
      return httpProgress;
    }

    bar && app.removeResource(bar);
  };
  const ajax = ({url, method, param}) => new Promise(async (resolve, reject) => {
    const {alert} = app.controller({focus});
    /^\/access/.test(url) ||
      ctrl && ctrl.log('style:{color:#aaf}', {url}, {method}, {param});

    try {
      const bar = loading();
      const rs = await fetch(url, {
        method,
        body: param && JSON.stringify(param),
        credentials: 'include',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });
      const {status, headers:rsHeaders} = rs;
      const contentType = rsHeaders.get('Content-Type');
      const data = (/text/.test(contentType) && await rs.text()) ||
        (/json/.test(contentType) && await rs.json());

      loading(progress == 'infinite' ? _finish : bar);
      /^\/access/.test(url) ||
        ctrl && ctrl.log('style:{color:#faa}', {url}, {data});

        if(status == 200) {
        resolve(data);
      }
      else {
        const {message} = data || {};
        alert.open({msg: message || 'error'}).then(x => {
          // 419: 만료된세션, 208: 기로그인
          if(status == 419 || status == 208) return location.reload();
          http.finish();
          loading(_finish);
          reject({status, message});
        });
      }
    } catch(e) {
      /^\/access/.test(url) ||
        ctrl && ctrl.log('style:{color:#faa}', {url}, e);

      alert.open({msg: 'server transaction fail'}).then(x => {
        http.finish();
        loading(_finish);
        reject({status:-100, message: e});
      });
    }
  });

  const http = {};
  http.finish = x => {
    _finish = document.querySelector('[data-app-resource] .http-progress');
    _finish = _finish && _finish.parentNode;
    return http;
  };
  http.get = url => ajax({ url, method: 'GET' });
  http.post = (url, param) => ajax({ url, method: 'POST', param});
  http.submit = (url, param) => http.get(`/access/${url.substr(1).replace(/\//g, '-')}`)
    .then(x => http.post(url, param));

  return http;
});


})(MakeApp('signIn'));
