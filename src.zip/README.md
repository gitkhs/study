# reactive-app

## 노드 환경

> npm init -y

노드 환경 설정을 위한 초기화로 `package.json` 파일을 생성 하며 값설정을 기본값으로 자동 세팅

> npm i

`package.json` 파일에 설정되어 있는 값으로 설치 한다.
`--save` 옵션으로 설치 한경우만 설정 파일에 설치 정보가 기록됨.

## webpack 설정

웹팩은 4버전을 기준으로 작성되어 있음. 4버전은 `webpack-cli` 설치 필요.

> npm i webpack@4.16.0 --save

> npm i webpack-cli@3.0.8 --save

> npm i webpack-dev-server@3.1.4 --save

웹팩 사용을 위한 설치

> npm i babel-core@6.26.3 --save

> npm i babel-loader@7.1.5 --save

> npm i babel-polyfill@6.26.0 --save

> npm i babel-preset-env@1.7.0 --save

트렌스파일링을 위한 바벨 설치

> npm i whatwg-fetch@2.0.4 --save

fetch 사용을위한 설치

> npm i node-sass@4.9.2 --save

> npm i sass-loader@7.0.3 --save

> npm i css-loader@1.0.0 --save

> npm i style-loader@0.21.0 --save

Sass 사용을 위한 설치

## webpack.config.js

웹팩을 구동하기 위한 기본 설정 파일이다.

```javascript
module.exports = {
  mode: 'development',
};
```
컴파일시 압축 할지 여부를 설정하는 옵션으로 작성하지 않으면 기본 압축 모드 이다. 개발자 모드 수행시 `development` 옵션값을 사용하면 컴파일시 압축하지 않는다. 배포모드는 `production`으로 압출파일로 출력.

```javascript
module.exports = {
  entry: {
    app: './src/app.js',
    'app-list': [
      './src/app1.js',
      './src/app2.js',
    ],
  },
};
```
컴파일될 파일을 작성한다.
* entry name: 컴파일될 항목명
* string: 컴파일 되상이 되는 스크립트 파일로 여러개를 한개의 파일로 컴파일 할경우 배열 처리 가능

```javascript
module.exports = {
  out: {
    path: __dirname + '/asset',
    filename: '[name].js',
  },
};
```
컴파일된 파일을 생성할 폴더 위치를 설정한다. `[name]`을 사용할 경우 **entry**에서 설정한 이름으로 파일을 생성한다.

```javascript
module.exports = {
  devServer: {
    contentBase: './dist',
  },
};
```
웹팩 서버를 실행시 루트 디렉토리 설정

[참고: DevServer](https://webpack.js.org/configuration/dev-server/#src/components/Sidebar/Sidebar.jsx)


```javascript
module.exports = {
  module: {
    rules: [{
      test: /\.scss$|\.sass$|\.css$/,
      use: [{
        loader: 'style-loader',
        options: {
          insertAt: 'top',
        },
      }, {
        loader: 'css-loader',
      },{
        loader: 'sass-loader',
      }],
    }],
  },
};
```
Sass 사용을 위한 로더 설정

```javascript
module.exports = {
  entry: {
    app: [
      'babel-polyfill',	// babel 폴리필
      'whatwg-fetch',	// fetch
    ],
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        use: [
          {
            loader: 'babel-loader',
            query: {
              presets: ['env']
            },
          },
        ],
      },
    ],
  },
};
```
ES5 버전 트렌스파일링을 위한 프리세 및 fetch 와 babel 폴리핑 inport

## npm 스크립트 실행과 webpack 컨피그 파일 설정

파라메터의 전달
```
"script" :{
  "start": "webpack-dev-server --env.target=mdrn --mode=development",
  "build": "webpack --env.value=param"
}
```

```javascript
module.exports = (env, param) => {
	const entry = {};
	const rules = [];
  const module = {rules};
  
  return {
    entry,
    module,
    output : {
      path: '',
      filename: '',
    },
  };
}
```

* env: 사용자정의 파라메터를 사용할수 있는 객체로 CLI에 입력된 `--env.value=param`값을 `env = {value:'param'}` 형태로 받을 수 있다.
* 노드에의해 실행 되는 모듈에서 사용되는 옵션값을 사용할 수 있는 객체로 `--mode=development`값을 `{mode:'development'}` 형대로 받을 수 있다.
