const Controller = require('./Controller');
const {
	appQuery,
	appElement,
	appSelector,
} = require('../utils');

module.exports = class Sheet extends Controller {
	constructor(fw, vl) {
		super(fw, vl);

		super.member({
			_clsName: 'Sheet',
			_parent: appQuery({ appSheetDailog: '' }, document.body),
		});
	}

	// 클래스 멤버변수 용
	member() {}

	// 바텀시트 오픈
	async open(param) {
		const {_parent, _name, _onload} = super.member();
		const created = () => {
			const dom = appQuery({ appSheet: _name }, _parent);
			dom.setAttribute(appSelector({ appSheetOn: '' }), '');

			_onload && _onload(param);
		};

		await this.render({created});

		return new Promise((_close, reject) => {
			super.member({ _close });
		});
	}

	// 바텀시트 종료
	close(param) {
		const {_parent, _name, _close, _target} = super.member();

		const dom = appQuery({ appSheet: _name }, _parent);
		dom.setAttribute(appSelector({ appSheetOff: '' }), '');
		dom.addEventListener('animationend', (ev) => {
			dom.parentNode.removeChild(dom);
			_target && _target.focus();
		});

		_close && _close(param);
	}

};
