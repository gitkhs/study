rxApp.service('http', function(svc, log) {
	var util = rxApp.utils();
	var isIE = util.isIE;
	var ajax = util.ajax;
	var promise = util.promise;
	var entries = util.entries;
	var before = function(url, prm) {
		log('%crequest: ' + url + '\n', 'color:#00f;', prm);
		rxApp.progress(true);
	};
	var after = function(url, prm) {
		log('%cresponse: ' + url + '\n', 'color:#f00;', prm);
		rxApp.progress(false);
	};

	// methods
	// ================================================== //
	svc.rest = function(method, prm) {
		return ajax(url, {
			method: method.toUpperCase(),
			body: encodeURIComponent(JSON.stringify(prm))
		});
	};

	svc.get = function(url) {
		return ajax(url);
	};

	svc.post = function(url, prm) {
		before(url, prm);

		return promise(function(resolve, reject) {
			ajax(url, {
				method: 'POST',
				body: encodeURIComponent(JSON.stringify(prm))
			}).then(function(data) {
				after(url, data);
				resolve(data);
			}).catch(function(err) {
				after(url, err);
				reject(err);
			});
		});
	};

	svc.submit = function(url, prm) {
		before(url, prm);

		return promise(function(resolve, reject) {
			ajax(url, {
				method: 'POST',
				body: entries(prm).map(function(vl) {
					return [
						encodeURIComponent(vl[0]),
						encodeURIComponent(
							vl[1] instanceof Object ? JSON.stringify(vl[1]) : vl[1]
						),
					].join('=');
				}).join('&'),
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8'
				}
			}).then(function(data) {
				after(url, data);
				resolve(data);
			}).catch(function(err) {
				before(url, err);
				reject(err);
			});
		});
	};

	svc.download = function(url) {
		rxApp.progress(true);

		ajax(url).then(function(blob) {
			rxApp.progress(false);
			if(blob.size <= 0) return;

			var link;
			var filename = url.split('/');

			if(isIE) {
				window.navigator.msSaveBlob(blob, filename.pop());
			} else {
				link = document.createElement('a');
				link.setAttribute('href', (window.URL || window.webkitURL).createObjectURL(blob));
				link.setAttribute('download', filename.pop());
				link.click();
				link.remove();
			}
		}).catch(function(err) {
			rxApp.progress(false);
		});
	};

	svc.upload = function(url, sel, observe) {
		var form = document.querySelector(sel);
		var files = form.querySelectorAll('input[type=file]');
		var values = {};
		for(var i=0; i<files.length; i++) {
			values[files[i].name] = files[i].value;
		}

		// if(!observe || !observe(values)) return;

		before(url);
		return promise(function(resolve, reject) {
			ajax(url, {
				method: 'POST',
				body: new FormData(form)
			}).then(function(data) {
				after(url);
				resolve(data);
			}).catch(function(err) {
				after(url);
				reject(err);
			});
		});
	};
});
