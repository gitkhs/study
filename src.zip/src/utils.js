//
// ================================================== //
const entries = vl => Object.entries(vl);
const json = vl => (typeof vl === 'string' ? JSON.parse(vl) : JSON.stringify(vl));
const left = (vl, sz) => vl.substr(0, sz);
const right = (vl, sz) => vl.substr(vl.length - sz);
const lpad = (vl, sz, ch=' ') => (vl.length >= sz ? vl : right(ch.repeat(sz) + vl, sz));
const rpad = (vl, sz, ch=' ') => (vl.length >= sz ? vl : left(vl + ch.repeat(sz), sz));
const date = (vl = 'yyyymmdd', dt = new Date) => {
	return vl.replace(/(yyyy|yy|mm|dd|h24|hh|mi|ss|ms|a\/p)/gi, (vl) => {
		switch(vl) {
		case 'yyyy': return dt.getFullYear();
		case 'yy': return lpad(dt.getFullYear(), 2, '0');
		case 'mm': return lpad(dt.getMonth()+1, 2, '0');
		case 'dd': return lpad(dt.getDate(), 2, '0');
		case 'h24': return lpad(dt.getHours(), 2, '0');
		case 'hh': return lpad(dt.getHours()%12 || 12, 2, '0');
		case 'mi': return lpad(dt.getMinutes(), 2, '0');
		case 'ss': return lpad(dt.getSeconds(), 2, '0');
		case 'ms': return lpad(dt.getMilliseconds(), 3, '0');
		default: return '';
		}
	});
};
const snake = vl => vl.replace(/[A-Z]/g, vl => `-${vl.toLowerCase()}`);
const camel = vl => vl.replace(/-\w/g, vl => vl.toUpperCase().substr(1));
const ajax = async (url, {method='GET', headers, body} = {}) => {
	return await fetch(url, { method, headers, body }).then(rs => {
		const contentType = rs.headers.get('Content-Type');

		if(/text/.test(contentType)) return rs.text();
		if(/json/.test(contentType)) return rs.json();
		return rs.blob();
	});
};
const promise = fn => new Promise(fn);
const promiseAll = vl => Promise.all(vl);

// DOM Object & element controll
// ================================================== //
const isIE = (() => {
	const agent = navigator.userAgent.toLowerCase();
	if(navigator.appName == 'Netscape' && (agent.includes('trident') || agent.includes('msie'))) {
		return true;
	}
})();
const hash = () => {
	const vl = location.hash &&
		location.hash.substr(1)
		.replace(/&/g, '","')
		.replace(/=/g, '":"');
	return vl && json(`{"${vl}"}`) || {};
};
const query = (v, dom = document) => dom.querySelector(v);
const queryAll = (v, dom = document) => dom.querySelectorAll(v);
const element = (tag, {html, text, attr, css, on} = {}) => {
	const dom = document.createElement(tag);

	html ? (dom.innerHTML = html) : (text && (dom.innerText = text));
	attr && entries(attr).forEach(([k, v]) => dom.setAttribute(k, v));
	css && entries(css).forEach(([k, v]) => (dom.style[k] = v));
	on && entries(on).forEach(([k, v]) => dom.addEventListener(k, v));

	return dom;
};

// app
// ================================================== //
const appInfo = (() => {
	const info = document.querySelector('[data-app-info]');
	if(!info) {
		throw 'can not find appInfo element:: tag element attribute set [data-app-info]';
	}

	const appInfo = info.dataset.appInfo && info.dataset.appInfo.replace(/'/g,'"').replace(/\n/g, '');
	if(!/^{.+?}$/.test(appInfo)) {
		throw 'appInfo is JONS data:: data-app-info="{...}"';
	}

	return JSON.parse(appInfo);
})();
const prefixData = vl => `data-${vl}`;
const appSelector = (vl) => {
	const sel = Object.entries(vl)
		.map(([ky, vl]) => (vl ? `${snake(ky)}=${vl}` : snake(ky)))
		.join('');
	return prefixData(sel);
};
const appQuery = (vl, dom) => {
	const sel = appSelector(vl);
	return query(`[${sel}]`, dom) || query(`[${sel.replace('data-', '')}]`, dom)
};
const appQueryAll = (vl, dom) => {
	const sel = appSelector(vl);
	const all = queryAll(`[${sel}]`, dom);
	return all.length ? all : queryAll(`[${sel.replace('data-', '')}]`, dom)
};
const appElement = (vl) => {
	const attr = Object.entries(vl)
		.reduce((rs, [ky, vl]) => Object.assign(rs, {
			[prefixData(snake(ky))]: vl
		}), {});

	return element('div', {attr });
};


module.exports = {
	entries,
	json,
	left,
	right,
	lpad,
	rpad,
	date,
	snake,
	camel,
	ajax,
	promise,
	promiseAll,
	
	isIE,
	hash,
	element,

	appInfo,
	appSelector,
	appQuery,
	appQueryAll,
	appElement,
	
	log(...vl) {
		/127.0.0.1|localhost/.test(location.hostname)
		&& console && console.log(...vl);
	},
};