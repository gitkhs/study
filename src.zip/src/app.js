require('./app.scss');

const getInfo = () => {
	const info = document.querySelector('[data-app-info]');
	if(!info) {
		throw 'can not find appInfo element:: tag element attribute set [data-app-info]';
	}

	const appInfo = info.dataset.appInfo && info.dataset.appInfo.replace(/'/g,'"').replace(/\n/g, '');
	if(!/^{.+?}$/.test(appInfo)) {
		throw 'appInfo is JONS data:: data-app-info="{...}"';
	}

	return JSON.parse(appInfo);
};
const getScript = function(info) {
	'use strict';

	const {path='', framework} = info;
	if(!framework) {
		throw `invalid app framework:: app-info="{'framework':...}"`;
	}

	try {
		if(typeof Symbol == 'undefined') return `${path}/${framework}-clss.js`;
		eval('class x {}'), eval('var x = x=>x');
	} catch(e){
		return `${path}/${framework}-clss.js`;
	}

	return `${path}/${framework}-mdrn.js`;
};


document.addEventListener('DOMContentLoaded', function() {
	const head = document.head;
	const body = document.body;
	const appInfo = getInfo();

	const script = document.createElement('script');
	script.setAttribute('src', getScript(appInfo));
	head.appendChild(script);

	const dailog = document.createElement('div');
	dailog.setAttribute('data-app-dailog', '');
	dailog.innerHTML = `<div data-app-sheet-dailog></div>
		<div data-app-modal-dailog></div>
		<div data-app-progress-dailog>
			<div data-app-progress-dimmed></div>
			<div data-app-progress-contents></div>
		</div>`;
	body.appendChild(dailog);
});
