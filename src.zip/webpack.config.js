module.exports = ({target}, {mode='production'}) => {
	const entry = {};
	const rules = [];
	const module = {rules};

	if(target == 'clss') {
		entry['knockout-clss'] = [
			'whatwg-fetch',
			'babel-polyfill',
			'./src/app-fw-knockout.js'
		];
		entry['vue-clss'] = [
			'whatwg-fetch',
			'babel-polyfill',
			'./src/app-fw-vue.js'
		];
		entry['app-service-http'] = './src/service/app-service-http.js';
		rules.push({
			test: /\.js$/,
			use: [
				{
					loader: 'babel-loader',
					query: {
						presets: ['env'],
					},
				},
			],
		});
	} else {
		entry['knockout-mdrn'] = './src/app-fw-knockout.js';
		entry['vue-mdrn'] = './src/app-fw-vue.js';
		entry['app-service-http'] = './src/service/app-service-http.js';
	}

	if(mode == 'development' || target == 'clss') {
		entry.app = './src/app.js';
		rules.push({
			test: /\.scss$|\.sass|\.css$/,
			use: [
				{
					loader: 'style-loader',
					options: {
						insertAt: 'top',
					},
				}, {
					loader: 'css-loader',
				}, {
					loader: 'sass-loader',
				},
			],
		});
	}

	return {
		mode,
		module,
		entry,
		output: {
			path: __dirname + '/asset',
			filename: '[name].js'
		},
	}
};
